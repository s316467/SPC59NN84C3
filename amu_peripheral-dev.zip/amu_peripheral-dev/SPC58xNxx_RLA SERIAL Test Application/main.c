/****************************************************************************
*
* Copyright Â© 2015-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
 order specified in the application wizard. The file is generated
 automatically.*/

#include "stm_lld_cfg.h"
#include "./amu_api/amu_api.h"

#ifdef TESTING

ieee32 ieee32Result = 0;

ieee32 p1[5] = {
    101,
    102,
    103,
    104,    
    105
};
ieee32 p2[5] = {
    106,
    107,
    108,
    109,
    110
};
ieee32 p3[1] = { 103 };
ieee32 p4[1] = { 100 };
ieee32 p5[1] = { 99 };
uint16 p6[1] = { 1 }; // Size of the ASC function, reduced because of init size
uint05 p7[1] = { 4 }; // Dimensionality of the ASC function (if this => 32)
uint16 p8[1] = { 96 }; // outer stage2 "for" loop counter
ieee64 p9[1] = { 95 };
uint01 v16[1] = { 1 }; // 0 or 1
uint01 vfh[1] = { 1 }; // 0 or 1
ieee32 v32f[5] = {
    31,
    32,
    33,
    34,
    35
};
ieee16 v16h[5] = {
    31,
    32,
    33,
    34,
    35
};
uint16 v16x[5] = {
    31,
    32,
    33,
    34,
    35
};
ieee32 L[5] = {
    111,
    112,
    113,
    114,
    115
};
ieee32 u[5] = {
    116,
    117,
    118,
    119,
    120
};
uint07 cmExp[1] = { 0 }; // 0 or 1
uint01 setz[1] = { 0 }; // 0 or 1
ieee64 y64[1] = { 0 };
ieee32 y32[1] = { 0 };
ieee64 z64[1] = { 0 };
ieee32 z32[1] = { 0 };
ieee32 ut[5] = { 0,
 0,
 0,
 0,
 0 
};

const struct AMU_params_tag amu_params = {
    .p1 = {
    101,
    102,
    103,
    104,    
    105},
    .p2 = {
    106,
    107,
    108,
    109,
    110},
    .p3 = {
    121,
    122,
    123,
    124,    
    125},
    .p4 = {100},
    .p5 = {99},
    .p6 = {1},
    .p7 = {5},
    .p8 = {1},
    .p9 = {95},
    .v32f = {31, 32, 33, 34, 35},
    .v16h = {31, 32, 33, 34, 35}, 
    .v16x = {31, 32, 33, 34, 35},
    .L = {
    111,
    112,
    113,
    114,
    115},
    .u = {
    116,
    117,
    118,
    119,
    120},
    .cmExp = {0}
};

unsigned int ADMAusedChannels[2] = {0,1};
// struct AMU_params_tag * amu_params_ptr = &amu_params;

const struct ADMAChannels_tag adma_channels = {
    .num_used_channels = 2,
    .channels = {0,1}
};

struct AMUResults_tag amu_results = {
    .RES64M = 0,
    .RES64L = 0,
    .RES32 = 0,
    .Y64M = 0,
    .Y64L = 0,
    .Y32 = 0
};

#endif

int main(void) {

    // uint8_t message[] = "Hello World!\r\n";
    /* Initialization of all the imported components in the order specified in
    the application wizard. The function is generated automatically.*/
    componentsInit();

    /* Enable Interrupts */
    irqIsrEnable();

    /* Start Serial Driver */
    sd_lld_start(&SD1, NULL);

    // test functions calls
    // amuStage1(u,p1,p2,ut,p7);
    // amuStage23( ut, v16, vfh, v32f, v16h, v16x, cmExp, L, p1, p3, p4, p5, p6, p7, p8, p9, setz, y64, y32, z64, z32);

    AMUInit(&AMU,NULL);
    
    AMUAddInputs(0,&AMU,&adma_channels,&amu_params,&EDMA_0,NULL,0,true,true);

    AMUExec(&AMU,1,false,false);
    ALUstopCheckResume(&AMU,true,false);
    AMUGetResults(&AMU,&adma_channels,&amu_results);
    // TEST CODE

    // amuStage1(u, p1, p2, ut, p7);

    // amuStage23(ut, v16, vfh, v32f, v16h, v16x, cmExp, L, p3, p4, p5, p6, p7, p8, p9, setz, y64, y32, z64, z32);


    /* Application main loop.*/
    for (;;) {
        /*
        // example application for leds, to be removed at project ending
        if (sd_lld_write(&SD1, message, (uint16_t)(sizeof(message) / sizeof(message[0]))) == SERIAL_MSG_OK) {
        pal_lld_togglepad(PORT_A, LED_D2);
        osalThreadDelayMilliseconds(500);
        pal_lld_togglepad(PORT_A, LED_D3);
        osalThreadDelayMilliseconds(500);
        pal_lld_togglepad(PORT_A, LED_D2);
        pal_lld_togglepad(PORT_A, LED_D3);
        osalThreadDelayMilliseconds(500);
        }
        */

       
    }
}
