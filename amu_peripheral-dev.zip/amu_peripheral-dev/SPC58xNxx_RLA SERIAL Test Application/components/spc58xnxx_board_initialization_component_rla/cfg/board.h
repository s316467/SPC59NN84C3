/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/

#ifndef _BOARD_H_
#define _BOARD_H_

#include "pal.h"

/*
 * Setup for a generic SPC58xNxx board.
 */

/*
 * Board identifiers.
 */
#define BOARD_SPC58xNXX_EVB
#define BOARD_NAME                  "SPC58xNxx_EVB"

/*
 * Support macros.
 */
#define MSCR_IO_INDEX(port, pin)    (((port) * 16U) + (pin))

/*
 * I/O definitions.
 */
#define LED_D2                      1U
#define LIN0_TX                     10U
#define LED_D3                      2U

/*
 * PORT definitions.
 */
#define PORT_LED_D2                 PORT_A
#define PORT_LIN0_TX                PORT_A
#define PORT_LED_D3                 PORT_A

/*
 * MSCR_IO definitions.
 */
#define MSCR_IO_LED_D2              MSCR_IO_INDEX(PORT_LED_D2, LED_D2)
#define MSCR_IO_LIN0_TX             MSCR_IO_INDEX(PORT_LIN0_TX, LIN0_TX)
#define MSCR_IO_LED_D3              MSCR_IO_INDEX(PORT_LED_D3, LED_D3)

/*
 * MSCR_MUX definitions.
 */

#if !defined(_FROM_ASM_)
#ifdef __cplusplus
extern "C" {
#endif
  void boardInit(void);
#ifdef __cplusplus
}
#endif
#endif /* _FROM_ASM_ */

#endif /* _BOARD_H_ */
