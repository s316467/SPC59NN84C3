/****************************************************************************
*
* Copyright © 2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED,
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    sdadc_lld.h
 * @brief   SPC5xx SDADC low level driver header.
 *
 * @addtogroup SDADC
 * @{
 */

#ifndef _SDADC_LLD_H_
#define _SDADC_LLD_H_

#include "spc5_lld.h"
#include "lldconf.h"

#if (LLD_USE_SDADC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @name    SDADC constant definitions
 * @{
 */
#define SDADC_MODE_DIFFERENTIAL           0U
#define SDADC_MODE_SINGLE				  1U
#define SDADC_VCOMSEL_VREFN               0U
#define SDADC_VCOMSEL_VREFPHALF           1U
#define SDADC_ANCHSEL(x)				  (x)
#define SDADC_PDR(x)				      (x)
#define SDADC_GAIN(x)				      (x)
#define SDADC_HPASS_DISABLED			  0U
#define SDADC_HPASS_ENABLED 			  1U
#define SDADC_OFFSET_CALIBRATION          1U
#define SDADC_GAIN_CALIBRATION            2U
#define SDADC_BOTH _CALIBRATION           SDADC_OFFSET_CALIBRATION | SDADC_GAIN_CALIBRATION
#define SDADC_CALIBRATION(x)              (x)
#define SDADC_BIAS_DISABLED				  0U
#define SDADC_BIAS_ENABLED				  1U
#define SDADC_DATAOUT_UNSIGNED			  0U
#define SDADC_DATAOUT_SIGNED			  1U
#define SDADC_FIFO_FALSE				  0U
#define SDADC_FIFO_TRUE 				  1U
#define SDADC_FIFO_1_BYTE                 0U
#define SDADC_FIFO_4_BYTE                 1U
#define SDADC_FIFO_8_BYTE                 2U
#define SDADC_FIFO_16_BYTE                3U
#define SDADC_FIFO_OVERWRITE_DISABLED	  0U
#define SDADC_FIFO_OVERWRITE_ENABLED 	  1U
#define SDADC_FIFO_FULL_EVENT_DISABLED	  0U
#define SDADC_FIFO_FULL_EVENT_ENABLED 	  1U
#define SDADC_FIFO_OVERRUN_EVENT_DISABLED 0U
#define SDADC_FIFO_OVERRUN_EVENT_ENABLED  1U
#define SDADC_WATCHDOG_EVENT_DISABLED     0U
#define SDADC_WATCHDOG_EVENT_ENABLED      1U
#define SDADC_DATA_VALID                  0U
#define SDADC_DATA_NOTVALID               1U
/** @} */

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/**
 * @name    Configuration options
 * @{
 */
/**
 * @brief   SDADCD1 driver enable switch.
 * @details If set to @p TRUE the support for SDADC0 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(SPC5_SDADC_USE_SDADC0) || defined(__DOXYGEN__)
#define SPC5_SDADC_USE_SDADC0                   FALSE
#endif

/**
 * @brief   SDADCD2 driver enable switch.
 * @details If set to @p TRUE the support for SDADC1 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(SPC5_SDADC_USE_SDADC1) || defined(__DOXYGEN__)
#define SPC5_SDADC_USE_SDADC1                   FALSE
#endif

/**
 * @brief   SDADCD3 driver enable switch.
 * @details If set to @p TRUE the support for SDADC2 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(SPC5_SDADC_USE_SDADC2) || defined(__DOXYGEN__)
#define SPC5_SDADC_USE_SDADC2                   FALSE
#endif

/**
 * @brief   SDADCD4 driver enable switch.
 * @details If set to @p TRUE the support for SDADC3 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(SPC5_SDADC_USE_SDADC3) || defined(__DOXYGEN__)
#define SPC5_SDADC_USE_SDADC3                   FALSE
#endif

/**
 * @brief   SDADCD5 driver enable switch.
 * @details If set to @p TRUE the support for SDADC4 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(SPC5_SDADC_USE_SDADC4) || defined(__DOXYGEN__)
#define SPC5_SDADC_USE_SDADC4                   FALSE
#endif

/**
 * @brief   SDADCD6 driver enable switch.
 * @details If set to @p TRUE the support for SDADC5 is included.
 * @note    The default is @p FALSE.
 */
#if !defined(SPC5_SDADC_USE_SDADC5) || defined(__DOXYGEN__)
#define SPC5_SDADC_USE_SDADC5                   FALSE
#endif
/** @} */

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/
#if (SPC5_HAS_SDADC0 == FALSE) && (SPC5_SDADC_USE_SDADC0 == TRUE)
#error "SDADC0 not present in the selected device"
#endif
#if (SPC5_HAS_SDADC1 == FALSE) && (SPC5_SDADC_USE_SDADC1 == TRUE)
#error "SDADC1 not present in the selected device"
#endif
#if (SPC5_HAS_SDADC2 == FALSE) && (SPC5_SDADC_USE_SDADC2 == TRUE)
#error "SDADC2 not present in the selected device"
#endif
#if (SPC5_HAS_SDADC3 == FALSE) && (SPC5_SDADC_USE_SDADC3 == TRUE)
#error "SDADC3 not present in the selected device"
#endif
#if (SPC5_HAS_SDADC4 == FALSE) && (SPC5_SDADC_USE_SDADC4 == TRUE)
#error "SDADC4 not present in the selected device"
#endif
#if (SPC5_HAS_SDADC5 == FALSE) && (SPC5_SDADC_USE_SDADC5 == TRUE)
#error "SDADC5 not present in the selected device"
#endif
#if    (SPC5_SDADC_USE_SDADC0 == FALSE) && (SPC5_SDADC_USE_SDADC1 == FALSE)  \
	&& (SPC5_SDADC_USE_SDADC2 == FALSE) && (SPC5_SDADC_USE_SDADC3 == FALSE)  \
	&& (SPC5_SDADC_USE_SDADC4 == FALSE) && (SPC5_SDADC_USE_SDADC5 == FALSE)  
#error "SDADC driver activated but no SDADC peripheral assigned"
#endif

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   Type of a structure representing an SDADC driver.
 */
typedef struct SDADCDriver SDADCDriver;

/**
 * @brief   SDADC notification callback type.
 *
 * @param[in] sdadcp      pointer to the @p SDADCDriver object triggering the
 *                         callback
 */
typedef void (*sdadccallback_t)(SDADCDriver *sdadcp);

/**
 * @brief   Driver configuration structure.
 * @note
 */
typedef struct {
  /**
   * @brief   SDADC Ground reference.
   */
  float vrefn;
  /**
   * @brief   SDADC Voltage reference.
   */
  float vrefp;
  /**
   * @brief   Calibration type selection.
   */
  uint8_t calibration; 
  /**
   * @brief   Mode Selection.
   */
  uint8_t mode;
  /**
   * @brief   Common voltage bias selection for single ended mode.
   */
  uint8_t vcomsel;
  /**
   * @brief  Analog channel selection
   */
  uint8_t anchsel;
  /**
   * @brief  Programmable Decimation Rate
   */
  uint8_t pdr;
  /**
   * @brief  Programmable Gain
   */
  uint8_t gain;
  /**
   * @brief  High Pass Filter enabled/disabled
   */
  uint8_t hpass;
  /**
   * @brief  BIAS enabled/disabled
   */
  uint8_t bias;
  /**
   * @brief  Output Settling Delay
   */
  uint8_t osd;
  /**
   * @brief  FIFO size
   */
  uint8_t fifo_size;
  /**
   * @brief  FIFO Overwrite enabled/disabled
   */
  uint8_t fifo_overwrite;
   /**
   * @brief  FIFO full event interrupt enabled/disabled
   */
  uint8_t fifo_full;
   /**
   * @brief  FIFO threshold
   */
  uint8_t fifo_threshold;
  /**
   * @brief  FIFO full event callback function
   */
  sdadccallback_t fifo_fullcb;
   /**
   * @brief  FIFO overrun event interrupt enabled/disabled
   */
  uint8_t fifo_overrun;
   /**
   * @brief  FIFO full event callback function
   */
  sdadccallback_t fifo_overruncb;
  /**
  * @brief  Watchdog event enable
  */
  uint8_t watchdog;
  /**
  * @brief  Watchdog low threshold
  */
  float  watchdog_lowth;
  /**
  * @brief  Watchdog event enable
  */
  float  watchdog_highth;
  /**
  * @brief watchdog event callback function
  */
  sdadccallback_t watchdog_cb;

} SDADCConfig;

/**
 * @brief   Structure representing a SDADC driver.
 */
struct SDADCDriver {
  /**
   * @brief   Current configuration data.
   */
  SDADCConfig *config;
  /**
   * @brief Pointer to the SDADCx registers block.
   */
  volatile struct spc5_sdadc *sdadc;
  /**
   * @brief   Offset calibration value
   */
  float offset_calibration;
  /**
   * @brief   Gain calibration value
   */
  float gain_calibration;
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/
/*===========================================================================*/
/* IRQ Handlers                                                              */
/*===========================================================================*/

#if (SPC5_SDADC_USE_SDADC0 == TRUE)
IRQ_HANDLER(SPC5_SDADC0_HANDLER);
#endif
#if (SPC5_SDADC_USE_SDADC1 == TRUE)
IRQ_HANDLER(SPC5_SDADC1_HANDLER);
#endif
#if (SPC5_SDADC_USE_SDADC2 == TRUE)
IRQ_HANDLER(SPC5_SDADC2_HANDLER);
#endif
#if (SPC5_SDADC_USE_SDADC3 == TRUE)
IRQ_HANDLER(SPC5_SDADC3_HANDLER);
#endif
#if (SPC5_SDADC_USE_SDADC4 == TRUE)
IRQ_HANDLER(SPC5_SDADC4_HANDLER);
#endif
#if (SPC5_SDADC_USE_SDADC5 == TRUE)
IRQ_HANDLER(SPC5_SDADC5_HANDLER);
#endif

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if (SPC5_SDADC_USE_SDADC0 == TRUE) || defined(__DOXYGEN__)
extern SDADCDriver SDADCD1;
#endif

#if (SPC5_SDADC_USE_SDADC1 == TRUE) || defined(__DOXYGEN__)
extern SDADCDriver SDADCD2;
#endif

#if (SPC5_SDADC_USE_SDADC2 == TRUE) || defined(__DOXYGEN__)
extern SDADCDriver SDADCD3;
#endif

#if (SPC5_SDADC_USE_SDADC3 == TRUE) || defined(__DOXYGEN__)
extern SDADCDriver SDADCD4;
#endif

#if (SPC5_SDADC_USE_SDADC4 == TRUE) || defined(__DOXYGEN__)
extern SDADCDriver SDADCD5;
#endif

#if (SPC5_SDADC_USE_SDADC5 == TRUE) || defined(__DOXYGEN__)
extern SDADCDriver SDADCD6;
#endif

#ifdef __cplusplus
extern "C" {
#endif
void sdadc_lld_init(void);
void sdadc_lld_start(SDADCDriver *sdadcp, SDADCConfig *config);
void sdadc_lld_stop(SDADCDriver *sdadcp);
void sdadc_lld_start_conversion(SDADCDriver *sdadcp);
void sdadc_lld_stop_conversion(SDADCDriver *sdadcp);
uint8_t sdadc_lld_read(SDADCDriver *sdadcp, float* converted_value);
float sdadc_lld_get_offsetCalibration (SDADCDriver *sdadcp);
float sdadc_lld_get_gainCalibration (SDADCDriver *sdadcp);
#ifdef __cplusplus
}
#endif

#endif /* LLD_USE_SDADC */

#endif /* _SDADC_LLD_H_ */

/** @} */
