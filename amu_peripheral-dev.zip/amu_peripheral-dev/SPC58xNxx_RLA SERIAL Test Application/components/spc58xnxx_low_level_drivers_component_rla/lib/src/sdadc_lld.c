/****************************************************************************
*
* Copyright © 2019 STMicroelectronics - All Rights Reserved
*
* This software is licensed under SLA0098 terms that can be found in the
* DM00779817_1_0.pdf file in the licenses directory of this software product.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED,
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
*****************************************************************************/
/**
 * @file    sdadc_lld.c
 * @brief   SPC5xx SDADC low level driver code.
 *
 * @addtogroup SDADC
 * @{
 */

#include "sdadc_lld.h"

#if (LLD_USE_SDADC == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
static float sdadc_lld_calibrateGain(SDADCDriver *sdadcp);
static float sdadc_lld_calibrateOffset(SDADCDriver *sdadcp);
static void sdadc_lld_serve_interrupt(SDADCDriver *sdadcp);

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   SDADC0 driver identifier.
 */
#if (SPC5_SDADC_USE_SDADC0 == TRUE) || defined(__DOXYGEN__)
SDADCDriver SDADCD1;
#endif

/**
 * @brief   SDADC1 driver identifier.
 */
#if (SPC5_SDADC_USE_SDADC1 == TRUE) || defined(__DOXYGEN__)
SDADCDriver SDADCD2;
#endif
/**
 * @brief   SDADC2 driver identifier.
 */
#if (SPC5_SDADC_USE_SDADC2 == TRUE) || defined(__DOXYGEN__)
SDADCDriver SDADCD3;
#endif
/**
 * @brief   SDADC3 driver identifier.
 */
#if (SPC5_SDADC_USE_SDADC3 == TRUE) || defined(__DOXYGEN__)
SDADCDriver SDADCD4;
#endif
/**
 * @brief   SDADC4 driver identifier.
 */
#if (SPC5_SDADC_USE_SDADC4 == TRUE) || defined(__DOXYGEN__)
SDADCDriver SDADCD5;
#endif
/**
 * @brief   SDADC5 driver identifier.
 */
#if (SPC5_SDADC_USE_SDADC5 == TRUE) || defined(__DOXYGEN__)
SDADCDriver SDADCD6;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions and macros.                                        */
/*===========================================================================*/

/**
 * @brief   SDADC ISR service routine.
 *
 * @param[in] sdadcp      pointer to the @p SDADCDriver object
 *
 * @notapi
 */
#if defined(__ghs__) || defined(__DOXYGEN__)
#pragma ghs ZO
static void sdadc_lld_serve_interrupt(SDADCDriver *sdadcp) {
#else
__attribute__((optimize("-O0"))) static void sdadc_lld_serve_interrupt(SDADCDriver *sdadcp) {
#endif
  /* check fifo full event */
  if (sdadcp->sdadc->SFR.B.DFFF == 1U) {
    /* callback*/
    if (sdadcp->config->fifo_fullcb != NULL) {
      sdadcp->config->fifo_fullcb(sdadcp);
    }
    /* clear flag */
    sdadcp->sdadc->SFR.B.DFFF = 1U;
  }
  /* check overrun event */
  if (sdadcp->sdadc->SFR.B.DFORF == 1U) {
    /* callback*/
    if (sdadcp->config->fifo_overruncb != NULL) {
      sdadcp->config->fifo_overruncb(sdadcp);
    }
    /* clear flag */
    sdadcp->sdadc->SFR.B.DFORF = 1U;
  }
  /* check watchdog event */
  if ((sdadcp->sdadc->SFR.B.WTHH == 1U) || (sdadcp->sdadc->SFR.B.WTHL == 1U)) {
    if (sdadcp->config->watchdog_cb != NULL) {
      sdadcp->config->watchdog_cb(sdadcp);
    }
    /* clear flags */
    sdadcp->sdadc->SFR.B.WTHH = 1U;
    sdadcp->sdadc->SFR.B.WTHL = 1U;
  }
}
#ifdef __ghs__
#pragma ghs O
#endif

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

#if (SPC5_SDADC_USE_SDADC0 == TRUE)
/**
 * @brief   SDAD0 Interrupt handler.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_SDADC0_HANDLER) {

  IRQ_PROLOGUE();

  sdadc_lld_serve_interrupt(&SDADCD1);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_SDADC_USE_SDADC1 == TRUE)
/**
 * @brief   SDAD0 Interrupt handler.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_SDADC1_HANDLER) {

  IRQ_PROLOGUE();

  sdadc_lld_serve_interrupt(&SDADCD2);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_SDADC_USE_SDADC2 == TRUE)
/**
 * @brief   SDAD0 Interrupt handler.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_SDADC2_HANDLER) {

  IRQ_PROLOGUE();

  sdadc_lld_serve_interrupt(&SDADCD3);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_SDADC_USE_SDADC3 == TRUE)
/**
 * @brief   SDAD0 Interrupt handler.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_SDADC3_HANDLER) {

  IRQ_PROLOGUE();

  sdadc_lld_serve_interrupt(&SDADCD4);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_SDADC_USE_SDADC4 == TRUE)
/**
 * @brief   SDAD0 Interrupt handler.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_SDADC4_HANDLER) {

  IRQ_PROLOGUE();

  sdadc_lld_serve_interrupt(&SDADCD5);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_SDADC_USE_SDADC5 == TRUE)
/**
 * @brief   SDAD0 Interrupt handler.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_SDADC5_HANDLER) {

  IRQ_PROLOGUE();

  sdadc_lld_serve_interrupt(&SDADCD6);

  IRQ_EPILOGUE();
}
#endif

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level SDADC driver initialization.
 *
 * @init
 */
void sdadc_lld_init(void) {

#if (SPC5_SDADC_USE_SDADC0 == TRUE)
  SDADCD1.config = NULL;
  SDADCD1.sdadc = &SPC5_SDADC0;
  INTC_PSR(SPC5_SDADC0_INT_NUMBER) = SPC5_SDADC0_PRIORITY;
#endif

#if (SPC5_SDADC_USE_SDADC1 == TRUE)
  SDADCD2.config = NULL;
  SDADCD2.sdadc = &SPC5_SDADC1;
  INTC_PSR(SPC5_SDADC1_INT_NUMBER) = SPC5_SDADC1_PRIORITY;
#endif

#if (SPC5_SDADC_USE_SDADC2 == TRUE)
  SDADCD3.config = NULL;
  SDADCD3.sdadc = &SPC5_SDADC2;
  INTC_PSR(SPC5_SDADC2_INT_NUMBER) = SPC5_SDADC2_PRIORITY;
#endif

#if (SPC5_SDADC_USE_SDADC3 == TRUE)
  SDADCD4.config = NULL;
  SDADCD4.sdadc = &SPC5_SDADC3;
  INTC_PSR(SPC5_SDADC3_INT_NUMBER) = SPC5_SDADC3_PRIORITY;
#endif

#if (SPC5_SDADC_USE_SDADC4 == TRUE)
  SDADCD5.config = NULL;
  SDADCD5.sdadc = &SPC5_SDADC4;
  INTC_PSR(SPC5_SDADC4_INT_NUMBER) = SPC5_SDADC4_PRIORITY;
#endif

#if (SPC5_SDADC_USE_SDADC5 == TRUE)
  SDADCD6.config = NULL;
  SDADCD6.sdadc = &SPC5_SDADC5;
  INTC_PSR(SPC5_SDADC5_INT_NUMBER) = SPC5_SDADC5_PRIORITY;
#endif
}

/**
 * @brief   Configures and activates the SDADC peripheral.
 *
 * @param[in] sdadcp       pointer to the @p SDADCDriver object
 * @param[in] config	   pointer to the @p SDADCDconfig object
 *
 * @api
 */
void sdadc_lld_start(SDADCDriver *sdadcp, SDADCConfig *config) {

  sdadcp->config = config;

#if (SPC5_SDADC_USE_SDADC0 == TRUE)
  if (&SDADCD1 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC0_PCTL, (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC1 == TRUE)
  if (&SDADCD2 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC1_PCTL, (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC2 == TRUE)
  if (&SDADCD3 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC2_PCTL, (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC3 == TRUE)
  if (&SDADCD4 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC3_PCTL, (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC4 == TRUE)
  if (&SDADCD5 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC4_PCTL, (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC5 == TRUE)
  if (&SDADCD6 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC5_PCTL, (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2)));
  }
#endif

  sdadcp->offset_calibration = (float)0U;
  sdadcp->gain_calibration = (float)1U;
  /* perform offset calibration if configured*/
  if ((sdadcp->config->calibration & SDADC_OFFSET_CALIBRATION) != 0U) {
    sdadcp->offset_calibration = sdadc_lld_calibrateOffset(sdadcp);
  }
  /* perform gain calibration if configured*/
  if ((sdadcp->config->calibration & SDADC_GAIN_CALIBRATION) != 0U) {
    sdadcp->gain_calibration = sdadc_lld_calibrateGain(sdadcp);
  }

  /* Flush FIFO */
  sdadcp->sdadc->FCR.B.FRST = 1U;
  /* Reset Data FIFO overrun flag*/
  sdadcp->sdadc->SFR.B.DFORF = 1U;
  /*Reset Data FIFO Full Flag*/
  sdadcp->sdadc->SFR.B.DFFF = 1U;
  /* Set conversion mode */
  sdadcp->sdadc->MCR.B.MODE = sdadcp->config->mode;
  /* Set VCOMSEL */
  sdadcp->sdadc->MCR.B.VCOMSEL = sdadcp->config->vcomsel;
  /* set channel */
  sdadcp->sdadc->CSR.B.ANCHSEL = sdadcp->config->anchsel;
  /* set gain */
  sdadcp->sdadc->MCR.B.PGAN = sdadcp->config->gain;
  /* enable gain error calibration mode*/
  sdadcp->sdadc->MCR.B.GECEN = 1U;
  /* set output settling time */
  sdadcp->sdadc->OSDR.B.OSD = sdadcp->config->osd;
  /* set decimation rate */
  sdadcp->sdadc->MCR.B.PDR = sdadcp->config->pdr;
  /* set highpass filter */
  sdadcp->sdadc->MCR.B.HPFEN = sdadcp->config->hpass;
  /* set BIAS enable */
  sdadcp->sdadc->CSR.B.BIASEN = sdadcp->config->bias;

  /* Fifo and event configuration */
  sdadcp->sdadc->FCR.B.FE = SDADC_FIFO_TRUE;
  sdadcp->sdadc->FCR.B.FOWEN = sdadcp->config->fifo_overwrite;
  /* fifo full event*/
  if (sdadcp->config->fifo_full == SDADC_FIFO_FULL_EVENT_ENABLED) {
    sdadcp->sdadc->FCR.B.FTHLD = sdadcp->config->fifo_threshold - 1U;
    sdadcp->sdadc->RSER.B.DFFDIRE = SDADC_FIFO_FULL_EVENT_ENABLED;
  }
  /* fifo overrun event */
  if (sdadcp->config->fifo_overrun == SDADC_FIFO_OVERRUN_EVENT_ENABLED) {
    sdadcp->sdadc->RSER.B.DFORIE = SDADC_FIFO_OVERRUN_EVENT_ENABLED;
  }

  /* watchdog configuration */
  if (sdadcp->config->watchdog == SDADC_WATCHDOG_EVENT_ENABLED) {
    float step;
    float thr;
    uint16_t low;
    uint16_t high;
    /* enable watchdog */
    sdadcp->sdadc->MCR.B.WDGEN = 1U;
    /* set low threshold */
    step = (float)32768U / (sdadcp->config->vrefp - sdadcp->config->vrefn);
    thr = (step * sdadcp->config->watchdog_lowth*sdadcp->gain_calibration) - sdadcp->offset_calibration;
    low = (uint16_t)thr;
    sdadcp->sdadc->WTHHLR.B.THRL = low;
    /* set high threshold*/
    thr = (step * sdadcp->config->watchdog_highth*sdadcp->gain_calibration) - sdadcp->offset_calibration;
    high = (uint16_t)thr;
    sdadcp->sdadc->WTHHLR.B.THRH = high;
    /* enable interrupt */
    sdadcp->sdadc->RSER.B.WTHDIRE = 1U;
  }
}

/**
 * @brief   Deactivates the SDADC peripheral.
 *
 * @param[in] sdadcp      pointer to the @p SDADCDriver object
 *
 * @api
 */
void sdadc_lld_stop(SDADCDriver *sdadcp) {

  /* Power Down SDADC */
  sdadcp->sdadc->MCR.B.EN = 0U;

#if (SPC5_SDADC_USE_SDADC0 == TRUE)
  if (&SDADCD1 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC0_PCTL, (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC1 == TRUE)
  if (&SDADCD2 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC1_PCTL, (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC2 == TRUE)
  if (&SDADCD3 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC2_PCTL, (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC3 == TRUE)
  if (&SDADCD4 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC3_PCTL, (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC4 == TRUE)
  if (&SDADCD5 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC4_PCTL, (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0)));
  }
#endif
#if (SPC5_SDADC_USE_SDADC5 == TRUE)
  if (&SDADCD6 == sdadcp) {
    SPCSetPeripheralClockMode(SPC5_SDADC5_PCTL, (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0)));
  }
#endif
}

/**
 * @brief   Starts an SDADC conversion.
 *
 * @param[in] sdadcp    pointer to the @p SDADCDriver object
 *
 * @api
 */
void sdadc_lld_start_conversion(SDADCDriver *sdadcp) {

  /* Start Conversion */
  sdadcp->sdadc->MCR.B.EN = 1U;
  sdadcp->sdadc->RKR.B.RESET_KEY = 0x5AF0U;
}

/**
 * @brief   Stops an ongoing conversion.
 *
 * @param[in] sdadcp    pointer to the @p SDADCDriver object
 *
 * @api
 */
void sdadc_lld_stop_conversion(SDADCDriver *sdadcp) {

  /* stop conversion by powering down ADC module */
  sdadcp->sdadc->MCR.B.EN = 0U;
  /* Flush FIFO */
  sdadcp->sdadc->FCR.B.FRST = 1U;
  /* Reset Data FIFO overrun flag*/
  sdadcp->sdadc->SFR.B.DFORF = 1U;
  /*Reset Data FIFO Full Flag*/
  sdadcp->sdadc->SFR.B.DFFF = 1U;

}

/**
 * @brief   Read converted value of a Channel
 *
 * @param[in] sdadcp             pointer to the @p SDADCDriver object
 * @param[in] converted_value    pointer to float where converted value is stored
 *
 * @return                SDADC_DATA_VALID or SDADC_DATA_NOTVALID Flag
 *
 * @api
 */
uint8_t sdadc_lld_read(SDADCDriver *sdadcp, float* converted_value) {

  int16_t data;
  uint8_t return_value = SDADC_DATA_NOTVALID;

  /* check if valid data is available */
  if (sdadcp->sdadc->SFR.B.DFEF == 0U) {
    /* read converted data */
    data = (int16_t)((uint16_t)sdadcp->sdadc->CDR.R);

    /* apply calibration*/
    *converted_value = (float)data + sdadcp->offset_calibration;
    *converted_value = (*converted_value) / sdadcp->gain_calibration;
    return_value = SDADC_DATA_VALID;
  }

  /* return value*/
  return return_value;

}

/**
 * @brief   Perform Offset Calibration
 *
 * @param[in] sdadcp      Pointer to the @p SDADCDriver to calibrate
 *
 * @return                Offset calibration Value
 *
 * @notapi
 */

static float sdadc_lld_calibrateOffset(SDADCDriver *sdadcp) {

  int32_t calibration_value = 0U;
  int16_t converted_value;
  uint8_t counter;
  int16_t temp[16];

  /* Flush FIFO */
  sdadcp->sdadc->FCR.B.FRST = 1U;
  /* Reset Data Fifo Overrun Flag */
  sdadcp->sdadc->SFR.B.DFORF = 1U;
  /*Reset Data FIFO Full Flag*/
  sdadcp->sdadc->SFR.B.DFFF = 1U;
  /* Enable FIFO */
  sdadcp->sdadc->FCR.B.FE = 1U;
  /* set FIFO size to 16byte*/
  /* sdadcp->sdadc->FCR.B.FSIZE = SDADC_FIFO_16_BYTE; FIFO size is 16 set by hardware*/
  /* set fifo threshold to 16 byte*/
  sdadcp->sdadc->FCR.B.FTHLD = 0x0F;
  /*Set Output Settling Time */
  sdadcp->sdadc->OSDR.R = 0x000000FFUL;
  /* set gain used to calculate offset calibration */
  sdadcp->sdadc->MCR.B.PGAN = sdadcp->config->gain;
  /* Gain Error Mode disabled */
  sdadcp->sdadc->MCR.B.GECEN = 0U;
  /* select differential mode */
  sdadcp->sdadc->MCR.B.MODE = SDADC_MODE_DIFFERENTIAL;
  /*
   * select channel to convert depending on which type of conversion
   * will be performed after calibration
   */
  if (sdadcp->config->mode == SDADC_MODE_SINGLE && sdadcp->config->vcomsel == SDADC_VCOMSEL_VREFN) {
    sdadcp->sdadc->CSR.B.ANCHSEL = SDADC_ANCHSEL(4U); /* VREFN - VREFN*/
  }
  else {
    sdadcp->sdadc->CSR.B.ANCHSEL = SDADC_ANCHSEL(5U); /* VREFP/2 - VREFP/2 */
  }
  /* Disable BIAS on all input */
  sdadcp->sdadc->CSR.B.BIASEN = 0U;
  /* disable high pass filter*/
  sdadcp->sdadc->MCR.B.HPFEN = 0U;
  /*Enable SDADC module */
  sdadcp->sdadc->MCR.B.EN = 1U;
  /* start conversion */
  sdadcp->sdadc->RKR.B.RESET_KEY = 0x5AF0U;
  /* wait until converted datas are ready */
  while (sdadcp->sdadc->SFR.B.DFFF == 0U) {

  }

  for (counter = 0; counter < 16; counter++) {
    /* read data */
    temp[counter] = (int16_t)((uint16_t)sdadcp->sdadc->CDR.B.CDATA);
    converted_value = temp[counter]; //sdadcp->sdadc->CDR.B.CDATA;
    /* calculate offset calibration */
    calibration_value += (0U - converted_value);
  }

  /*Disable SDADC module */
  sdadcp->sdadc->MCR.B.EN = 0U;

  /* return average value of calibration value */
  return (float)calibration_value / (float)16U;
}

/**
 * @brief   Perform GAIN Calibration
 *
 * @param[in] sdadcp      Pointer to the @p SDADCDriver to calibrate
 *
 * @return                GAIN calibration Value
 *
 * @notapi
 */

static float sdadc_lld_calibrateGain(SDADCDriver *sdadcp) {

  uint8_t counter;
  int32_t calibration_value;
  float calculated_gain;
  float dp, dn;
  int16_t temp[16];

  /* Flush FIFO */
  sdadcp->sdadc->FCR.B.FRST = 1U;
  /* Reset Data Fifo Overrun Flag */
  sdadcp->sdadc->SFR.B.DFORF = 1U;
  /*Reset Data FIFO Full Flag*/
  sdadcp->sdadc->SFR.B.DFFF = 1U;
  /* Enable FIFO */
  sdadcp->sdadc->FCR.B.FE = 1U;
  /* set FIFO size to 16byte*/
  /* sdadcp->sdadc->FCR.B.FSIZE = SDADC_FIFO_16_BYTE; FIFO size is 16 set by hardware*/
  /* set fifo threshold to 16 byte*/
  sdadcp->sdadc->FCR.B.FTHLD = 0x0F;
  /*Set Output Settling Time */
  sdadcp->sdadc->OSDR.R = 0x000000FFUL;
  /* set decimation rate */
  sdadcp->sdadc->MCR.B.PDR = sdadcp->config->pdr;
  /* set gain 1 used to calculate gain calibration */
  sdadcp->sdadc->MCR.B.PGAN = 0U;
  /* Gain Error Mode enabled */
  sdadcp->sdadc->MCR.B.GECEN = 1U;
  /* select differential mode */
  sdadcp->sdadc->MCR.B.MODE = SDADC_MODE_DIFFERENTIAL;
  /* Disable BIAS on all input */
  sdadcp->sdadc->CSR.B.BIASEN = 0U;
  /* disable high pass filter*/
  sdadcp->sdadc->MCR.B.HPFEN = 0U;
  /* select channel  DREFP - DREFN*/
  sdadcp->sdadc->CSR.B.ANCHSEL = SDADC_ANCHSEL(6U);
  /*Enable SDADC module */
  sdadcp->sdadc->MCR.B.EN = 1U;
  /* start conversion */
  sdadcp->sdadc->RKR.B.RESET_KEY = 0x5AF0U;
  /* wait until converted datas are ready */
  while (sdadcp->sdadc->SFR.B.DFFF == 0U) {

  }
  calibration_value = 0U;
  /*
   * Expected output if there is no gain error is 0b0111_1001_1001_1001, corresponding to
   * full positive scale after attenuation inserted by the internal filter (1*0.95). The
   * measurement should be repeated to reduce contribution of noise during calibration
   * process. Dp is the average value of attenuated positive full scale
   */
  for (counter = 0U; counter < 16U; counter++) {
    temp[counter] = (int16_t)((uint16_t)sdadcp->sdadc->CDR.B.CDATA);
    calibration_value += temp[counter]; //(int16_t)((uint16_t)sdadcp->sdadc->CDR.B.CDATA);
  }

  dp = (float)calibration_value / (float)16U;

  /*Disable SDADC module */
  sdadcp->sdadc->MCR.B.EN = 0U;
  /* Flush FIFO */
  sdadcp->sdadc->FCR.B.FRST = 1U;
  /* Reset Data Fifo Overrun Flag */
  sdadcp->sdadc->SFR.B.DFORF = 1U;
  /*Reset Data FIFO Full Flag*/
  sdadcp->sdadc->SFR.B.DFFF = 1U;
  /* select channel  DREFN - DREFP*/
  sdadcp->sdadc->CSR.B.ANCHSEL = SDADC_ANCHSEL(7U);
  /*Enable SDADC module */
  sdadcp->sdadc->MCR.B.EN = 1U;
  /* start conversion */
  sdadcp->sdadc->RKR.B.RESET_KEY = 0x5AF0U;

  /* wait until converted datas are ready */
  while (sdadcp->sdadc->SFR.B.DFFF == 0U) {

  }
  /*
   * Expected output if there is no gain error is 0b1000_0110_0110_0110, corresponding to
   * full negative scale after attenuation inserted by the internal filter (-1*0.95). The
   * measurement should be repeated to reduce contribution of noise during calibration
   * process. Dn is the average value of attenuated negative full scale
   */
  calibration_value = 0U;
  counter = 0U;
  for (counter = 0U; counter < 16U; counter++) {
    temp[counter] = (int16_t)((uint16_t)sdadcp->sdadc->CDR.B.CDATA);
    calibration_value += temp[counter]; //(int16_t)((uint16_t)sdadcp->sdadc->CDR.B.CDATA);
  }

  dn = (float)calibration_value / (float)16U;

  calculated_gain = (dp - dn) / (float)65536U;

  /*Disable SDADC module */
  sdadcp->sdadc->MCR.B.EN = 0U;

  return calculated_gain;
}

/**
 * @brief   Read Offset Calbration Value
 *
 * @param[in] sdadcp      Pointer to the @p SDADCDriver to read offset calibration value
 *
 * @return                Offset calibration Value
 *
 * @notapi
 */
float sdadc_lld_get_offsetCalibration(SDADCDriver *sdadcp) {
  return sdadcp->offset_calibration;
}

/**
 * @brief   Read Gain Calbration Value
 *
 * @param[in] sdadcp      Pointer to the @p SDADCDriver to read gain calibration value
 *
 * @return                Gain calibration Value
 *
 * @notapi
 */
float sdadc_lld_get_gainCalibration(SDADCDriver *sdadcp) {
  return sdadcp->gain_calibration;
}

#endif /*LLD_USE_SDADC*/
/** @} */
