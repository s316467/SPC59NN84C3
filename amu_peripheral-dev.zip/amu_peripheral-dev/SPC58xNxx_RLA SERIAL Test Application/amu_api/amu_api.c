#include "./amu_api.h"

// functions for initialization 

void AMUInit( volatile struct AMU_tag * amu,struct ADMAChannels_tag * adma_channels) {
    
    if (amu == NULL) {
        return; 
    }
    // initialize ARAM with ADMA (puts all ARAM bits to 0 starting from first index) (To be modified, not actually modifying bits as normal user)
    if(adma_channels != NULL){
        for(int i=0;i<1;i++){
            for(int j = 0; j < 4095; j++){
                amu->CH[adma_channels->channels[i]].DCCRCH.B.DARU = (vuint32_t) 0x00; // ADMA does not modify the original starting value of AMU2_DDACHn
                amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be cleared (max 8, not 13 bits -> 8191)
                amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) j; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                amu->CH[adma_channels->channels[i]].DCCRCH.B.FARZ = (vuint32_t) 1; // zeroing of ARAM by the ADMA enabled
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared
                // amu->CH[adma_channels->channels[i]].DCCRCH.B.WFS1D = (vuint32_t) 1; // ADMA starts transfer after stage23 completition
                amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle
                amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
            }
            amu->CH[adma_channels->channels[i]].DCCRCH.B.FARZ &= 0x00000000; // zeroing of ARAM by the ADMA disabled
            amu->CH[adma_channels->channels[i]].DDACH.B.PTR &= 0x00000000; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF) (0 = beginning of ARAM space, adds used for offset)        
            amu->CH[adma_channels->channels[i]].DCCRCH.B.ECRC &= 0x00000000; // ADMA does not perform CRC check
            amu->CH[adma_channels->channels[i]].DCCRCH.B.DECC &= 0x00000000; // Enable single-bit corrections and double-bit detections on corrupted data fetched from the system Flash address space
            amu->CH[adma_channels->channels[i]].CCR1CH.B.EECC = (vuint32_t) 1; // Enable Error Correcting Code checking of ARAM reads is disabled
            amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle
            amu->CH[adma_channels->channels[i]].DCCRCH.B.SARU = (vuint32_t) 0x00; // ADMA doesn't increment the AMU2_DSACHn as the data transfer occurs. The final value points to the next 8-byte aligned system Flash address
            amu->CH[adma_channels->channels[i]].DCCRCH.B.DARU = (vuint32_t) 0x00; // ADMA doesn't increment the AMU2_DDACHn as each data transfer occurs including the last transfer. The final value points to the next 8-byte aligned ARAM addres
        }
    } else {
        for (int i = 0; i < 2; i++) {
            // amu->CH[adma_channels->channels[i]].IDVCH.B.CH &= 0x00000000; // read only, 0x0001_0002 for CH1, .R is reset value
            // amu->CH[adma_channels->channels[i]].IDVCH.B.VER &= 0x00000000; // read only, 0x0001_0002 for CH1
            // amu->CH[adma_channels->channels[i]].NCH.B.NMSK &= 0x00000000; // exception, usable only in debug mode
            // amu->CH[adma_channels->channels[i]].NCH.B.NCRS &= 0x00000000; // exception, usable only in debug mode
            amu->CH[adma_channels->channels[i]].P1PTRCH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].P2PTRCH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].P3PTRCH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].P4CH.B.IEEE &= 0x00000000;
            amu->CH[adma_channels->channels[i]].P5CH.B.IEEE &= 0x00000000;
            // amu->CH[adma_channels->channels[i]].P6CH.B.UINT &= 0; // exception, usable in exec mode
            amu->CH[adma_channels->channels[i]].P7CH.B.UINT &= 0x00000000;
            // amu->CH[adma_channels->channels[i]].P8CH.B.THRHC &= 0x00000000; // exception, usable in exec mode
            // amu->CH[adma_channels->channels[i]].P8CH.B.UINT &= 0x00000000; // exception, usable in exec mode
            amu->CH[adma_channels->channels[i]].P9MCH.B.IEEE64 &= 0x00000000; 
            amu->CH[adma_channels->channels[i]].P9LCH.B.IEEE64 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].VPTRCH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].LPTRCH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].UPTRCH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DSACH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DDACH.B.PTR &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCNTCH.B.THRHC &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCKSCH.B.UINT &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.ADICFG &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.DARU &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.DECC &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.DEICFG &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.DSAS &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.ECRC &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.EHP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.FARZ &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.HCRCE &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.MAXSP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.RSM &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.SARU &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.SRTSP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STMP3 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV16 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV32 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.WFDNI &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.WFS1D &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.WFS23D &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.AEICFG &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.BPRI &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.CMEXP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.DDSL &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.DNICFG &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.EECC &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.ESTZC &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.MAXSP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.NCICFG &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.OVICFG &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.SETZ &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.SRTSP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.V16 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR1CH.B.VFH &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR18 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR19 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR20 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR25 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR26 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR27 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCR31 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ADCCRE &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.CSXXS &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.ENCRS &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.S1SRT &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.S23RSM &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.S23SRT &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.S23STP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.SNCRS &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.WFDS1 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.WFDS23 &= 0x00000000;
            amu->CH[adma_channels->channels[i]].CCR2CH.B.WFSS23 &= 0x00000000;
            // amu->CH[adma_channels->channels[i]].RES64MCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].RES64LCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].SEIRCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].ACKSCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].RES32CH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].ASEIRCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].AACKSCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].Y64MCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].Y64LCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].AP8CH.R &= 0x00000000; // only in Supervisor Read, but on manual is defined as RW
            // amu->CH[adma_channels->channels[i]].SEINCCH.R &= 0x00000000; // read only
            // amu->CH[adma_channels->channels[i]].Y32CH.R &= 0x00000000; // read only
        }
    }

    for(int i = 0; i < ARAM_TOT_USABLE_SIZE; i+=4) // some addresses could be reserved
        memset(&amu->ADR_reserved0[0] + i, 0, 4);
}

void AMUAddInputs(unsigned int mode, volatile struct AMU_tag * amu, struct ADMAChannels_tag * adma_channels,volatile struct AMU_params_tag * amu_params, volatile struct EDMA_tag * edma_0, volatile struct EDMA_tag * edma_1, unsigned int edma_channel, bool p3StreamingEnabled, bool VStreamingEnabled){
    if (amu == NULL || amu_params == NULL || (mode < 0 || mode > 2) || adma_channels->num_used_channels == 0) {
        return; 
    }
    
    unsigned int start = 0;
    unsigned int counter = 0;
    volatile unsigned int ARAMSize = sizeof(amu->ADR_reserved0);
    volatile unsigned int paramsSize = &amu_params->cmExp[0] - &amu_params->p1[0] + 1;
    if(paramsSize > ARAMSize)
        return;
    switch (mode){
        case 0:
            // CPU only use case
            // For this scenario, a processor core performs all the required data loading, moving the
            // coefficients and parameters from system Flash into the ARAM and then initializing all the
            // corresponding pointer and parameter registers. Once the data load and register initialization
            // are completed, the calculation is started by writing the AMU2_CCR{1,2}CHn registers. In
            // this case, the AMU completion and error indicators are configured to generate interrupts to
            // the processor; the calculation actually begins when the AMU2_CCR2CHn[S1SRT, S23SRT]
            // bits are set.
            // The AMU2 performs the calculation and then typically generates an interrupt, signaling
            // successful completion or some type of error termination or an N crossing debug event.
            // As the processor handles the interrupt, the 64-bit double precision result
            // (AMU2_RES64{M,L}CHn) is retrieved along with the status flags in the AMU2_SEIRCHn
            // register. After processing the interrupt, the service routine clears the interrupt source by
            // writing a “1” to clear the appropriate flag in the low-order byte of the AMU2_SEIRCHn
            // register. The processor then performs any required analysis of the status indicators before
            // saving the result.
            // The preceding description assumes the processor is interrupted when the AMU2 completes
            // as this would be the typical scenario. The AMU2 also provides a channel busy flag
            // (AMU2_SEIRCHn[CHBSY]) that the processor can poll to determine whether the calculation
            // is finished.

            // CPU params insert from flash to ARAM

            // p1
            for(int i = 0; i < (&amu_params->p2[0] - &amu_params->p1[0]); i++){
                if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p1[0]), &amu_params->p1[i], sizeof(amu_params->p1[0])) == NULL) 
                    return;
                start++;
            }
            // p2
            for(int i = 0; i < (&amu_params->p3[0] - &amu_params->p2[0]); i++){
                if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p2[0]), &amu_params->p2[i], sizeof(amu_params->p2[0])) == NULL) 
                    return;
                start++;
            }
            //p3
            for(int i = 0; i < (&amu_params->p4[0] - &amu_params->p3[0]); i++){
                if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p3[0]), &amu_params->p3[i], sizeof(amu_params->p3[0])) == NULL) 
                    return;
                start++;
            }
            //p4
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p4[0]), &amu_params->p4[0], sizeof(amu_params->p4[0])) == NULL) 
                return;
            start++;
            //p5
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p5[0]), &amu_params->p5[0], sizeof(amu_params->p5[0])) == NULL) 
                return;
            start++;
            //p6
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p6[0]), &amu_params->p6[0], sizeof(amu_params->p6[0])) == NULL) 
                return;
            start++;
            //p7
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p7[0]), &amu_params->p7[0], sizeof(amu_params->p7[0])) == NULL) 
                return;
            start++;
            //p8
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p8[0]), &amu_params->p8[0], sizeof(amu_params->p8[0])) == NULL) 
                return;
            start++;
            //p9
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->p9[0]), &amu_params->p9[0], sizeof(amu_params->p9[0])) == NULL) 
                return;
            start++;
            //V
            for(int i = 0; i < (&amu_params->v16h[0] - &amu_params->v32f[0]); i++){
                if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->v32f[0]), &amu_params->v32f[i], sizeof(amu_params->v32f[0])) == NULL) 
                    return;
                start++;
            }
            //L
            for(int i = 0; i < (&amu_params->u[0] - &amu_params->L[0]); i++){
                if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->L[0]), &amu_params->L[i], sizeof(amu_params->L[0])) == NULL) 
                    return;
                start++;
            }
            //u
            for(int i = 0; i < (&amu_params->cmExp[0] - &amu_params->u[0]); i++){
                if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->u[0]), &amu_params->u[i], sizeof(amu_params->u[0])) == NULL) 
                    return;
                start++;
            }
            // cmExp
            if(memcpy(&amu->ADR_reserved0[0] + start*sizeof(amu_params->cmExp[0]), &amu_params->cmExp[0], sizeof(amu_params->cmExp[0])) == NULL) 
                return;
            start++;

            break;
        case 1:
            // SDMA (also called eDMA) use case
            // In this example, it is assumed the processor has created the appropriate data structure in
            // system Flash memory so that the System DMA can perform the data load into the ARAM
            // plus the initialization of the pointer and parameter registers.
            // The SDMA would typically require two separate TCDs (Transfer Control Descriptors): one to
            // perform the data move from system Flash into the ARAM, and a second to load the
            // programming model registers. The SDMA can use the scatter/gather feature to process the
            // two TCDs in a single channel, or 2 channels can be used where the first channel performing
            // the data move “links” to the second channel performing the register loads. In any case, the
            // second data transfer loads the programming model using an 80-byte block transfer. Using
            // CH0 as an example, this block data transfer writes from the AMU2_P1PTRCHn register
            // (offset address 0x1_0010) to the AMU2_CCR2CHn registers (offset address 0x1_005c)
            // before beginning the actual calculation.
            // It should be noted the programming model of the AMU2 is organized such that an optimized
            // 80-byte burst transfer (5 x 8-byte 8-beat bursts) can be used to load the registers. The
            // optimized block transfer does not include the AMU2_NCHn register for two reasons:
            // 1. The use of the N crossing functionality is a debug feature and not intended for normal
            // system operation;
            // 2. The inclusion of the AMU2_NCHn functionality must be properly enabled by setting
            // AMU2_CCR2CHn[ENCRS] = 1. Stated differently, the AMU2_NCHn functionality is
            // completely disabled if AMU2_CCR2CHn[ENCRS] = 0. In the optimized block transfer,
            // the AMU2_NCHn register does not need to be initialized, and AMU2_CCR2CHn
            // register (with ENCRS = 0) is always the last register written.
            // Note, the AMU2_NCHn register can be included in the sequential data transfer for the
            // register writes by increasing the total number of bytes to be transferred to 84 and using 32-
            // bit writes.
            // As before, the AMU completion and error indicators are configured to generate interrupts to
            // the processor; the calculation actually begins when the AMU2_CCR2CHn[S1SRT, S23SRT]
            // bits are set by the SDMA’s last transfer.
            // The channel performs the calculation and generates an interrupt, signaling a successful
            // completion or some type of error termination or an N crossing debug event.
            // As the processor handles the interrupt, the 64-bit double precision result
            // (AMU2_RES64{M,L}CHn) is retrieved along with the status flags in the AMU2_SEIRCHn
            // register. After processing the interrupt, the service routine clears the interrupt source by
            // writing a “1” to clear the appropriate flag in the low-order byte of the AMU2_SEIRCHn
            // register. The processor then performs any required analysis of the status indicators before
            // saving the result.

            // eDMA usage example and impl. for ARAM

            // To perform a simple transfer of n bytes of data with one activation, set the major loop to one
            // (TCDn_CITER = TCDn_BITER = 1). The data transfer begins after the channel service
            // request is acknowledged and the channel is selected to execute. After the transfer is
            // complete, the TCDn_CSR[DONE] bit is set and an interrupt generates if properly enabled.

            // A typical initialization of the eDMA has the following sequence:
            // 1. Write the CR register if a configuration other than the default is desired.
            // 2. Write the channel priority levels into the DCHPRIn registers if a configuration other than
            // the default is desired.
            // 3. Enable error interrupts in the EEI registers if so desired.
            // 4. Write the 32-byte TCD for each channel that may request service.
            // 5. Enable any hardware service requests via the ERQ register.
            // 6. Request channel service by software (setting the TCDn_CSR[START] bit) or hardware
            // (slave device asserting its eDMA peripheral request signal).

            // For example, the following TCD entry is configured to transfer 16 bytes of data. The eDMA
            // is programmed for one iteration of the major loop, transferring 16 bytes per iteration. The
            // source memory has a byte wide memory port located at 0x1000. The destination memory
            // has a 32-bit-wide port located at 0x2000. The address offsets are programmed in
            // increments to match the transfer size: one byte for the source and four bytes for the
            // destination. The final source and destination addresses are adjusted to return to their
            // beginning values.

            // TCDn_CITER = TCDn_BITER = 1
            // TCDn_NBYTES = 16
            // TCDn_SADDR = 0x1000
            // TCDn_SOFF = 1
            // TCDn_ATTR[SSIZE] = 0
            // TCDn_SLAST = -16
            // TCDn_DADDR = 0x2000
            // TCDn_DOFF = 4
            // TCDn_ATTR[DSIZE] = 2
            // TCDn_DLAST_SGA= –16
            // TCDn_CSR[INT_MAJ] = 1
            // TCDn_CSR[START] = 1 (Should be written last after all other fields have
            // been initialized)
            // All other TCDn fields = 0

            // Besides transferring 32 bytes via two hardware requests, the next example is the same as
            // the previous one. The only fields that change are the major loop iteration count and the final
            // address offsets. The eDMA is programmed for two iterations of the major loop transferring
            // 16 bytes per iteration. After the channel’s hardware requests are enabled in the ERQ
            // register, the slave device initiates channel service requests.
            // TCDn_CITER = TCDn_BITER = 2
            // TCDn_SLAST = –32
            // TCDn_DLAST_SGA = –32
            if(edma_channel < 0 || edma_channel > 63){
                return;
            }

            if(edma_0 && edma_1 == NULL){ // TBM, only ADMA ch1 has params offsets if both used
                edma_0->CH[edma_channel].TCD_CITER.B_ELINKNO.CITER |= edma_0->CH[edma_channel].TCD_BITER.B_ELINKNO.BITER |= sizeof(*amu_params);
                edma_0->CH[edma_channel].TCD_NBYTES.B_MLNO.NBYTES |= sizeof(*amu_params); // 64 bits per transfer
                edma_0->CH[edma_channel].TCD_SADDR.B.SADDR |= (vuint32_t) amu_params;
                edma_0->CH[edma_channel].TCD_SOFF.B.SOFF |= 0x00000008;
                edma_0->CH[edma_channel].TCD_ATTR.B.SSIZE |= 0b011; // 64 bits per transfer
                edma_0->CH[edma_channel].TCD_SLAST.B.SLAST |= 0x00000000;  //Adjustment value added to the source address at the completion of the major
                                                                // iteration count. This value can be applied to restore the source address to the initial
                                                                // value, or adjust the address to reference the next data structure.
                edma_0->CH[edma_channel].TCD_DADDR.B.DADDR |= (vuint32_t) &amu->ADR_reserved0;
                edma_0->CH[edma_channel].TCD_DOFF.B.DOFF |= 0x00000008;
                edma_0->CH[edma_channel].TCD_ATTR.B.DSIZE |= 0b011; // 64 bits per transfer
                edma_0->CH[edma_channel].TCD_DLASTSGA.B.DLASTSGA |= 0x00000000;//Adjustment value added to the destination address at the completion of the major
                                                                    // iteration count. This value can be applied to restore the destination address to the
                                                                    // initial value, or adjust the address to reference the next data structure.
                edma_0->CH[edma_channel].TCD_CSR.B.START |= 0x00000001;
                while(edma_0->CH[edma_channel].TCD_CSR.B.DONE == 0b1); 
            } else if (edma_0 == NULL && edma_1 ){  // TBM, only ADMA ch1 has params offsets if both used
                edma_1->CH[edma_channel].TCD_CITER.B_ELINKNO.CITER |= edma_1->CH[edma_channel].TCD_BITER.B_ELINKNO.BITER |= sizeof(*amu_params);
                edma_1->CH[edma_channel].TCD_NBYTES.B_MLNO.NBYTES |= sizeof(*amu_params); // 64 bits per transfer
                edma_1->CH[edma_channel].TCD_SADDR.B.SADDR |= (vuint32_t) amu_params;
                edma_1->CH[edma_channel].TCD_SOFF.B.SOFF |= 0x00000008;
                edma_1->CH[edma_channel].TCD_ATTR.B.SSIZE |= 0b011; // 64 bits per transfer
                edma_1->CH[edma_channel].TCD_SLAST.B.SLAST |= 0x00000000;  //Adjustment value added to the source address at the completion of the major
                                                                // iteration count. This value can be applied to restore the source address to the initial
                                                                // value, or adjust the address to reference the next data structure.
                edma_1->CH[edma_channel].TCD_DADDR.B.DADDR |= (vuint32_t) &amu->ADR_reserved0;
                edma_1->CH[edma_channel].TCD_DOFF.B.DOFF |= 0x00000008;
                edma_1->CH[edma_channel].TCD_ATTR.B.DSIZE |= 0b011; // 64 bits per transfer
                edma_1->CH[edma_channel].TCD_DLASTSGA.B.DLASTSGA |= 0x00000000;//Adjustment value added to the destination address at the completion of the major
                                                                    // iteration count. This value can be applied to restore the destination address to the
                                                                    // initial value, or adjust the address to reference the next data structure.
                edma_1->CH[edma_channel].TCD_CSR.B.START |= 0x00000001;
                while(edma_1->CH[edma_channel].TCD_CSR.B.DONE == 0b1);
            } else {
                return;
            }
            

            break;
        case 2:
            // ADMA (three possible) use cases (last case implemented, consider previous peripherals impls for case 2 and 3)
            // 1) Single calculation using SDMA + ADMA for data load, CPU for post-processing
            // For this case, it is assumed the processor has created the appropriate data structure in
            // system Flash memory so that the System DMA and the ADMA collectively can perform the
            // data load into the ARAM plus the initialization of the pointer and parameter registers.
            // In this example, let the ADMA move the U[*] vector into the ARAM and the SDMA move all
            // the rest of the data.
            // The SDMA would typically require two separate TCDs (Transfer Control Descriptors): one to
            // perform the data move from system Flash into the ARAM, and a second to load the
            // programming model registers. The SDMA can use the scatter/gather feature to process the
            // two TCDs in a single channel, or 2 channels can be used where the first channel performing
            // the data move “links” to the second channel performing the register load. The second data
            // transfer loads the programming model using an 80-byte (5 x 16 byte 4-beat bursts) block
            // transfer. Using CH0 as an example, this block data transfer writes from the
            // AMU2_P1PTRCHn register (offset address 0x1_0010) to the AMU2_CCR2CHn registers
            // (offset address 0x1_005c) before beginning the actual calculation. In this example, the
            // programming model initialization configures the ADMA to move the U[*] vector into the
            // ARAM and the AMU2_CCR2CHn[WFDS1, WFDS23] conditional start bits are set (and
            // [S1SRT, S23SRT] cleared) to signal the start of the calculation engine is dependent on the
            // completion of the ADMA.
            // As before, the AMU completion and error indicators are configured to generate interrupts to
            // the processor; the calculation actually begins when the ADMA completes the data transfer
            // of the U[*] vector into the ARAM.
            // The channel performs the calculation and generates an interrupt, signaling a successful
            // completion or some type of error termination or an N crossing debug event.
            // As the processor handles the interrupt, the 64-bit double precision result
            // (AMU2_RES64{M,L}CHn) is retrieved along with the status flags in the AMU2_SEIRCHn
            // register. After processing the interrupt, the service routine clears the interrupt source by
            // writing a “1” to clear the appropriate flag in the low-order byte of the AMU2_SEIRCHn
            // register. The processor then performs any required analysis of the status indicators before
            // saving the result.
            // 2) Single calculation using SDMA for partial data load, streaming ADMA for V[*], CPU for post-processing
            // For this case, it is assumed the processor has created the appropriate data structure in
            // system Flash memory so that the System DMA can perform the partial data load into the
            // ARAM plus the initialization of the pointer and parameter registers.
            // In this example, let the ADMA use the special data streaming mode to fetch the V[*] array
            // into the ARAM with the SDMA moving all the rest of the data including the programming
            // model register initialization.
            // The SDMA would typically require two separate TCDs (Transfer Control Descriptors): one to
            // perform the data move from system Flash into the ARAM, and a second to load the
            // programming model registers. The SDMA can use the scatter/gather feature to process the
            // two TCDs in a single channel, or 2 channels can be used where the first channel performing
            // the data move “links” to the second channel performing the register load. In any case, the
            // second data transfer loads the programming model using an 80-byte (5 x 16 byte 4-beat
            // bursts) block transfer. Using CH0 as an example, this block data transfer writes from the
            // AMU2_P1PTRCHn register (offset address 0x1_0010) to the AMU2_CCR2CHn registers
            // (offset address 0x1_005c) before beginning the actual calculation. In this scenario, the
            // programming model initialization configures the ADMA to stream the V[*] array into the
            // ARAM by setting both AMU2_DCCRCHn[STMV{32,16}, SRT] and the
            // AMU2_CCR2CHn[S1SRT, S23SRT] indicators set to signal the start of the calculation
            // engine for this special data streaming mode.
            // As before, the AMU completion and error indicators are configured to generate interrupts to
            // the processor; the calculation is paced by the availability of V[*] input data being managed
            // by the ADMA.
            // The channel performs the calculation and generates an interrupt, signaling successful
            // completion or some type of error termination or an N crossing debug event.
            // As the processor handles the interrupt, the 64-bit double precision result
            // (AMU2_RES64{M,L}CHn) is retrieved along with the status flags in the AMU2_SEIRCHn
            // register. After processing the interrupt, the service routine clears the interrupt source by
            // writing a “1” to clear the appropriate flag in the low-order byte of the AMU2_SEIRCHn
            // register. The processor then performs any required analysis of the status indicators before
            // saving the result.
            // As detailed in Section 88.3.6.4: ADMA V and P3 Data Streaming Modes, the AMU2
            // supports streaming of V or P3, or both, concurrently. Additionally, neither the checksum nor
            // the ADMA speed control is supported in this mode. Additionally for this case, the
            // AMU2_VPTRCHn register must be reloaded before the next calculation.
            // 3) Multiple calculations using ADMA for partial data load, SDMA for result retrieval
            // For this example, let a processor or system DMA perform the initial data and programming
            // model register load, and configuring the AMU2 for the first calculation. Next, configure the
            // ADMA to perform repeated loads of the second, third, fourth, … last U[*] vectors and the
            // SDMA to retrieve results as each calculation is finished.
            // For this scenario, the ADMA would load a data structure from Flash (or a calibration
            // remapped destination memories, or both) having the U[*] vectors and the values for the
            // AMU2_CCR{1,2}CHn registers. The configuration sequences through the Flash data
            // structure and loads each U[*] vector into the same ARAM locations for all calculations.
            // Consider the following sequence of events:
            // 1. A processor or system DMA loads the initial data set and initializes the programming
            // model registers. The initial register load sets AMU2_DCCRCHn[WFDNI] to delay the
            // fetching of the next (2nd) U[*] until the first calculation is complete. Additionally, the
            // ADMA is configured to load the next U[*] input vector and the AMU2_CCR{1,2}CHn
            // registers by setting AMU2_DCCRCHn[SARU, DARU] = [0b10, 0b01]. Finally, as part of
            // the initial register writes, AMU2_CCR1CHn[DNICFG] = 0b10 to generate a SDMA
            // request after the ALU calculation completes, and AMU2_CCR2CHn[S1SRT, S23SRT]
            // = 1,1 to start the first calculation.
            // 2. As the first complete calculation finishes, the assertion of AMU2_SEIRCHn[DNIRQ] is
            // configured to assert an SDMA request and initiate the ADMA to fetch the next U[*]
            // vector from Flash and writing it into the same ARAM locations. Since
            // AMU2_DCCRCHn[DARU] = 0b01, the last 64 bits of fetch data are written into the
            // AMU2_CCR{1,2}CHn registers. The write sets AMU2_CCR2CHn[WFDS1, WFSS23] =
            // 1,1 to conditionally start the second calculation when the ADMA completes the new
            // U[*] fetch. The ADMA fetch also needs to set AMU2_CCR2CHn[ADCCR25] =
            // AMU2_DCCRCHn[WFDNI] = 1 on all data sets except the final iteration. The SDMA
            // responds by copying the AMU2_RES64{M,L}CHn and AMU2_SEIRCHn registers into
            // system RAM; the AMU2_SEIRCHn[DNIRQ] indicator is cleared by the SDMA
            // acknowledge.
            // 3. The process continues with the ALU performing the calculation, the ADMA fetching a
            // new U[*] vector, and the SDMA copying the 64-bit result and status into system RAM
            // until the last U[*] vector is fetched from Flash. The final value loaded into
            // AMU2_CCR1CHn[DNICFG]
            
            // TBM, needed both channels to be used
            for(int i = 0; i < adma_channels->num_used_channels;i++){
                if(adma_channels->channels[i] > 2)
                    return;
                counter++;
            }
            if(counter != adma_channels->num_used_channels)
                return;
            start=1;
            if(adma_channels->num_used_channels == 1){
                // p1
                for(int i = 0; i < &amu_params->p2[0] - &amu_params->p1[0]; i++){
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p1[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[0].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                }
                // p2
                for(int i = 0; i < &amu_params->p3[0] - &amu_params->p2[0]; i++){
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &(amu_params->p2[i]) >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                }
                //p3
                for(int i = 0; i < &amu_params->p4[0] - &amu_params->p3[0]; i++){
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &(amu_params->p3[i]) >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                }
                //p4
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p4[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                start++;
                //p5
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p5[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                start++;
                //p6
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p6[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                start++;
                //p7
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p7[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                start++;
                //p8
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p8[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                start++;
                //p9
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->p9[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                start++;
                //V
                for(int i = 0; i < &amu_params->L[0] - &amu_params->v32f[0]; i++){
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->v32f[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                }
                //L
                for(int i = 0; i < &amu_params->u[0] - &amu_params->L[0] ; i++){
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->L[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                }
                //U
                for(int i = 0; i < &amu_params->cmExp[0] - &amu_params->u[0] ; i++){
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->u[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                }
                // cmExp
                if(start > sizeof(amu->ADR_reserved0)/2)
                    return;
                amu->CH[adma_channels->channels[0]].DSACH.B.PTR = (vuint32_t) &amu_params->cmExp[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                amu->CH[adma_channels->channels[0]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                amu->CH[adma_channels->channels[0]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                while(amu->CH[adma_channels->channels[0]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                amu->CH[adma_channels->channels[0]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                
                // y and z are results given from config registers
            }else{
                for(int i = 0; i< adma_channels->num_used_channels; i++){
                    // p1
                    for(int i = 0; i < &amu_params->p2[0] - &amu_params->p1[0]; i++){
                        if(start > sizeof(amu->ADR_reserved0)/2)
                            return;
                        amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p1[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                        amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                        while(amu->CH[0].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                        amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                        start++;
                    }
                    // p2
                    for(int i = 0; i < &amu_params->p3[0] - &amu_params->p2[0]; i++){
                        if(start > sizeof(amu->ADR_reserved0)/2)
                            return;
                        amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &(amu_params->p2[i]) >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                        amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                        while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                        amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                        start++;
                    }
                    //p3
                    for(int i = 0; i < &amu_params->p4[0] - &amu_params->p3[0]; i++){
                        if(start > sizeof(amu->ADR_reserved0)/2)
                            return;
                        amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &(amu_params->p3[i]) >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                        amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                        while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                        amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                        start++;
                    }
                    //p4
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p4[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                    //p5
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p5[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                    //p6
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p6[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                    //p7
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p7[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                    //p8
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p8[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                    //p9
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->p9[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    start++;
                    //V
                    for(int i = 0; i < &amu_params->L[0] - &amu_params->v32f[0]; i++){
                        if(start > sizeof(amu->ADR_reserved0)/2)
                            return;
                        amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->v32f[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                        amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                        while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                        amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                        start++;
                    }
                    //L
                    for(int i = 0; i < &amu_params->u[0] - &amu_params->L[0] ; i++){
                        if(start > sizeof(amu->ADR_reserved0)/2)
                            return;
                        amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->L[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                        amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                        while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                        amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                        start++;
                    }
                    //U
                    for(int i = 0; i < &amu_params->cmExp[0] - &amu_params->u[0] ; i++){
                        if(start > sizeof(amu->ADR_reserved0)/2)
                            return;
                        amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->u[i] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                        amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                        amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                        while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                        amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                        start++;
                    }
                    // cmExp
                    if(start > sizeof(amu->ADR_reserved0)/2)
                        return;
                    amu->CH[adma_channels->channels[i]].DSACH.B.PTR = (vuint32_t) &amu_params->cmExp[0] >> 3; // ADMA source 8-byte aligned pointer into the system Flash region (including remapped accesses into on- and off-chip calibration memories or system RAM, or both).
                    amu->CH[adma_channels->channels[i]].DCNTCH.B.BCNT = (vuint32_t) 1; // Size of the memory to be updated each time (1 = 64 bits modified) (max 8 = 16 registers, but in the end max is 4 because otherwise repeated bits to arrive to max elements added)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000; // ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA stops, this indicator is cleared (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.CADS = (vuint32_t) 1; // Reset the ADMA status state machines to idle (requested for start)
                    amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT = (vuint32_t) 1; // This assertion of a properly-qualified start condition ((SRT == 1) && (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers
                    while(amu->CH[adma_channels->channels[i]].SEIRCH.B.ADMAS == 0b11); // ADMA Running or stalled
                    amu->CH[adma_channels->channels[i]].DDACH.B.PTR = (vuint32_t) start; // ADMA (offset) destination address in the ARAM (from 0 to max 0x07FFF => 32767 => 32768 / 16 = 2048)
                    
                    // y and z are results given from config registers
                }
                
            }
            break;
        default:
            return;
    }  
    for(int i=0;i<adma_channels->num_used_channels;i++){
        // TBM, use controls based on size in ARAM from not using ADMA for data transfer
        vuint32_t * p = &amu->ADR_reserved0[0] + 4;
        amu->CH[adma_channels->channels[i]].P1PTRCH.B.PTR = (vuint32_t) ( (vuint32_t) p & 0x7FFF) >> 2; 
        p += (vuint8_t) (&amu_params->p2[0] - &amu_params->p1[0])*2; // consider dim to have # of elements in the space and then *2 because of 64 bits alignment (1 element in 32 bits, other space for ADMA insert from flash in ARAM)
        amu->CH[adma_channels->channels[i]].P2PTRCH.B.PTR = (vuint32_t) ( (vuint32_t) p & 0x7FFF) >> 2;
        p += (vuint8_t) (&amu_params->p3[0] - &amu_params->p2[0])*2;
        if(p3StreamingEnabled)
            amu->CH[adma_channels->channels[i]].P3PTRCH.B.PTR = (vuint32_t) &amu_params->p3[0] >> 2;
        else{
            amu->CH[adma_channels->channels[i]].P3PTRCH.B.PTR = (vuint32_t) ( (vuint32_t) p  & 0x7FFF) >> 2; 
        }
        p += (vuint8_t) (&amu_params->p4[0] - &amu_params->p3[0])*2;
        amu->CH[adma_channels->channels[i]].P4CH.B.IEEE = (vuint32_t) *p;
        // memcpy(amu->CH[adma_channels->channels[i]].P4CH.B.IEEE,p,sizeof(p));
        p += (&amu_params->p5[0] - &amu_params->p4[0])*2;
        amu->CH[adma_channels->channels[i]].P5CH.B.IEEE = *p;
        p += (&amu_params->p6[0] - &amu_params->p5[0])*2;
        // amu->CH[adma_channels->channels[i]].P6CH.B.UINT = (vuint32_t) *p ; // not writable, used by exec stage
        p += (&amu_params->p7[0] - &amu_params->p6[0])*2;
        amu->CH[adma_channels->channels[i]].P7CH.B.UINT = (vuint32_t) *p;
        p += (&amu_params->p8[0] - &amu_params->p7[0])*2;
        // amu->CH[adma_channels->channels[i]].P8CH.B.UINT = (vuint32_t) *p ; // not writable, used by exec stage
        p += (&amu_params->p9[0] - &amu_params->p8[0])*2;
        p -= sizeof(amu_params->p9[0])/2;
        amu->CH[adma_channels->channels[i]].P9MCH.B.IEEE64 = (vuint32_t) *p; // TBM, should be zero in test code
        p += sizeof(amu_params->p9[0])/2;
        amu->CH[adma_channels->channels[i]].P9LCH.B.IEEE64 = (vuint32_t) *p;
        // checks on v16 and vfh have to be done, otherwise 0 and so no add needed
        if(amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV16 || amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV32 || VStreamingEnabled){
            if(amu->CH[adma_channels->channels[i]].CCR1CH.B.V16 && amu->CH[adma_channels->channels[i]].CCR1CH.B.VFH==0) // 16-bit half-precision format
                amu->CH[adma_channels->channels[i]].VPTRCH.B.PTR = (vuint32_t) &amu_params->v16h[0] >> 2;  // from flash
            else if(amu->CH[adma_channels->channels[i]].CCR1CH.B.V16 && amu->CH[adma_channels->channels[i]].CCR1CH.B.VFH) // 16-bit fixed-point format with a common 7-bit biased exponent
                amu->CH[adma_channels->channels[i]].VPTRCH.B.PTR = (vuint32_t) &amu_params->v16x[0] >> 2;  // from flash
            else // 32-bit single-precision format
                amu->CH[adma_channels->channels[i]].VPTRCH.B.PTR = (vuint32_t) &amu_params->v32f[0] >> 2;  // from flash
        }else{
            if(amu->CH[adma_channels->channels[i]].CCR1CH.B.V16 && amu->CH[adma_channels->channels[i]].CCR1CH.B.VFH==0)
                p += (&amu_params->v16h[0] - &amu_params->p9[0])*2;
            else if(amu->CH[adma_channels->channels[i]].CCR1CH.B.V16 && amu->CH[adma_channels->channels[i]].CCR1CH.B.VFH)
                p += (&amu_params->v16x[0] - &amu_params->p9[0])*2;
            else
                p += (&amu_params->v32f[0] - &amu_params->p9[0])*2;
            amu->CH[adma_channels->channels[i]].VPTRCH.B.PTR = (vuint32_t) (*p  & 0x7FFF) >> 2; // from ARAM
        }
        p += (&amu_params->L[0] - &amu_params->v16x[0])*2;
        amu->CH[adma_channels->channels[i]].LPTRCH.B.PTR = (vuint32_t) ( (vuint32_t) p  & 0x7FFF) >> 2;
        p += (&amu_params->u[0] - &amu_params->L[0])*2;
        amu->CH[adma_channels->channels[i]].UPTRCH.B.PTR = (vuint32_t) ( (vuint32_t) p  & 0x7FFF) >> 2;  
        p += (&amu_params->cmExp[0] - &amu_params->u[0])*2;

        // these have to be returned based on settings, cannot be set here
        // amu_params->y32[0] = amu->CH[adma_channels->channels[i]].Y32CH.B.IEEE32;
        // amu_params->y64[0] = amu->CH[adma_channels->channels[i]].Y64MCH.B.IEEE64 + amu->CH[adma_channels->channels[i]].Y64LCH.B.IEEE64;
        // amu_params->z32[0] = amu->CH[adma_channels->channels[i]].RES32CH.B.IEEE32;
        // amu_params->z64[0] = amu->CH[adma_channels->channels[i]].RES64LCH.B.IEEE64;
        // probably should not be considered here but in conf funcs
        // amu->CH[adma_channels->channels[i]].CCR1CH.B.CMEXP = (vuint32_t) *p & 0x7;
        // p += (&amu_params->setz[0] - &amu_params->cmExp[0])*2;
        // amu->CH[adma_channels->channels[i]].CCR1CH.B.SETZ = (vuint32_t) *p & 0x1;
        // p += (&amu_params->vfh[0] - &amu_params->setz[0])*2;
        // amu->CH[adma_channels->channels[i]].CCR1CH.B.VFH = (vuint32_t) *p & 0x1;
    }
    
    // p3 and V streaming if required by user
    if(p3StreamingEnabled && VStreamingEnabled==false){
        for(int i = 0;i<adma_channels->num_used_channels; i++){
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STMP3 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT |= 1;
            while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
            amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
        }
    } else if(p3StreamingEnabled==false && VStreamingEnabled){
        if(amu->CH[0].CCR1CH.B.V16 && amu->CH[0].CCR1CH.B.VFH==0 || amu->CH[0].CCR1CH.B.V16 && amu->CH[0].CCR1CH.B.VFH){ // 16-bit half-precision format && 16-bit fixed-point format with a common 7-bit biased exponent
            for(int i = 0;i<adma_channels->num_used_channels; i++){
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV16 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT |= 1;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
            }
        }
        else{ // 32-bit single-precision format
            for(int i = 0;i<adma_channels->num_used_channels; i++){
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV32 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT |= 1;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
            }
        }
    } else if(p3StreamingEnabled && VStreamingEnabled){
        if(amu->CH[0].CCR1CH.B.V16 && amu->CH[0].CCR1CH.B.VFH==0 || amu->CH[0].CCR1CH.B.V16 && amu->CH[0].CCR1CH.B.VFH){ // 16-bit half-precision format && 16-bit fixed-point format with a common 7-bit biased exponent
            for(int i = 0;i<adma_channels->num_used_channels; i++){
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV16 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.STMP3 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT |= 1;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
            }
        }
        else{ // 32-bit single-precision format
            for(int i = 0;i<adma_channels->num_used_channels; i++){
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STMV32 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.STMP3 |= amu->CH[adma_channels->channels[i]].DCCRCH.B.SRT |= 1;
                while(amu->CH[0].SEIRCH.B.ADSTM == 0b1);
                amu->CH[adma_channels->channels[i]].DCCRCH.B.STP &= 0x00000000;
            }
        }
    }

}


void AMUExec(volatile struct AMU_tag * amu, int numUsedADMAChannels, bool p3StreamingEnabled, bool VStreamingEnabled){ // to be modified, no calculations performed, probably missing vectors in ARAM specific spaces
    // first approach, not running
    // Unconditionally start stage1 exec
    // for(int i=0;i<1;i++){
    //     amu->CH[adma_channels->channels[i]].CCR2CH.B.S23STP = 0;
    //     amu->CH[adma_channels->channels[i]].CCR2CH.B.S23SRT = 1;
    // }
    // // Wait for stage1 exec completion
    // do{
    //     // ALUstopCheckResume(amu);
    // }while(amu->CH[0].SEINCCH.B.S23XS != 0x11);
    // result is in ut, that is in ARAM on both channels
    // 0x0_7F00 0x0_7F7F 128 bytes Channel 0 ut[*] Storage
    // 0x0_7F80 0x0_7FFF 128 bytes Channel 1 ut[*] Storage
    
    // TO DO: use channels vectors streaming for s23 exec (only usable if V, U and L are defined from system flash, not in ARAM)
    // amu->CH[0].CCR1CH.B.DDSL = 1;
    
    
    // CPU only use case
    // For this scenario, a processor core performs all the required data loading, moving the
    // coefficients and parameters from system Flash into the ARAM and then initializing all the
    // corresponding pointer and parameter registers. Once the data load and register initialization
    // are completed, the calculation is started by writing the AMU2_CCR{1,2}CHn registers. In
    // this case, the AMU completion and error indicators are configured to generate interrupts to
    // the processor; the calculation actually begins when the AMU2_CCR2CHn[S1SRT, S23SRT]
    // bits are set.
    // The AMU2 performs the calculation and then typically generates an interrupt, signaling
    // successful completion or some type of error termination or an N crossing debug event.
    // As the processor handles the interrupt, the 64-bit double precision result
    // (AMU2_RES64{M,L}CHn) is retrieved along with the status flags in the AMU2_SEIRCHn
    // register. After processing the interrupt, the service routine clears the interrupt source by
    // writing a “1” to clear the appropriate flag in the low-order byte of the AMU2_SEIRCHn
    // register. The processor then performs any required analysis of the status indicators before
    // saving the result.
    // The preceding description assumes the processor is interrupted when the AMU2 completes
    // as this would be the typical scenario. The AMU2 also provides a channel busy flag
    // (AMU2_SEIRCHn[CHBSY]) that the processor can poll to determine whether the calculation
    // is finished.
    
    amu->CH[0].CCR2CH.B.CSXXS |= (vuint32_t) 0b1; // Reset both of the ALU execution state machines to idle
    amu->CH[0].CCR2CH.B.S1SRT |=  amu->CH[0].CCR2CH.B.S23SRT |= (vuint32_t) 0b1; // Once stage1 starts execution, this indicator bit is automatically cleared
    while( amu->CH[0].SEIRCH.B.S23XS == 0b11);
    amu->CH[0].CCR2CH.B.S23STP |=  (vuint32_t) 0b0;

    // go check ARAM ut vector address space for results

    /* ALU Completion State Details in AMU2_SEIRCHn  */
    // Columns (1 bit when omitted): 
    // ALU Completion State
    // S23XS (2 bits)
    // S1XS (2 bits)
    // YCAFLT
    // ZCAFLT
    // S23AFLT
    // S1AFLT
    // IDVERR
    // ECCERR
    // RGCERR
    // ERIRQ
    // OVIRQ
    // NCIRQ
    // DNIRQ
    // S1 error-free completion 00 00 0 0 0 0 0 0 0 0 0 0 1(1)
    // S1 input data validation error 00 01 0 0 0 0 1 0 0 1 0 0 0
    // S1 ECC error 00 01 0 0 0 0 0 1 0 1 0 0 0
    // S1 register conflict error 00 01 0 0 0 0 0 0 1 1 0 0 0
    // S1 overflow 00 01 0 0 0 1 0 0 0 0 1 0 0
    // S1 underflow 00 00 0 0 0 1 0 0 0 0 0 0 1(1)
    // S23 error-free completion 00 00 0 0 0 0 0 0 0 0 0 0 1
    // S23 N crossing 10 00 0 0 0 0 0 0 0 0 0 1 0
    // S23 input data validation error 01 00 0 0 0 0 1 0 0 1 0 0 0
    // S23 ECC error 01 00 0 0 0 0 0 1 0 1 0 0 0
    // S23 register conflict error 01 00 0 0 0 0 0 0 1 1 0 0 0
    // S23 overflow 01 00 0 0 1 0 0 0 0 0 1 0 0
    // S23 underflow 00 00 0 0 1 0 0 0 0 0 0 0 1
    // Final Y32 overflow 01 00 1 0 0 0 0 0 0 0 1 0 0
    // Final Y32 underflow 00 00 1 0 0 0 0 0 0 0 0 0 1
    // Z32 overflow 01 00 0 1 0 0 0 0 0 0 1 0 0
    // Z32 underflow 00 00 0 1 0 0 0 0 0 0 0 0 1

}
void AMUGetResults( volatile struct AMU_tag * amu, struct ADMAChannels_tag * adma_channels,struct AMUResults_tag * amu_results){
    if(amu == NULL || adma_channels == NULL || amu_results == NULL || adma_channels->num_used_channels==0){
        return;
    }
    unsigned int counter = 0;
    for(int i = 0; i < adma_channels->num_used_channels;i++){
        if(adma_channels->channels[i] > 2)
            return;
        counter++;
    }
    if(counter != adma_channels->num_used_channels)
        return;
    // get the results from ADMA
    for(int i = 0; i < adma_channels->num_used_channels;i++){
        amu_results->RES64L = amu->CH[adma_channels->channels[i]].RES64LCH.B.IEEE64;
        amu_results->RES64M = amu->CH[adma_channels->channels[i]].RES64MCH.B.IEEE64;
        amu_results->RES32 = amu->CH[adma_channels->channels[i]].RES32CH.B.IEEE32;
        amu_results->Y64L = amu->CH[adma_channels->channels[i]].Y64LCH.B.IEEE64;
        amu_results->Y64M = amu->CH[adma_channels->channels[i]].Y64MCH.B.IEEE64;
        amu_results->Y32 = amu->CH[adma_channels->channels[i]].Y32CH.B.IEEE32;
    }

}

void ALUstopCheckResume( volatile struct AMU_tag * amu, bool ADMACH0Used, bool ADMACH1Used){
    /* stop the ALU */
    if(ADMACH0Used == false && ADMACH1Used == false){
        return;
    }
    if(ADMACH0Used && ADMACH1Used==false){
        amu->CH[0].CCR2CH.B.S23STP |= 0b1; // set stop request
        while (amu->CH[0].SEIRCH.B.S23XS == 0b11); // wait for stop
        // 3. Check calculation progress as needed. (ex. UT, P3 and V vectors in ARAM)
        /* resume the ALU */
        amu->CH[0].CCR2CH.B.S23RSM |= 0b1; // set resume request
    } else if(ADMACH0Used==false && ADMACH1Used){
            amu->CH[1].CCR2CH.B.S23STP = 0b1; // set stop request
            while (amu->CH[1].SEIRCH.B.S23XS == 0b11); // wait for stop
            // 3. Check calculation progress as needed. (ex. UT, P3 and V vectors in ARAM)
            /* resume the ALU */
            amu->CH[1].CCR2CH.B.S23RSM |= 0b1; // set resume request
    } else {
        amu->CH[0].CCR2CH.B.S23STP |= amu->CH[1].CCR2CH.B.S23STP |= 0b1; // set stop request
        while (amu->CH[0].SEIRCH.B.S23XS == 0b11 || amu->CH[1].SEIRCH.B.S23XS == 0b11); // wait for stop
        // 3. Check calculation progress as needed. (ex. UT, P3 and V vectors in ARAM)
        /* resume the ALU */
        amu->CH[0].CCR2CH.B.S23RSM |= amu->CH[1].CCR2CH.B.S23RSM |= 0b1; // set resume request
    }
}
	

void ALUstopNewCalcRestoreResume( volatile struct AMU_tag * amu, bool ADMACH0Used, bool ADMACH1Used ){
    /* stop the ALU */
    if(ADMACH0Used == false && ADMACH1Used == false){
        return;
    }
    if(ADMACH0Used && ADMACH1Used==false){
        amu->CH[0].CCR2CH.B.S23STP |= 0b1; // set stop request
        while (amu->CH[0].SEIRCH.B.S23XS == 0b11); // wait for stop
        // 3. Temporarily save the contents of the required programming model. This includes the
        // AMU2_{P3PTR, P4, P5, P6, P7, P8, VPTR, LPTR, CCR{1,2}, Y64, RES32} registers
        // as well as the CHn UT[*] in the ARAM data FIFO.
        // 4. Load the new data set, execute the calculation, store the results as required.
        // 5. Restore the saved data contents from Step 3, including restoring the saved Y64 to P9
        // and RES32 to P5 (see Note below).
        /* resume the ALU */
        amu->CH[0].CCR2CH.B.S23RSM |= 0b1; // set resume request
    } else if(ADMACH0Used==false && ADMACH1Used){
            amu->CH[1].CCR2CH.B.S23STP = 0b1; // set stop request
            while (amu->CH[1].SEIRCH.B.S23XS == 0b11); // wait for stop
        // 3. Temporarily save the contents of the required programming model. This includes the
        // AMU2_{P3PTR, P4, P5, P6, P7, P8, VPTR, LPTR, CCR{1,2}, Y64, RES32} registers
        // as well as the CHn UT[*] in the ARAM data FIFO.
        // 4. Load the new data set, execute the calculation, store the results as required.
        // 5. Restore the saved data contents from Step 3, including restoring the saved Y64 to P9
        // and RES32 to P5 (see Note below).
            /* resume the ALU */
            amu->CH[1].CCR2CH.B.S23RSM |= 0b1; // set resume request
    } else {
        amu->CH[0].CCR2CH.B.S23STP |= amu->CH[1].CCR2CH.B.S23STP |= 0b1; // set stop request
        while (amu->CH[0].SEIRCH.B.S23XS == 0b11 || amu->CH[1].SEIRCH.B.S23XS == 0b11); // wait for stop
        // 3. Temporarily save the contents of the required programming model. This includes the
        // AMU2_{P3PTR, P4, P5, P6, P7, P8, VPTR, LPTR, CCR{1,2}, Y64, RES32} registers
        // as well as the CHn UT[*] in the ARAM data FIFO.
        // 4. Load the new data set, execute the calculation, store the results as required.
        // 5. Restore the saved data contents from Step 3, including restoring the saved Y64 to P9
        // and RES32 to P5 (see Note below).
        /* resume the ALU */
        amu->CH[0].CCR2CH.B.S23RSM |= amu->CH[1].CCR2CH.B.S23RSM |= 0b1; // set resume request
    }
}

