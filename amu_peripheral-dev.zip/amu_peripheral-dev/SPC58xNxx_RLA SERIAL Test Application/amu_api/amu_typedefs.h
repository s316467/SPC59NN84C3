#ifndef AMU_TYPEDEFS_H
#define AMU_TYPEDEFS_H
#include <stddef.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h> 
#include "typedefs.h"

// 64 bits used for memory alignment purposes, preferred max size on the right declaration

typedef vuint64_t ieee16;
typedef vuint64_t ieee32;
typedef vuint64_t ieee64;
typedef vuint64_t uint01;
typedef vuint64_t uint02;
typedef vuint64_t uint05;
typedef vuint64_t uint06;
typedef vuint64_t uint07;
typedef vuint64_t uint08;
typedef vuint64_t uint16;
#endif