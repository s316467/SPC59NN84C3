#ifndef AMU_API_H
#define AMU_API_H

#include "components.h"

#define TESTING 1

#ifdef TESTING
#include "./amu_test/amu_test.h"
#include "./amu_cfg/amu_cfg.h"
#else
#include "./amu_cfg/amu_cfg.h"
#include "./amu_typedefs.h"
#endif

#define AMU_ARAM_PARAMS_ADDR 0xF40C0000UL
#define AMU_ARAM_PARAMS_SIZE 0x7C00UL
#define ADMA_CHANNELS_MAX 2UL
#define AMU_ARAM_CH0_V_FIFO_ADDR 0xF40C7C00UL
#define AMU_ARAM_CH0_V_FIFO_SIZE 0x100UL
#define AMU_ARAM_CH1_V_FIFO_ADDR 0xF40C7D00UL
#define AMU_ARAM_CH1_V_FIFO_SIZE 0x100UL
#define AMU_ARAM_CH0_P3_FIFO_ADDR 0xF40C7E00UL
#define AMU_ARAM_CH0_P3_FIFO_SIZE 0x80UL
#define AMU_ARAM_CH1_P3_FIFO_ADDR 0xF40C7E80UL
#define AMU_ARAM_CH1_P3_FIFO_SIZE 0x80UL
#define AMU_ARAM_CH0_UT_STORAGE_ADDR 0xF40C7F00UL
#define AMU_ARAM_CH0_UT_STORAGE_SIZE 0x80UL
#define AMU_ARAM_CH1_UT_STORAGE_ADDR 0xF40C7F80L
#define AMU_ARAM_CH1_UT_STORAGE_SIZE 0x80UL
#define ARAM_TOT_USABLE_SIZE 0x8000UL // 32 KB
#define ARAM_PARAMS_SIZE 0x7C00UL // 31 KB

typedef const struct ADMAChannels_tag {
  unsigned int num_used_channels;
  unsigned int channels[ADMA_CHANNELS_MAX];
};

typedef struct AMUResults_tag {
    ieee32 RES64M;
    ieee32 RES64L;
    ieee32 RES32;
    ieee32 Y64M;
    ieee32 Y64L;
    ieee32 Y32;
};


/*
struct AMU_tag {
  vuint8_t ADR_reserved0[65536]; // RW

    //  Local ARAM Address Space
    // The 32 KB physical address space allocated to the AMU’s local RAM (ARAM) is segmented
    // into 2 regions. The first, a 31 KB space (offset addresses = 0x0_0000 - 0x0_7BFF), is
    // intended for user-defined storage of the AMU input data. The second, a 1 KB space (offset
    // addresses = 0x0_7C00 - 0x0_7FFF) is used by the AMU2 for temporary storage. This RAM
    // space is used by the calculation engines to temporarily store the UT[*] vector generated as
    // the stage1 output; additionally, it implements small FIFO memories to store “streamed data”
    // associated with the V[*] and P3[*] vectors. The specific memory allocation within this 1 KB
    // space is shown in Table 2247. Note if the streaming feature for the V[*] and P3[*] vectors is
    // not enabled, the first 768 bytes of this 1 KB space can be used for general purpose ARAM
    // data storage.
    
    // Offset Start Address  Offset End Address      Size                           Purpose
    // 0x0_7C00                0x0_7CFF            256 bytes             Channel 0 Streaming v[*] FIFO
    // 0x0_7D00                0x0_7DFF            256 bytes             Channel 1 Streaming v[*] FIFO
    // 0x0_7E00                0x0_7E7F            128 bytes             Channel 0 Streaming p3[*] FIFO
    // 0x0_7E80                0x0_7EFF            128 bytes             Channel 1 Streaming p3[*] FIFO
    // 0x0_7F00                0x0_7F7F            128 bytes             Channel 0 ut[*] Storage
    // 0x0_7F80                0x0_7FFF            128 bytes             Channel 1 ut[*] Storage
    
    // Given the 32 KB physical address space associated with the ARAM, all the pointers for this
    // memory are implemented as 15-bit byte addresses that define the offset into the local
    // memory. These local memory pointers are restricted to reference data items on their natural
    // size boundaries, for example, with a 0-modulo-2 byte addresses (2-byte aligned) for 16-bit
    // data, 0-modulo-4 byte addresses (4-byte aligned) for 32-bit data and 0-modulo-8 byte
    // addresses (8-byte aligned) for 64-bit data. Additionally, software must manage the pointer
    // values near the end of the address ranges as the hardware pointer calculations do not
    // perform any special handling near the 31 KB or 32 KB boundaries.

    // Concerning the alignment of streamed V[*] or P3[*] data in their FIFOs, it should be noted
    // that if the streamed data starts at offset 8 or 24 within the 32-byte Flash page, the first
    // doubleword of data is stored at offset 8 in the associated FIFO, else it is stored at offset 0.
    // During normal usage, this is completely transparent, but may be of interest during AMU
    // debug if the contents of the FIFOs are examined.
    // If the ARAM is protected from single bit errors by enabling the ECC logic, it is the system’s
    // responsibility to initialize its contents with correct ECC before any AMU calculations are
    // performed. This initialization can be performed by the system DMA performing 16-byte burst
    // transfers to write the entire contents of the ARAM, using the memory initialization feature of
    // the ADMA, or using the ADMA to load the entire memory from Flash. If the system DMA is
    // used for ARAM initialization, both AMU2_CCR1CH{0,1}[EECC] configuration bits must be
    // cleared until the initialization is complete.
    // Finally, it should be noted that the two 32-bit Control & Configuration Registers are treated
    // in a special manner when configured as the last destination of an ADMA transfer. The
    // AMU2_DCCRCHn[DARU] provides this specific configuration. For example, when
    // configured with DARU = 0b01, the last 64-bit ADMA transfer associated with channel 0
    // writes to the CCR{1,2}CH0 registers to initiate an ALU calculation. Likewise, the last 64-bit
    // ADMA transfer associated with channel 1 could write to the CCR{1,2}CH1 registers. This
    // mechanism allows the basic data block transfer controlled by the ADMA to load new input
    // data into the ARAM and then initiate a calculation by writing to the CCR{1,2}CHn registers.
    
  struct {
    union {
      vuint32_t R; // Reset Value (=0x00000002 for CH0, =0x0001_0002 for CH1)
      struct {
          vuint32_t unused_1:15;
          vuint32_t CH:1;
          // Channel number, n (n = 0 to 1)
          // 0 Channel 0
          // 1 Channel 1 
          vuint32_t unused_0:12;
          vuint32_t VER:4;
          // AMU version number
          // This implementation is Version 2.
        } B;
    } IDVCH;

    vuint8_t AMU_reserved1[8];

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t NMSK:16;
            // N crossing Mask. This field provides the ability to mask individual bits in the N crossing
            // comparison. If set, the bit is ignored in the equality comparison comparing the N crossing value
            // and the outer loop iteration count from stage2 of the algorithm.
            // if NMSK[i] == 0, then the corresponding bit in NCRS[i] is included in the comparison
            // if NMSK[i] == 1, then the corresponding bit in NCRS[i] is excluded (masked) in the comparison
            vuint32_t NCRS:16;
            // N crossing value (unsigned integer). When enabled by AMU2_CCR2CHn[ENCRS], the stage2
            // calculation is stopped after the masked NCRS iterations of the outer loop. After the calculation is
            // stopped, the p8 outer loop count contains an NCRS+1 value in this register. The intermediate
            // value contained in the y64 register is consistent with this p8/NCRS value. Additionally, if the
            // AMU2_CCR1CHn[NCICFG] is set to an appropriate value, an interrupt or a DMA request is
            // triggered when the outer loop count reaches the masked NCRS value. The interrupt
            // enable/disable control is independent of the AMU2_CCR2CHn[ENCRS] setting.
            // The equality comparison is defined as:
            // N crossing_event = ((p8[15:0] | NMSK[15:0]) == (NCRS[15:0] | NMSK[15:0]))
            // where “|” is the boolean OR operator.
        } B;
    } NCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_1:17;
            vuint32_t PTR:13; 
            // Pointer into ARAM for the p1[*] vector. PTR[14:0] is a byte address. Since this array contains
            // aligned 32-bit data elements, the two least significant address bits are fixed at zero.
            vuint32_t unused_0:2;
        } B;
    } P1PTRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_1:17;
            vuint32_t PTR:13;
            // Pointer into ARAM for the p2[*] vector. PTR[14:0] is a byte address. Since this array contains
            // aligned 32-bit data elements, the two least significant address bits are fixed at zero.
            vuint32_t unused_0:2;
        } B;
    } P2PTRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t PTR:30;
            // Pointer for the p3[*] vector. Depending on the data mode for the p3[*] vector, this field is used in
            // two different ways:
            // if AMU2_DCCRCHn[STMP3] = 0, then PTR[14:2] defines offset pointer into ARAM
            // if AMU2_DCCRCHn[STMP3] = 1, then PTR[31:3] defines system Flash address
            // PTR[31:0] is a byte address. The two least significant address bits are fixed at zero to enforce 4-
            // byte (32 bit) alignment for the non-streaming configuration and the low-order three bits are forced
            // to zero for the streaming configuration.
            vuint32_t unused_0:2;
        } B;
    } P3PTRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE:32;
            // Parameter p4 value in IEEE 32-bit floating-point format. This value remains static once written.
        } B;
    } P4CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE:32;
            //  Parameter p5 value in IEEE 32-bit floating-point format. This value remains static once written.
        } B;
    } P5CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_0:16;
            vuint32_t UINT:16;
            // Parameter p6 value in a 16-bit unsigned integer format.
        } B;
    } P6CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_0:27;
            vuint32_t UINT:5;
            // Parameter P7 value in a 5-bit unsigned integer format. A 0b00000 in this field
            // means P7 = 32.
        } B;
    } P7CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t THRHC:16;
            // Threshold Count. This 16-bit unsigned integer defines the threshold count used in
            // the ALU speed control function. There are additional control fields associated with
            // this function in the AMU2_CCR1CHn register. There is a single ALU speed control
            // function shared by the calculation engine and accessible from either the CH0 or
            // CH1 programming models.
            vuint32_t UINT:16;
            // Parameter p8 value in a 16-bit unsigned integer format.
        } B;
    } P8CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE64:32;
            // Most significant word of parameter p9 value in IEEE 64-bit floating-point format.
            // This is the P9MCHn register.
        } B;
    } P9MCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE64:32;
            // Least significant word of parameter p9 value in IEEE 64-bit floating-point format. This is the
            // P9LCHn register.
        } B;
    } P9LCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t PTR:30;
            // Pointer for the v[*] array. Depending on the data mode for the v[*] array, this field is
            // used in two different ways:
            // – if AMU2_DCCRCHn[STMV{32,16}] == 00, then PTR[14:2] is offset pointer into
            // ARAM.
            // – if AMU2_DCCRCHn[STMV{32,16}] != 00, then PTR[31:3] is system Flash
            // address.
            // PTR[31:0] is a byte address. The two least significant address bits are fixed at zero
            // to enforce 4-byte (32 bit) alignment for the non-streaming configuration and the
            // low-order three bits are forced to zero for the streaming configuration.
            vuint32_t unused_0:2;
        } B;
    } VPTRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_1:17;
            vuint32_t PTR:13;
            // Pointer into ARAM for the L[*] vector. PTR[14:0] is a byte address. Since this array
            // contains aligned 32-bit data elements, the two least significant address bits are
            // fixed at zero.
            vuint32_t unused_0:2;
        } B;
    } LPTRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_1:17;
            vuint32_t PTR:13;
            // Pointer into ARAM for the u[*] vector. PTR[14:0] is a byte address. Since this array contains
            // aligned 32-bit data elements, the two least significant address bits are fixed at zero.
            vuint32_t unused_0:2;
        } B;
    } UPTRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t PTR:29;
            // ADMA source address in Flash region of the system memory map. For best
            // performance and efficiency, this byte address is forced to doubleword (8-byte
            // aligned) alignment, matching the AMU’s private interface to the Flash controller.
            vuint32_t unused_0:3;
        } B;
    } DSACH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_1:17;
            vuint32_t PTR:12;
            // ADMA destination address in the ARAM. For best performance and efficiency, this
            // byte address is enforced to a doubleword (8-byte aligned) alignment, matching the
            // AMU’s private interface to the Flash controller.
            vuint32_t unused_0:3;
        } B;
    } DDACH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t THRHC:11;
            // Threshold Count. This 16-bit unsigned integer defines the threshold count used in
            // the ADMA speed control function. There are additional control fields associated
            // with this function in the AMU2_DCCRCHn register. There is a single ADMA speed
            // control function shared by both channels and accessible from either the CH0 or
            // CH1 programming models.
            // The count is forced to be 32-byte aligned to match the ADMA’s fetch size from the
            // system Flash private connection.
            vuint32_t unused_1:5;
            vuint32_t BCNT:13;
            // ADMA transfer byte count in a 16-bit unsigned integer format and forced to be an
            // 8-byte aligned count.
            vuint32_t unused_0:3;
        } B;
    } DCNTCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t UINT:32;
            // Expected ADMA checksum in a 32-bit unsigned integer format.
        } B;
    } DCKSCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_2:1;
            vuint32_t SRTSP:3;
            // Start Speed
            // This 3-bit encoded value defines the start speed for the ADMA channel. It is used with
            // the MAXSP field and AMU2_DCNTCHn[THRHC] with the current speed of the ADMA is
            // reported in AMU2_SEIRCHn[DCURSP].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels and accessible from either the CH0 or
            // CH1 programming models.
            // 000 Maximum speed; speed control disabled
            // 001 1/8 speed
            // 010 2/8 speed
            // 011 3/8 speed
            // 100 4/8 speed
            // 101 5/8 speed
            // 110 6/8 speed
            // 111 7/8 speed
            vuint32_t unused_1:1;
            vuint32_t MAXSP:3;
            // Maximum Speed
            // This 3-bit encoded value defines the maximum speed for the ADMA channel. It is used
            // with the SRTSP field and AMU2_DCNTCHn[THRHC] with the current speed of the
            // ADMA is reported in AMU2_SEIRCHn[DCURSP].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels and accessible from either the CH0 or
            // CH1 programming models.
            // This field uses the same definition as SRTSP above.
            vuint32_t ADICFG:2;
            // ADma Interrupt ConFiGuration
            // This 2-bit field provides the reporting mechanism associated with the ADMA complete
            // indicator flag (AMU2_SEIRCHn[ADIRQ]).
            // 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ADMA completion
            // 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software
            // 10 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
            // acknowledgement
            // 11 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
            // acknowledgement
            vuint32_t SARU:2;
            // Source Address Register Update
            // This 2-bit field controls the updating of the AMU2_DSACHn register.
            // 00 ADMA does not modify the original starting value of AMU2_DSACHn
            // 01 ADMA does not modify the original starting value of AMU2_DSACHn
            // 10 ADMA increments the AMU2_DSACHn as the data transfer occurs. The final value
            // points to the next 8-byte aligned system Flash address
            // 11 ADMA increments the AMU2_DSACHn as the data transfer occurs and, after the final
            // transfer, “rounds up” to the next 32-byte aligned system Flash page address
            vuint32_t DARU:2;
            // Destination Address Register Update
            // This 2-bit field controls the updating of the AMU2_DDACHn register.
            // 00 ADMA does not modify the original starting value of AMU2_DDACHn
            // 01 ADMA uses AMU2_DDACHn + the current byte counter as the ARAM write address
            // as each data transfer occurs except for the final 8-byte transfer. Both the
            // AMU2_DDACHn and AMU2_DCNTCHn register values are unchanged. This value
            // enables the special ADMA transfer where the last 8 bytes are not written into the
            // ARAM, but instead are written into the AMU2_CCR{1,2}CHn registers. For this mode,
            // the contents of AMU2_DCNTCHn defines the total number of data bytes to be
            // transferred + 8 (for the final 8-byte transfer to the AMU2_CCR{1,2}CHn). Additionally,
            // if DCCRCHn[DECC] = 0, any required single-bit corrections on the fetched data,
            // including that destined for AMU2_CCR{1,2}CHn, are performed before being
            // forwarded to the destination (either the ARAM or the control & configuration
            // registers). If a non-correctable ECC event is detected on the last 64-bit data fetch, the
            // update of the AMU2_CCR{1,2}CHn registers is not performed to avoid any
            // inadvertent ALU activity
            // 10 ADMA increments the AMU2_DDACHn as each data transfer occurs including the
            // last transfer. The final value points to the next 8-byte aligned ARAM address
            // 11 ADMA increments the AMU2_DDACHn as each data transfer occurs including the
            // last transfer. The final value points to the next 8-byte aligned ARAM address
            vuint32_t HCRCE:1;
            // Halt on Cyclic Redundancy Check Error
            // This bit determines the AMU2’s response to a properly-enabled (ECRC == 1) CRC
            // checksum error.
            // 0 AMU2 continues calculation regardless of the error status associated with a CRC
            // checksum
            // 1 AMU2 halts execution if a CRC checksum error is detected when DCCRCHn[ECRC]
            // = 1
            vuint32_t ECRC:1;
            // Enable Cyclic Redundancy Check
            // This bit enables the ADMA’s calculation of a CRC checksum as data is written into the
            // ARAM. The expected 32-bit checksum result is defined in the AMU2_DCKSCHn
            // register.
            // 0 ADMA checksum is disabled
            // 1 ADMA checksum is enabled
            vuint32_t CADS:1;
            // Clear ADMA State
            // Setting this bit resets the DMA status state machine (AMU2_SEIRCHn[ADMAS]) to idle.
            // The use of this bit is intended for situations where halted or stopped data transfers are
            // not continued. This bit always reads as a zero.
            // See Section 88.3.6.2: ADMA execution states for more information.
            // 0 Do not reset the ADMA status state machine to idle
            // 1 Reset the ADMA status state machines to idle
            vuint32_t DECC:1;
            // Disable ADMA ECC single bit corrections
            // Setting this bit disables the ADMA’s ECC logic from performing single-bit corrections and
            // double-bit detections on data to be written into the ARAM and optionally sent to the CRC
            // logic for checksum generation.
            // This bit is intended for test and debug purposes.
            // 0 Enable single-bit corrections and double-bit detections on corrupted data fetched from
            // the system Flash address space
            // 1 Disable single-bit corrections and double-bit detections on corrupted data fetched from
            // the system Flash address space
            vuint32_t STMP3:1;
            // Stream the P3 vector into a 128-byte ARAM circular FIFO
            // When enabled, the P3 vector is fetched from the system Flash using the
            // AMU2_P3PTRCHn register (which is incremented) and written into a dedicated 128-
            // byte ARAM FIFO. The transfers are paced by the ALU’s execution speed. Due to the
            // inherent pipelining of the AMU2, speculative prefetches beyond the actual P3 vector in
            // Flash are likely - the AMU2_P3PTRCHn register must be reloaded before the next
            // calculation. When operating in this mode, the checksum function is not supported.
            // The streaming of P3 data is initiated when STMP3 = 1 and SRT = 1. Concurrent
            // streaming of the V array can be supported by also setting STMV{32,16} != 00.
            // When a non-streamed ADMA data transfer is required, this flag must be cleared. The
            // ADMA supports either normal data transfers or a streaming operation.
            // Writes to AMU2_CCR2CHn[ADCC18] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[STMP3] =
            // AMU2_CCR2CHn[ADCCR18].
            // 0 P3 streaming mode is disabled
            // 1 P3 streaming mode is enabled
            vuint32_t STMV32:1;
            // Stream the 32-bit V array into a 256-byte ARAM circular FIFO
            // When enabled, the 32-bit V array is fetched from the system Flash using the
            // AMU2_VPTRCHn register (which is incremented) and written into a dedicated 256-byte
            // ARAM FIFO. The transfers are paced by the ALU’s execution speed. Due to the inherent
            // pipelining of the AMU2, speculative prefetches beyond the actual V array in Flash are
            // likely - the AMU2_VPTRCHn register must be reloaded before the next calculation.
            // When operating in this mode, the checksum function is not supported.
            // The separate STMV{32,16} are required so the ADMA can begin the appropriate data
            // transfer before the AMU2_CCR1CHn[V16] is configured. It is software’s responsibility to
            // insure the STMV{32,16} and AMU2_CCR1CHn[V16] settings are consistent.
            // The definition of the 2-bit {STMV32, STMV16} configuration bits is:
            // (00) All V streaming is disabled
            // (01) 16-bit V streaming is enabled
            // (10) 32-bit V streaming is enabled
            // (11) 32-bit V streaming is enabled
            // The streaming of V data is initiated when STMV{32, 16} != 00 and SRT = 1. Concurrent
            // streaming of the P3 vector can be supported by also setting STMP3 = 1.
            // When a non-streamed ADMA data transfer is required, this flag must be cleared. The
            // ADMA supports either normal data transfers or a streaming operation.
            // Writes to AMU2_CCR2CHn[ADCC19] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[STMV32] =
            // AMU2_CCR2CHn[ADCCR19].
            // 0 V32 streaming mode is disabled
            // 1 V32 streaming mode is enabled
            vuint32_t STMV16:1;
            // Stream the 16-bit V array into a 256-byte ARAM circular FIFO
            // When enabled, the 16-bit V array is fetched from the system Flash using the
            // AMU2_VPTRCHn register (which is incremented) and written into a dedicated 256-byte
            // ARAM FIFO. The transfers are paced by the ALU’s execution speed. Due to the inherent
            // pipelining of the AMU2, speculative prefetches beyond the actual V array in Flash are
            // likely - the AMU2_VPTRCHn register must be reloaded before the next calculation.
            // When operating in this mode, the checksum function is not supported.
            // The separate STMV{32,16} are required so the ADMA can begin the appropriate data
            // transfer before the AMU2_CCR1CHn[V16] is configured. It is software’s responsibility to
            // insure the STMV{32,16} and AMU2_CCR1CHn[V16] settings are consistent.
            // 0 V16 streaming mode is disabled
            // 1 V16 streaming mode is enabled
            // The definition of the 2-bit {STMV32, STMV16} configuration bits is:
            // (00) All V streaming is disabled
            // (01) 16-bit V streaming is enabled
            // (10) 32-bit V streaming is enabled
            // (11) 32-bit V streaming is enabled
            // The streaming of V data is initiated when STMV{32,16} != 00 and SRT = 1. Concurrent
            // streaming of the P3 vector can be supported by also setting STMP3 = 1.
            // When a non-streamed ADMA data transfer is required, this flag must be cleared. The
            // ADMA supports either normal data transfers or a streaming operation.
            // Writes to AMU2_CCR2CHn[ADCC20] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[STMV16] =
            // AMU2_CCR2CHn[ADCCR20].
            vuint32_t EHP:1;
            // Enable High Priority
            // The ADMA’s private connection with the platform Flash controller includes a signal that
            // elevates the priority of a data request versus requests from the other system bus
            // masters. By default, the ADMA’s priority is lower than the other system bus masters.
            // However, when this control signal is asserted, the ADMA’s request is given highest
            // priority within the platform Flash controller. The assertion of this high priority signal is
            // controlled by three mechanisms:
            // (1) For non-streamed ADMA transfers, the high priority control signal is asserted based
            // on the setting of the ADMA speed control and the platform Flash controller’s response
            // time. If the responses are too slow, the ADMA asserts the high priority signal.
            // (2) For streamed ADMA transfers, the high priority control signal is asserted based on
            // the setting of the ALU speed control and the platform Flash controller’s response time.
            // Again, if the responses are too slow based on the ALU’s need for new data, the ADMA
            // asserts the high priority signal.
            // (3) If this EHP bit is set, the high priority control signal is unconditionally asserted.
            // 0 ADMA does not unconditionally assert the high priority signal to the platform Flash
            // controller
            // 1 ADMA does unconditionally assert the high priority signal to the platform Flash
            // controller
            vuint32_t DSAS:1;
            // ADMA Stop if Alu Stops. This bit provides a mechanism to automatically stop the ADMA
            // channel transfer requests if the ALU stops for any reason.
            // This bit applies to non-streamed ADMA transfers. When streaming P3 or V, or both, the
            // ADMA automatically stops streaming if/when the ALU is stopped or halted, and
            // automatically resumes streaming when the calculation is resumed.
            // 0 ALU stops do not affect the ADMA
            // 1 ALU stops force the ADMA to also stop
            vuint32_t STP:1;
            // ADMA Stop request
            // The setting of this indicator bit signals the ADMA to stop at the next appropriate point.
            // The ADMA run status is available in AMU2_SEIRCHn[ADMAS].
            // If the P3 vector or V array, or both, are being streamed, the ADMA data transfers are
            // paced by the ALU calculation speed, so any stop or halt condition to the ALU
            // automatically stalls the ADMA.
            // Note the simultaneous assertion of the STP and any conditional (WFS1D, WFS23D,
            // WFDNI) or unconditional (SRT) start indicators causes the attempted ADMA initiation to
            // effectively be ignored with no change in the AMU2_SEIRCHn[ADMAS] status.
            // 0 No ADMA stop request; it operates normally
            // 1 ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA
            // stops, this indicator is cleared.
            vuint32_t DEICFG:1;
            // ADMA Error Interrupt ConfIguration
            // This field controls the reporting mechanism associated with the ADMA error indicator
            // flag (AMU2_SEIRCHn[DEIRQ]).
            // 0 If an ADMA error is detected, set the indicator flag; the flag is explicitly cleared by
            // software.
            // 1 If an ADMA error is detected, set the indicator flag and assert core interrupt request;
            // the flag is explicitly cleared by software.
            vuint32_t WFDNI:1;
            // Wait For ALU Done Interrupt request
            // This flag is a conditional ADMA start indicator. If asserted, the ADMA does not begin any
            // data transfers until the ALU’s stage2 + 3 calculations complete and set the
            // AMU2_SEIRCHn[DNIRQ] indicator. This condition is signaled by
            // (AMU2_SEIRCHn[DNIRQ] = 1’b1). If the ALU is idle when the AMU2_DCCRCHn
            // register is loaded and a conditional ADMA start after the next ALU calculation completes
            // is desired, the WFDNI indicator should be used.
            // Once the ADMA transfer begins, this indicator bit is automatically cleared.
            // Writes to AMU2_CCR2CHn[ADCC25] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[WFDNI] =
            // AMU2_CCR2CHn[ADCCR25].
            // 0 No ADMA start condition dependency
            // 1 ADMA does not start until the ALU’s stage2 + 3 calculations complete, and set
            // AMU2_SEIRCHn[DNIRQ]
            vuint32_t WFS23D:1;
            // Wait For Stage23 Done
            // This flag is a conditional ADMA start indicator. If asserted, the ADMA does not begin any
            // data transfers until the ALU’s stage2 + 3 calculations are complete. This condition is
            // signaled by (AMU2_SEIRCHn[S23XS] == 2’b00). Once the ADMA transfer begins, this
            // indicator bit is automatically cleared.
            // If the ADMA’s data transfer must be delayed until the entire ALU calculation is complete,
            // then both WFS1D and WFS23D must be asserted. Alternatively, the WFDNI flag can be
            // used as the conditional ADMA start condition.
            // Writes to AMU2_CCR2CHn[ADCC26] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[WFS23D] =
            // AMU2_CCR2CHn[ADCCR26].
            // 0 No ADMA start condition dependency
            // 1 ADMA does not start until the ALU’s stage2 + 3 calculations are complete
            vuint32_t WFS1D:1;
            // Wait For Stage1 Done
            // This flag is a conditional ADMA start indicator. If asserted, the ADMA does not begin any
            // data transfers until the ALU’s stage1 calculation is complete. This condition is signaled
            // by (AMU2_SEIRCHn[S1XS] == 2’b00). Once the ADMA transfer begins, this indicator bit
            // is automatically cleared.
            // If the ADMA’s data transfer must be delayed until the entire ALU calculation is complete,
            // then both WFS1D and WFS23D must be asserted. Alternatively, the WFDNI flag can be
            // used as the conditional ADMA start condition.
            // Writes to AMU2_CCR2CHn[ADCC27] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[WFS1D] =
            // AMU2_CCR2CHn[ADCCR27].
            // 0 No ADMA start condition dependency
            // 1 ADMA does not start until the ALU’s stage1 calculation is complete
            vuint32_t RSM:1;
            // ADMA ReSuMe
            // The assertion of a properly-qualified resume condition ((RSM == 1) && (STP == 0))
            // resumes the data transfer defined by the contents of the ADMA’s registers, exiting from
            // the stopped state.
            // This bit applies to non-streamed ADMA transfers. When streaming P3 or V, or both, the
            // ADMA automatically stops streaming if/when the ALU is stopped or halted, and
            // automatically resumes streaming when the calculation is resumed.
            // Once the ADMA resumes execution, this indicator bit is automatically cleared.
            // 0 Do not resume the ADMA
            // 1 Resume the ADMA’s data transfer
            vuint32_t unused_0:1;
            vuint32_t FARZ:1;
            // Force ARAM to Zero
            // The assertion of this indicator flag enables a special ADMA mode of operation where up
            // to 16 bytes of zero data (with the appropriate ECC check bits) are written into the ARAM
            // destination defined by AMU2_DDACHn on alternating cycles.
            // This ARAM initialization mode functions in a manner similar to a normal ADMA data
            // transfer. Instead of fetching data from the Flash (or one of its remapped destination
            // memories), the ADMA forces all zero data with correct ECC to be written into the ARAM.
            // The AMU2_DSACHn register is not used, but the starting destination address is defined
            // by AMU2_DDACHn and the size of the memory to be cleared by
            // AMU2_DCNTCHn[BCNT]. The CRC is not supported in this mode, and
            // AMU2_DCCRCHn[DARU] must be 0b00. The ARAM initialization is initiated by setting
            // AMU2_DCCRCHn[SRT] = 1. All the ADMA status reporting operates like a normal data
            // transfer. It is recommended that the other ADMA channel be idle during this initialization
            // function.
            // 0 The zeroing of the ARAM by the ADMA is disabled
            // 1 The zeroing of the ARAM by the ADMA is enabled
            vuint32_t SRT:1;
            // ADMA Start request. This assertion of a properly-qualified start condition ((SRT == 1) &&
            // (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers.
            // Once ADMA starts execution, this indicator bit is automatically cleared.
            // Writes to AMU2_CCR2CHn[ADCC31] may affect this indicator, that is, if
            // AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[SRT] =
            // AMU2_CCR2CHn[ADCCR31].
            // 0 Do not unconditionally start the ADMA
            // 1 Unconditionally start the ADMA
        } B;
    } DCCRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_2:1;
            vuint32_t SRTSP:3;
            // Start Speed
            // This 3-bit encoded value defines the start speed for the ADMA channel. It is used with
            // the MAXSP field and AMU2_DCNTCHn[THRHC] with the current speed of the ADMA is
            // reported in AMU2_SEIRCHn[DCURSP].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels and accessible from either the CH0 or
            // CH1 programming models.
            // 000 Maximum speed; speed control disabled
            // 001 1/8 speed
            // 010 2/8 speed
            // 011 3/8 speed
            // 100 4/8 speed
            // 101 5/8 speed
            // 110 6/8 speed
            // 111 7/8 speed
            vuint32_t unused_1:1;
            vuint32_t MAXSP:3;
            // Maximum Speed
            // This 3-bit encoded value defines the maximum speed for the ADMA channel. It is used
            // with the SRTSP field and AMU2_DCNTCHn[THRHC] with the current speed of the
            // ADMA is reported in AMU2_SEIRCHn[DCURSP].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels and accessible from either the CH0 or
            // CH1 programming models.
            // This field uses the same definition as SRTSP above.
            vuint32_t AEICFG:2;
            // ALU Error Interrupt ConFiGuration
            // This 2-bit field provides the reporting mechanism associated with the ALU error indicator
            // flag (AMU2_SEIRCHn[ERIRQ]).
            // 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ALU error condition
            // 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software
            // 10 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ALU error condition
            // 11 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software
            vuint32_t OVICFG:2;
            // Overflow Interrupt Configuration
            // This 2-bit field provides the reporting mechanism associated with the ALU overflow
            // indicator flag (AMU2_SEIRCHn[OVIRQ]).
            // 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ALU overflow condition.
            // 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software.
            // 10 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ALU overflow condition.
            // 11 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software.
            vuint32_t NCICFG:2;
            // N Crossing Interrupt Configuration
            // This 2-bit field provides the reporting mechanism associated with the ALU N crossing
            // indicator flag (AMU2_SEIRCHn[NCIRQ]).
            // 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ALU N crossing condition
            // 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software
            // 10 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
            // acknowledgement.The AMU2_CCR2CHn[SNCRS] indicator should be set so the
            // ALU stops its calculation so the correct intermediate result is available for the SDMA
            // 11 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
            // acknowledgement.The AMU2_CCR2CHn[SNCRS] indicator should be set so the
            // ALU stops its calculation so the correct intermediate result is available for the SDMA
            vuint32_t DNICFG:2;
            // ALU Done Interrupt Configuration
            // This 2-bit field provides the reporting mechanism associated with the ALU done, that is,
            // a calculation has successfully completed, indicator flag (AMU2_SEIRCHn[DNIRQ]).
            // 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
            // software to poll for ALU done condition.
            // 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
            // software.
            // 10 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
            // acknowledgement
            // 11 Set indicator flag, initiate an ADMA transfer if one of the conditional start flags
            // (AMU2_DCCRCHn[WFS1D, WFS23D, WFDNI]) is also asserted. The
            // AMU2_SEIRCHn[DNIRQ] flag is cleared by the AMU
            vuint32_t BPRI:1;
            // Bus Priority
            // This indicator bit controls the bus arbitration priority associated with the ARAM and the
            // programming model registers. Recall from Figure 2350: AMU2 block diagram, there are
            // multiple master devices that can access the ARAM and programming model registers,
            // specifically, the ADMA and ALU as well as system bus transfers routed via slave
            // peripheral bus. This indicator bit controls the arbitration policy for selecting one master’s
            // request when concurrent accesses occur; idle cycles from the selected master provide
            // opportunities for stalled accesses from other masters to be granted and complete.
            // 0 ADMA has higher arbitration priority than the ALU which has higher priority than slave
            // peripheral bus accesses (ADMA > ALU > slave peripheral bus)
            // 1 ADMA has higher arbitration priority than slave peripheral bus accesses which have
            // higher priority than the ALU (ADMA > slave peripheral bus > ALU)
            vuint32_t EECC:1;
            // Enable Error Correcting Code (ECC) in the ARAM
            // This bit controls the checking of data read from the ARAM by the ALU and the slave
            // peripheral bus. Note, ECC is generated on all writes to the ARAM from either the ADMA
            // or the slave peripheral bus. If a single-bit error is detected by the ECC logic on an ARAM
            // read, the corrected data is written back into the ARAM only in response to the readmodify-
            // write sequence needed on all slave peripheral write accesses.
            // 0 ECC checking of ARAM reads is disabled
            // 1 ECC checking of ARAM reads is enabled
            // If the system DMA is used for ARAM initialization, the EECC bits for both channels must
            // be cleared until the initialization is complete.
            vuint32_t DDSL:1;
            // Disable Debug Stall
            // This bit disables the AMU from stalling when an MCU debug event is underway.
            // 0 All debug events, as signaled by an input signal, stall the amu-> The stall globally
            // affects both channels of the ADMA and ALU
            // 1 Debug events do not affect the AMU
            vuint32_t SETZ:1;
            // Set Z result
            // This bit controls the first operation performed in the ALU’s stage3 output normalization.
            // As the name implies, if this bit is asserted, the final result (z64) is set to the P5 data
            // value, else it is unaffected. The second operation in stage3 involves a final accumulation
            // with the result plus the product of y64 and p4.
            // The stage3 output normalization pseudo-code is:
            // // stage 3: output normalization 
            // if (setz) {
            // z64 = (ieee64) p5;
            // }
            // z64 = z64 + (ieee32) y64 * p4; // 32 x 32 . 64 FMA
            // 0 z64 is unaffected
            // 1 z64 is set to the 64-bit double-precision value of p5
            vuint32_t ESTZC:1;
            // Enable SETZ Clear
            // If set, this bit forces the SETZ flag to be automatically cleared after a stage3 calculation
            // as indicated by the assertion of AMU2_SEIRCHn[DNIRQ].
            // 0 SETZ flag is not cleared by the hardware.
            // 1 SETZ flag is automatically cleared by the hardware after the stage3 calculation
            // completes.
            vuint32_t unused_0:2;
            vuint32_t V16:1;
            // V is a 16-bit data format
            // This bit, along with VFH, defines the format for the V array:
            // if V16 = 0, then V[*] is 32-bit single-precision format (ieee32)
            // if V16 = 1 && VFH = 0, then V[*] is 16-bit half-precision format (ieee16)
            // if V16 = 1 && VFH = 1, then V[*] is 16-bit fixed-point format with a common 7-bit biased
            // exponent
            // This bit cannot be changed while the ADMA is streaming V[*] data. See
            // Section 88.3.3.2: 16-bit fixed-point with common exponent for details on the 16-bit fixed
            // point format.
            vuint32_t VFH:1;
            V is Fixed Halfword format
            // This bit, along with V16, defines the format for the V array:
            // if V16 = 0, then V[*] is 32-bit single-precision format (ieee32)
            // if V16 = 1 && VFH = 0, then V[*] is 16-bit half-precision format (ieee16)
            // if V16 = 1 && VFH = 1, then V[*] is 16-bit fixed-point format with a common 7-bit biased
            // exponent
            // See Section 88.3.3.2: 16-bit fixed-point with common exponent for details on the 16-bit
            // fixed point format.
            vuint32_t CMEXP:7;
            // Common Exponent
            // This 7-bit field defines the common exponent using an excess-63 format for the V array’s
            // 16-bit fixed-point format.
            // See Section 88.3.3.2: 16-bit fixed-point with common exponent for details on the 16-bit
            // fixed point format.
        } B;
    } CCR1CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t unused_5:1;
            vuint32_t ADCCRE:1;
            // Alternate DCCR write Enable
            // This bit enables all the aliased AMU2_DCCRCHn indicators
            // (AMU2_CCR2CHn[ADCR18, ADCCR19, ADCCR20, ADCCR25, ADCCR26,
            // ADCCR27]) to be written when this register is updated. Clearing this bit allows software
            // to write the AMU2_CCR2CHn without affecting the aliased control bits in the
            // AMU2_DCCRCHn. The ADCCRE indicator always reads as a zero.
            // 0 Contents of the write data for AMU2_CCR2CHn[ADCCR{18,19,20,25,26,27}] do not
            // affect the AMU2_DcCRCHn
            // 1 Contents of the write data for AMU2_CCR2CHn[ADCCR{18,19,20,25,26,27}] are
            // loaded into AMU2_DCCRCHn
            vuint32_t ADCCR18:1;
            // Alternate AMU2_DCCRCHn[STMP3]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[STMP3], that is, AMU2_DCCRCHn[STMP3] =
            // AMU2_CCR2CHn[ADCCR18], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the STMP3 indicator allows it to be written by the special ADMA
            // mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t ADCCR19:1;
            // Alternate AMU2_DCCRCHn[STMV32]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[STMV32], that is, AMU2_DCCRCHn[STMV32] =
            // AMU2_CCR2CHn[ADCCR19], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the STMV32 indicator allows it to be written by the special ADMA
            // mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t ADCCR20:1;
            // Alternate AMU2_DCCRCHn[STMV16]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[STMV16], that is, AMU2_DCCRCHn[STMV16] =
            // AMU2_CCR2CHn[ADCCR20], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the STMV16 indicator allows it to be written by the special ADMA
            // mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t unused_4:4;
            vuint32_t ADCCR25:1;
            // Alternate AMU2_DCCRCHn[WFDNI]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[WFDNI], that is, AMU2_DCCRCHn[WFDNI] =
            // AMU2_CCR2CHn[ADCCR25], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the WFDNI indicator allows it to be written by the special ADMA
            // mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t ADCCR26:1;
            // Alternate AMU2_DCCRCHn[WFS23D]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[WFS23D], that is, AMU2_DCCRCHn[WFS23D] =
            // AMU2_CCR2CHn[ADCCR26], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the WFS23D indicator allows it to be written by the special ADMA
            // mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t ADCCR27:1;
            // Alternate AMU2_DCCRCHn[WFS1D]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[WFS1D], that is, AMU2_DCCRCHn[WFS1D] =
            // AMU2_CCR2CHn[ADCCR27], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the WFS1D indicator allows it to be written by the special ADMA
            // mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t ADCCR31:1;
            // Alternate AMU2_DCCRCHn[SRT]
            // If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
            // directly affect AMU2_DCCRCHn[SRT], that is, AMU2_DCCRCHn[SRT] =
            // AMU2_CCR2CHn[ADCCR31], else the AMU2_DCCRCHn indicator is unaffected.
            // This alternate copy of the SRT indicator allows it to be written by the special ADMA mode
            // that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.
            vuint32_t unused_3:1;
            vuint32_t ENCRS:1;
            // Enable N CRoSsing event
            // This bit enables the occurrence of an N crossing event.
            // 0 The ALU’s N crossing logic is disabled
            // 1 The ALU’s N crossing logic is enabled
            vuint32_t SNCRS:1;
            // Stop on N CRoSsing event
            // This bit forces the ALU to stop execution on the occurrence of an N crossing event.
            // 0 The ALU does not stop execution when an N crossing event occurs
            // 1 The ALU stops execution when an N crossing event occurs
            vuint32_t CSXXS:1;
            // Clear Stage “X” eXecution State
            // Setting this bit resets both the ALU execution state machines (AMU2_SEIRCHn[S1XS,
            // S23XS]) to idle. The use of this bit is intended for situations where halted or stopped
            // calculations are not continued. This bit always reads as a zero.
            // 0 Do not reset the ALU execution state machines to idle
            // 1 Reset both of the ALU execution state machines to idle
            // See Section 88.3.5.1: ALU execution states for more information.
            vuint32_t unused_2:6;
            vuint32_t S23STP:1;
            // Stage23 STop request
            // The setting of this indicator bit signals the ALU to stop at the completion of the current
            // outer loop execution. If asserted after the final stage2 outer loop completes, stage3 also
            // finishes and S23STP remains asserted indicating the stop request was not granted.The
            // ALU’s stage23 status is available in AMU2_SEIRCHn[S23XS].
            // Once the ALU is stopped, this indicator bit is automatically cleared.
            // 0 No stage23 stop request; the ALU operates normally
            // 1 Stage23 stop request; stop execution at the completion of the current outer loop
            // iteration
            vuint32_t unused_1:1;
            vuint32_t WFSS23:1;
            // Wait For Sdma complete before starting Stage23
            // This is a conditional start bit for stage23. It signals the stage23 execution start is enabled
            // by the completion of an SDMA data transfer.
            // This indicator is used when the SDMA is used to copy an AMU result into system
            // memory. The setting of this flag means the SDMA result retrieval must be finished before
            // a stage23 calculation is initiated. Once stage23 begins execution, this indicator bit is
            // automatically cleared.
            // When streaming P3[*] or V[*] data, or both, this indicator bit is ignored.
            // 0 No conditional stage23 start condition
            // 1 Initiate stage23’s execution when the SDMA completes its current data transfer
            vuint32_t WFDS23:1;
            // Wait For aDma complete before starting Stage23
            // This is a conditional start bit for stage23. It signals the stage23 execution start is enabled
            // by the completion of the ADMA data transfer.
            // The WFDS23 indicator is automatically cleared if the ADMA halts due to a bus or noncorrectable
            // ECC error, or if a checksum error is detected. This prevents the ALU stage23
            // execution from starting after the ADMA halt condition is processed by a service routine.
            // The WFDS23 conditional start indicator can be combined with WFDS1. If both bits are
            // asserted, as the ADMA completes its data transfer, the ALU begins execution of stage1,
            // followed by stage23.
            // Once stage23 begins execution, this indicator bit is automatically cleared.
            // When streaming P3[*] or V[*] data, or both, this indicator bit is ignored.
            // 0 No conditional stage23 start condition
            // 1 Initiate stage23’s execution when the ADMA completes its current data transfer
            vuint32_t WFDS1:1;
            // Wait For aDma complete before starting Stage1
            // This is a conditional start bit for stage1. It signals the stage1 execution start is enabled by
            // the completion of the ADMA data transfer.
            // The WFDS1 indicator is automatically cleared if the ADMA halts due to a bus or noncorrectable
            // ECC error, or if a checksum error is detected. This prevents the ALU stage1
            // execution from starting after the ADMA halt condition is processed by a service routine.
            // The WFDS1 conditional start indicator can be combined with WFDS23. If both bits are
            // asserted, as the ADMA completes its data transfer, the ALU begins execution of stage1,
            // followed by stage23. Once stage1 begins execution, this indicator bit is automatically
            // cleared.
            // When streaming P3[*] or V[*] data, or both, this indicator bit is ignored.
            // 0 No conditional stage1 start condition
            // 1 Initiate stage1’s execution when the ADMA completes its current data transfer.
            vuint32_t S23RSM:1;
            // Stage23 ReSuMe
            // This bit resumes a stopped stage23 calculation. If stage23 is not stopped at the time of
            // an attempted write to assert this bit, it is ignored.
            // Once stage23 resumes execution, this indicator bit is automatically cleared.
            // 0 Do not resume a stopped stage23 calculation
            // 1 Resume a stopped stage23 calculation
            vuint32_t unused_0:1;
            vuint32_t S23SRT:1;
            // Stage23 StaRT request. This assertion of a properly-qualified start condition ((S23SRT
            // == 1) && (S23STP == 0)) initiates the ALU’s stage23 execution. If S1SRT is also
            // asserted, the ALU hardware sequences through the execution, first of stage1 and then
            // stage23.
            // Once stage23 starts execution, this indicator bit is automatically cleared.
            // 0 Do not unconditionally start ALU’s stage23 execution
            // 1 Unconditionally start ALU’s stage23 execution, either immediately or after stage1
            // completes
            vuint32_t S1SRT:1;
            // Stage1 StaRT request. This assertion of this start condition initiates the ALU’s stage1
            // execution.
            // Once stage1 starts execution, this indicator bit is automatically cleared.
            // 0 Do not unconditionally start ALU’s stage1 execution
            // 1 Unconditionally start ALU’s stage1 execution
        } B;
    } CCR2CH;

    vuint8_t AMU_reserved2[32];

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE64:32;
            // Most significant word of the final result value in IEEE 64-bit floating-point format.
            // This is the RES64MCHn register.
        } B;
    } RES64MCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE64:32;
            // Least significant word of the final result value in IEEE 64-bit floating-point format.
            // This is the RES64LCHn register.
        } B;
    } RES64LCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t CHBSY:1;
            // Channel Busy
            // This read-only bit is intended to serve as a polling flag as it signals the AMU2 channel is
            // busy. In this context, the “channel” status represents the logical summation of the ADMA
            // data channel and the ALU calculation engine status fields indicating a non-idle “channel”.
            // This flag is asserted when ((AMU2_SEIRCHn[ADMAS] == 0b11) ||
            // (AMU2_SEIRCHn[S1XS] == 0b11) || (AMU2_SEIRCHn[S23XS] == 0b11)).
            // 0 Channel n is idle
            // 1 Channel n is busy performing an ADMA data transfer or an ALU calculation
            vuint32_t ADSTM:1;
            // ADMA is Streaming
            // This read-only flag signals whether the ADMA is performing a data streaming transfer of
            // the P3[*] or V[*] input vectors as enabled by AMU2_DCCRCHn[STMP3, STMV{32, 16}]
            // control bits.
            // 0 The ADMA is not performing any P3[*] nor V[*] data streaming transfers
            // 1 The ADMA is busy performing a P3[*] or V[*] data streaming transfers
            vuint32_t S23XS:2;
            // Stage23 Execution Status
            // This read-only 2-bit field defines the execution status of the ALU’s stage23 logic. See
            // Section 88.3.5.1: ALU execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Stopped
            // 11 Running or stalled
            vuint32_t S1XS:2;
            // Stage1 eXecution Status
            // This read-only 2-bit field defines the execution status of the ALU’s stage1 logic. See
            // Section 88.3.5.1: ALU execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Unused, reserved as stage1 execution cannot be stopped via a request
            // 11 Running or stalled
            vuint32_t ADMAS:2;
            // ADMA Status
            // This read-only 2-bit field defines the status of the ADMA. See Section 88.3.6.2: ADMA
            // execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Stopped
            // 11 Running or stalled
            vuint32_t QDSL:1;
            // Qualified Debug Stali
            // This read-only bit signals a qualified debug stall condition as defined by (debug_event
            // == 1) && (AMU2_CCR1CHn[DDSL] == 0).
            // 0 No qualified debug stall
            // 1 The ALU calculation engine and ADMA are stalled due to a qualified debug event.
            vuint32_t ACURSP:3;
            // Alu Current Speed
            // This read-only 3-bit encoded value defines the current speed for the ALU engine. The
            // ALU speed control is defined by AMU2_CCR1CHn[SRTSP, MAXSP] and
            // AMU2_P8CHn[THRHC].
            // The ALU speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.5.2: ALU speed
            // control for more details on the ALU speed control mechanism. There is a single ALU
            // speed control function shared by both channels.
            // 000 Maximum speed; speed control disabled
            // 001 1/8 speed
            // 010 2/8 speed
            // 011 3/8 speed
            // 100 4/8 speed
            // 101 5/8 speed
            // 110 6/8 speed
            // 111 7/8 speed
            vuint32_t unused_1:1;
            vuint32_t DCURSP:3;
            // ADMA Current Speed
            // This read-only 3-bit encoded value defines the current speed for the ADMA channel. The
            // ADMA speed control is defined by AMU2_DCCRCHn[SRTSP, MAXSP] and
            // AMU2_DCNTCHn[THRHC].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels.
            // The DCURSP uses the same encodings as the ACURSP field above.
            vuint32_t YCAFLT:1;
            // Y Conversion Arithmetic Fault
            // The assertion of this read-only flag indicates the conversion from double-precision
            // ieee64 format of the y64 result to single-precision ieee32 format generated an arithmetic
            // fault (overflow, underflow).
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the conversion of y64 to y32
            // 1 Arithmetic fault associated with the conversion of y64 to y32 was detected. For the
            // overflow case, the y32 value is set to (+/-) INF, while an underflow produces a (+/-) 0
            // value
            vuint32_t ZCAFLT:1;
            // Z Conversion Arithmetic Fault
            // The assertion of this read-only flag indicates the conversion from double-precision
            // ieee64 format of the z64 result to single-precision ieee32 format generated an arithmetic
            // fault (overflow, underflow).
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the conversion of z64 to z32.
            // 1 Arithmetic fault associated with the conversion of z64 to z32 was detected. For the
            // overflow case, the z32 value is set to (+/-) INF, while an underflow produces a (+/-) 0
            // value.
            vuint32_t S23AFLT:1;
            // Stage2, 3 Arithmetic Fault
            // The assertion of this read-only flag indicates an arithmetic fault (overflow, underflow) was
            // detected in the ALU’s stage2 or stage3 calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the ALU’s stage3 calculation.
            // 1 Arithmetic fault associated with the ALU’s stage3 calculation was detected.
            vuint32_t S1AFLT:1;
            // Stage1 Arithmetic Fault
            // The assertion of this read-only flag indicates an arithmetic fault (overflow, underflow) was
            // detected in the ALU’s stage1 calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the ALU’s stage1 calculation.
            // 1 Arithmetic fault associated with the ALU’s stage1 calculation was detected.
            vuint32_t IDVERR:1;
            // Input Data Validation Error
            // The assertion of this read-only flag indicates an error (NaN, +/- INF) was detected in the
            // input data before the ALU’s calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No error associated with the input data
            // 1 Arithmetic fault associated with the input data was detected
            vuint32_t ADMERR:1;
            // ADMA Error
            // The assertion of this read-only flag indicates an error (such as bus error, illegal address,
            // multi-bit ECC event) was detected by the ADMA. This flag does not include CRC
            // checksum errors as these are directly signaled by SEIRCHn[CKSERR].
            // If the ADMA is streaming P3 or V data, or both, at the time of the error, this flag is set and
            // the ALU calculation is stalled with AMU2_SEIRCHn[S{1,23}XS] indicating the running or
            // stalled state.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No bus error, illegal address, multi-bit ECC, such as errors associated with the ADMA
            // 1 An ADMA bus error, illegal address, multi-bit ECC event, other errors, was detected
            vuint32_t CKSERR:1;
            // ADMA Checksum Error
            // The assertion of this read-only flag indicates an ADMA CRC checksum error was
            // detected.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No CRC checksum error associated with the ADMA
            // 1 An ADMA CRC checksum error was detected
            vuint32_t ECCERR:1;
            // Error Correcting Code Error
            // The assertion of this read-only flag indicates a non-correctable ECC error was detected
            // on an ARAM read by the ALU. Non-correctable ECC errors detected by the ADMA are
            // reported with AMU2_SEIRCHn[ADMERR] = 1, while similar errors detected during a
            // slave peripheral bus access from the CPU or SDMA are reported via an error-terminated
            // bus cycle.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No ARAM ECC error
            // 1 An ARAM non-correctable ECC error was detected
            vuint32_t RGCERR:1;
            // Register Conflict Error
            // The assertion of this read-only flag indicates an unexpected write of the AMU2’s
            // programming model while the ALU is executing was attempted.
            // The protected registers include: AMU2_{P1* - P9*, VPTR, LPTR, UPTR}CHn.
            // Attempted writes to the AMU2_{P1PTR, P2PTR, P7, UPTR}CHn registers while the ALU
            // is executing stage 1 set this indicator bit and halt the ALU. Attempted writes to the
            // AMU2_{P3PTR, P4, P5, P6, P7, P8, P9{M,L}, VPTR, LPTR}CHn registers while the ALU
            // is executing stage 23 set this indicator bit and halt the ALU.
            // The AMU2_{N, DSA, DDA, DCNT, DCKS, DCCR, CCR1, CCR2}CHn registers can
            // safely be written while the ALU is executing.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No register conflict error
            // 1 An AMU2 register conflict error was detected
            vuint32_t unused_0:1;
            vuint32_t DEIRQ:1;
            // ADMA Error Interrupt Request
            // This flag is set to signal the ADMA has detected an error.
            // The error conditions which set this indicator flag include:
            // – Multi-bit ECC event during a data transfer (ADMERR = 1)
            // – Bus error termination during a data transfer (ADMERR = 1)
            // – Detection of a checksum error (CKSERR = 1)
            // The subsequent system behavior is defined by the AMU2_DCCRCHn[DEICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ADMA has not detected an error
            // 1 ADMA has detected an error
            vuint32_t ADIRQ:1;
            // ADMA Interrupt ReQuest. This flag is set to signal the ADMA has completed its data
            // transfer. This flag is not set when streaming P3[*] or V[*] data, or both, completes.
            // The subsequent system behavior is defined by the AMU2_DCCRCHn[ADICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_DCCRCHn[ADICFG] = 0b0-. For other configuration values, the SDMA hardware
            // provides an acknowledgement signal which clears this indicator bit. A read of this
            // register does not affect the state of this indicator bit.
            // 0 ADMA has not completed its data transfer
            // 1 ADMA has completed its data transfer
            vuint32_t ERIRQ:1;
            // ALU Error Interrupt Request
            // This flag is set to signal the ALU has detected certain errors.
            // The error conditions which set this indicator flag include:
            // – Multi-bit ECC event on an ARAM read by the ALU (ECCERR = 1)
            // – Detection of a register conflict error (RGCERR = 1)
            // – Detection of an input data validation error (IDVERR = 1)
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[AEICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ALU has not detected an error
            // 1 ALU has detected an error
            vuint32_t OVIRQ:1;
            // ALU Overflow Interrupt Request
            // This flag is set to signal the ALU has detected an overflow condition.
            // The error conditions which set this indicator flag include:
            // – Arithmetic overflow during stage1 (S1AFLT = 1), stage2 (S23AFLT = 1), or stage3
            // (S23AFLT = 1)
            // – Overflow when performing 64-bit to 32-bit conversions for ut[*] (S1AFLT = 1), t
            // (S23AFLT = 1), y (YCAFLT = 1), z (ZCAFLT =1)
            // The ALU halts execution at specific places within the algorithm if an overflow is detected:
            // stage1 overflows halt at the end of its calculation, stage2 overflows halt at the completion
            // of the outer loop iteration and stage3 overflows complete at the end of its calculation.
            // See Table 2288: ALU Completion State Details in AMU2_SEIRCHn for additional details.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[OVICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ALU has not detected an overflow condition
            // 1 ALU has detected an overflow condition
            vuint32_t NCIRQ:1;
            // ALU N Crossing Interrupt Request
            // This flag is set to signal the ALU has completed “N” iterations of the stage2 calculation in
            // response to a properly configured N crossing event.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[NCICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_CCR1CHn[NCICFG] = 0b0-. For other configuration values, the SDMA or ADMA
            // hardware provides an acknowledgement signal which clears this indicator bit. A read of
            // this register does not affect the state of this indicator bit.
            // 0 ALU has not completed N iterations of a properly-configured N crossing event
            // 1 ALU has completed N iterations of a properly-configured N crossing event
            vuint32_t DNIRQ:1;
            // ALU Done Interrupt Request
            // This flag is set to signal the ALU has successfully completed an error-free calculation.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[DNICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_CCR1CHn[DNICFG] = 0b0-. For other configuration values, the SDMA or ADMA
            // hardware provides an acknowledgement signal which clears this indicator bit. A read of
            // this register does not affect the state of this indicator bit.
            // 0 ALU has not completed its calculation
            // 1 ALU has completed its calculation
        } B;
    } SEIRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t UINT:32;
            // Actual ADMA checksum in a 32-bit unsigned integer format.
        } B;
    } ACKSCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE32:32;
            // Single-precision version (IEEE 32-bit floating-point format) of the final 64-bit result
            // (z64) value.
        } B;
    } RES32CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t CHBSY:1;
            // Channel Busy
            // This read-only bit is intended to serve as a polling flag as it signals the AMU2 channel is
            // busy. In this context, the “channel” status represents the logical summation of the ADMA
            // data channel and the ALU calculation engine status fields indicating a non-idle “channel”.
            // This flag is asserted when ((AMU2_SEIRCHn[ADMAS] == 0b11) ||
            // (AMU2_SEIRCHn[S1XS] == 0b11) || (AMU2_SEIRCHn[S23XS] == 0b11)).
            // 0 Channel n is idle
            // 1 Channel n is busy performing an ADMA data transfer or an ALU calculation
            vuint32_t ADSTM:1;
            // ADMA is Streaming
            // This read-only flag signals whether the ADMA is performing a data streaming transfer of
            // the P3[*] or V[*] input vectors as enabled by AMU2_DCCRCHn[STMP3, STMV{32, 16}]
            // control bits.
            // 0 The ADMA is not performing any P3[*] nor V[*] data streaming transfers
            // 1 The ADMA is busy performing a P3[*] or V[*] data streaming transfers
            vuint32_t S23XS:2;
            // Stage23 Execution Status
            // This read-only 2-bit field defines the execution status of the ALU’s stage23 logic. See
            // Section 88.3.5.1: ALU execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Stopped
            // 11 Running or stalled
            vuint32_t S1XS:2;
            // Stage1 eXecution Status
            // This read-only 2-bit field defines the execution status of the ALU’s stage1 logic. See
            // Section 88.3.5.1: ALU execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Unused, reserved as stage1 execution cannot be stopped via a request
            // 11 Running or stalled
            vuint32_t ADMAS:2;
            // ADMA Status
            // This read-only 2-bit field defines the status of the ADMA. See Section 88.3.6.2: ADMA
            // execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Stopped
            // 11 Running or stalled
            vuint32_t QDSL:1;
            // Qualified Debug Stali
            // This read-only bit signals a qualified debug stall condition as defined by (debug_event
            // == 1) && (AMU2_CCR1CHn[DDSL] == 0).
            // 0 No qualified debug stall
            // 1 The ALU calculation engine and ADMA are stalled due to a qualified debug event.
            vuint32_t ACURSP:3;
            // Alu Current Speed
            // This read-only 3-bit encoded value defines the current speed for the ALU engine. The
            // ALU speed control is defined by AMU2_CCR1CHn[SRTSP, MAXSP] and
            // AMU2_P8CHn[THRHC].
            // The ALU speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.5.2: ALU speed
            // control for more details on the ALU speed control mechanism. There is a single ALU
            // speed control function shared by both channels.
            // 000 Maximum speed; speed control disabled
            // 001 1/8 speed
            // 010 2/8 speed
            // 011 3/8 speed
            // 100 4/8 speed
            // 101 5/8 speed
            // 110 6/8 speed
            // 111 7/8 speed
            vuint32_t unused_1:1;
            vuint32_t DCURSP:3;
            // ADMA Current Speed
            // This read-only 3-bit encoded value defines the current speed for the ADMA channel. The
            // ADMA speed control is defined by AMU2_DCCRCHn[SRTSP, MAXSP] and
            // AMU2_DCNTCHn[THRHC].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels.
            // The DCURSP uses the same encodings as the ACURSP field above.
            vuint32_t YCAFLT:1;
            // Y Conversion Arithmetic Fault
            // The assertion of this read-only flag indicates the conversion from double-precision
            // ieee64 format of the y64 result to single-precision ieee32 format generated an arithmetic
            // fault (overflow, underflow).
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the conversion of y64 to y32
            // 1 Arithmetic fault associated with the conversion of y64 to y32 was detected. For the
            // overflow case, the y32 value is set to (+/-) INF, while an underflow produces a (+/-) 0
            // value
            vuint32_t ZCAFLT:1;
            // Z Conversion Arithmetic Fault
            // The assertion of this read-only flag indicates the conversion from double-precision
            // ieee64 format of the z64 result to single-precision ieee32 format generated an arithmetic
            // fault (overflow, underflow).
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the conversion of z64 to z32.
            // 1 Arithmetic fault associated with the conversion of z64 to z32 was detected. For the
            // overflow case, the z32 value is set to (+/-) INF, while an underflow produces a (+/-) 0
            // value.
            vuint32_t S23AFLT:1;
            // Stage2, 3 Arithmetic Fault
            // The assertion of this read-only flag indicates an arithmetic fault (overflow, underflow) was
            // detected in the ALU’s stage2 or stage3 calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the ALU’s stage3 calculation.
            // 1 Arithmetic fault associated with the ALU’s stage3 calculation was detected.
            vuint32_t S1AFLT:1;
            // Stage1 Arithmetic Fault
            // The assertion of this read-only flag indicates an arithmetic fault (overflow, underflow) was
            // detected in the ALU’s stage1 calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the ALU’s stage1 calculation.
            // 1 Arithmetic fault associated with the ALU’s stage1 calculation was detected.
            vuint32_t IDVERR:1;
            // Input Data Validation Error
            // The assertion of this read-only flag indicates an error (NaN, +/- INF) was detected in the
            // input data before the ALU’s calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No error associated with the input data
            // 1 Arithmetic fault associated with the input data was detected
            vuint32_t ADMERR:1;
            // ADMA Error
            // The assertion of this read-only flag indicates an error (such as bus error, illegal address,
            // multi-bit ECC event) was detected by the ADMA. This flag does not include CRC
            // checksum errors as these are directly signaled by SEIRCHn[CKSERR].
            // If the ADMA is streaming P3 or V data, or both, at the time of the error, this flag is set and
            // the ALU calculation is stalled with AMU2_SEIRCHn[S{1,23}XS] indicating the running or
            // stalled state.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No bus error, illegal address, multi-bit ECC, such as errors associated with the ADMA
            // 1 An ADMA bus error, illegal address, multi-bit ECC event, other errors, was detected
            vuint32_t CKSERR:1;
            // ADMA Checksum Error
            // The assertion of this read-only flag indicates an ADMA CRC checksum error was
            // detected.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No CRC checksum error associated with the ADMA
            // 1 An ADMA CRC checksum error was detected
            vuint32_t ECCERR:1;
            // Error Correcting Code Error
            // The assertion of this read-only flag indicates a non-correctable ECC error was detected
            // on an ARAM read by the ALU. Non-correctable ECC errors detected by the ADMA are
            // reported with AMU2_SEIRCHn[ADMERR] = 1, while similar errors detected during a
            // slave peripheral bus access from the CPU or SDMA are reported via an error-terminated
            // bus cycle.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No ARAM ECC error
            // 1 An ARAM non-correctable ECC error was detected
            vuint32_t RGCERR:1;
            // Register Conflict Error
            // The assertion of this read-only flag indicates an unexpected write of the AMU2’s
            // programming model while the ALU is executing was attempted.
            // The protected registers include: AMU2_{P1* - P9*, VPTR, LPTR, UPTR}CHn.
            // Attempted writes to the AMU2_{P1PTR, P2PTR, P7, UPTR}CHn registers while the ALU
            // is executing stage 1 set this indicator bit and halt the ALU. Attempted writes to the
            // AMU2_{P3PTR, P4, P5, P6, P7, P8, P9{M,L}, VPTR, LPTR}CHn registers while the ALU
            // is executing stage 23 set this indicator bit and halt the ALU.
            // The AMU2_{N, DSA, DDA, DCNT, DCKS, DCCR, CCR1, CCR2}CHn registers can
            // safely be written while the ALU is executing.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No register conflict error
            // 1 An AMU2 register conflict error was detected
            vuint32_t unused_0:1;
            vuint32_t DEIRQ:1;
            // ADMA Error Interrupt Request
            // This flag is set to signal the ADMA has detected an error.
            // The error conditions which set this indicator flag include:
            // – Multi-bit ECC event during a data transfer (ADMERR = 1)
            // – Bus error termination during a data transfer (ADMERR = 1)
            // – Detection of a checksum error (CKSERR = 1)
            // The subsequent system behavior is defined by the AMU2_DCCRCHn[DEICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ADMA has not detected an error
            // 1 ADMA has detected an error
            vuint32_t ADIRQ:1;
            // ADMA Interrupt ReQuest. This flag is set to signal the ADMA has completed its data
            // transfer. This flag is not set when streaming P3[*] or V[*] data, or both, completes.
            // The subsequent system behavior is defined by the AMU2_DCCRCHn[ADICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_DCCRCHn[ADICFG] = 0b0-. For other configuration values, the SDMA hardware
            // provides an acknowledgement signal which clears this indicator bit. A read of this
            // register does not affect the state of this indicator bit.
            // 0 ADMA has not completed its data transfer
            // 1 ADMA has completed its data transfer
            vuint32_t ERIRQ:1;
            // ALU Error Interrupt Request
            // This flag is set to signal the ALU has detected certain errors.
            // The error conditions which set this indicator flag include:
            // – Multi-bit ECC event on an ARAM read by the ALU (ECCERR = 1)
            // – Detection of a register conflict error (RGCERR = 1)
            // – Detection of an input data validation error (IDVERR = 1)
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[AEICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ALU has not detected an error
            // 1 ALU has detected an error
            vuint32_t OVIRQ:1;
            // ALU Overflow Interrupt Request
            // This flag is set to signal the ALU has detected an overflow condition.
            // The error conditions which set this indicator flag include:
            // – Arithmetic overflow during stage1 (S1AFLT = 1), stage2 (S23AFLT = 1), or stage3
            // (S23AFLT = 1)
            // – Overflow when performing 64-bit to 32-bit conversions for ut[*] (S1AFLT = 1), t
            // (S23AFLT = 1), y (YCAFLT = 1), z (ZCAFLT =1)
            // The ALU halts execution at specific places within the algorithm if an overflow is detected:
            // stage1 overflows halt at the end of its calculation, stage2 overflows halt at the completion
            // of the outer loop iteration and stage3 overflows complete at the end of its calculation.
            // See Table 2288: ALU Completion State Details in AMU2_SEIRCHn for additional details.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[OVICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ALU has not detected an overflow condition
            // 1 ALU has detected an overflow condition
            vuint32_t NCIRQ:1;
            // ALU N Crossing Interrupt Request
            // This flag is set to signal the ALU has completed “N” iterations of the stage2 calculation in
            // response to a properly configured N crossing event.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[NCICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_CCR1CHn[NCICFG] = 0b0-. For other configuration values, the SDMA or ADMA
            // hardware provides an acknowledgement signal which clears this indicator bit. A read of
            // this register does not affect the state of this indicator bit.
            // 0 ALU has not completed N iterations of a properly-configured N crossing event
            // 1 ALU has completed N iterations of a properly-configured N crossing event
            vuint32_t DNIRQ:1;
            // ALU Done Interrupt Request
            // This flag is set to signal the ALU has successfully completed an error-free calculation.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[DNICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_CCR1CHn[DNICFG] = 0b0-. For other configuration values, the SDMA or ADMA
            // hardware provides an acknowledgement signal which clears this indicator bit. A read of
            // this register does not affect the state of this indicator bit.
            // 0 ALU has not completed its calculation
            // 1 ALU has completed its calculation
        } B;
    } ASEIRCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t UINT:32;
            // Actual ADMA checksum in a 32-bit unsigned integer format.
        } B;
    } AACKSCH;

    vuint8_t AMU_reserved3[4];

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE64:32;
            // Most significant word of the y64 value in IEEE 64-bit floating-point format at the
            // completion of the stage2 outer loop. This is the Y64MCHn register.
        } B;
    } Y64MCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE64:32;
            // Least significant word of the y64 value in IEEE 64-bit floating-point format at the
            // completion of the stage2 outer loop. This is the Y64LCHn register.
        } B;
    } Y64LCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t THRHC:16;
            // Threshold Count
            // This 16-bit unsigned integer defines the threshold count used in the ALU speed
            // control function. There are additional control fields associated with this function in
            // the AMU2_CCR1CHn register. There is a single ALU speed control function
            // shared by the calculation engine and accessible from either the CH0 or CH1
            // programming models.
            vuint32_t UINT:16;
            // Parameter p8 value in a 16-bit unsigned integer format.
        } B;
    } AP8CH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t CHBSY:1;
            // Channel Busy
            // This read-only bit is intended to serve as a polling flag as it signals the AMU2 channel is
            // busy. In this context, the “channel” status represents the logical summation of the ADMA
            // data channel and the ALU calculation engine status fields indicating a non-idle “channel”.
            // This flag is asserted when ((AMU2_SEIRCHn[ADMAS] == 0b11) ||
            // (AMU2_SEIRCHn[S1XS] == 0b11) || (AMU2_SEIRCHn[S23XS] == 0b11)).
            // 0 Channel n is idle
            // 1 Channel n is busy performing an ADMA data transfer or an ALU calculation
            vuint32_t ADSTM:1;
            // ADMA is Streaming
            // This read-only flag signals whether the ADMA is performing a data streaming transfer of
            // the P3[*] or V[*] input vectors as enabled by AMU2_DCCRCHn[STMP3, STMV{32, 16}]
            // control bits.
            // 0 The ADMA is not performing any P3[*] nor V[*] data streaming transfers
            // 1 The ADMA is busy performing a P3[*] or V[*] data streaming transfers
            vuint32_t S23XS:2;
            // Stage23 Execution Status
            // This read-only 2-bit field defines the execution status of the ALU’s stage23 logic. See
            // Section 88.3.5.1: ALU execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Stopped
            // 11 Running or stalled
            vuint32_t S1XS:2;
            // Stage1 eXecution Status
            // This read-only 2-bit field defines the execution status of the ALU’s stage1 logic. See
            // Section 88.3.5.1: ALU execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Unused, reserved as stage1 execution cannot be stopped via a request
            // 11 Running or stalled
            vuint32_t ADMAS:2;
            // ADMA Status
            // This read-only 2-bit field defines the status of the ADMA. See Section 88.3.6.2: ADMA
            // execution states for more details on the execution states.
            // The status encodings are:
            // 00 Idle or pending start condition
            // 01 Halted
            // 10 Stopped
            // 11 Running or stalled
            vuint32_t QDSL:1;
            // Qualified Debug Stali
            // This read-only bit signals a qualified debug stall condition as defined by (debug_event
            // == 1) && (AMU2_CCR1CHn[DDSL] == 0).
            // 0 No qualified debug stall
            // 1 The ALU calculation engine and ADMA are stalled due to a qualified debug event.
            vuint32_t ACURSP:3;
            // Alu Current Speed
            // This read-only 3-bit encoded value defines the current speed for the ALU engine. The
            // ALU speed control is defined by AMU2_CCR1CHn[SRTSP, MAXSP] and
            // AMU2_P8CHn[THRHC].
            // The ALU speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.5.2: ALU speed
            // control for more details on the ALU speed control mechanism. There is a single ALU
            // speed control function shared by both channels.
            // 000 Maximum speed; speed control disabled
            // 001 1/8 speed
            // 010 2/8 speed
            // 011 3/8 speed
            // 100 4/8 speed
            // 101 5/8 speed
            // 110 6/8 speed
            // 111 7/8 speed
            vuint32_t unused_1:1;
            vuint32_t DCURSP:3;
            // ADMA Current Speed
            // This read-only 3-bit encoded value defines the current speed for the ADMA channel. The
            // ADMA speed control is defined by AMU2_DCCRCHn[SRTSP, MAXSP] and
            // AMU2_DCNTCHn[THRHC].
            // The ADMA speed control provides a mechanism to control the operation efficiency of the
            // submodule for coarse power control of the amu-> See Section 88.3.6.5: ADMA speed
            // control for more details on the ADMA speed control mechanism. There is a single ADMA
            // speed control function shared by both channels.
            // The DCURSP uses the same encodings as the ACURSP field above.
            vuint32_t YCAFLT:1;
            // Y Conversion Arithmetic Fault
            // The assertion of this read-only flag indicates the conversion from double-precision
            // ieee64 format of the y64 result to single-precision ieee32 format generated an arithmetic
            // fault (overflow, underflow).
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the conversion of y64 to y32
            // 1 Arithmetic fault associated with the conversion of y64 to y32 was detected. For the
            // overflow case, the y32 value is set to (+/-) INF, while an underflow produces a (+/-) 0
            // value
            vuint32_t ZCAFLT:1;
            // Z Conversion Arithmetic Fault
            // The assertion of this read-only flag indicates the conversion from double-precision
            // ieee64 format of the z64 result to single-precision ieee32 format generated an arithmetic
            // fault (overflow, underflow).
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the conversion of z64 to z32.
            // 1 Arithmetic fault associated with the conversion of z64 to z32 was detected. For the
            // overflow case, the z32 value is set to (+/-) INF, while an underflow produces a (+/-) 0
            // value.
            vuint32_t S23AFLT:1;
            // Stage2, 3 Arithmetic Fault
            // The assertion of this read-only flag indicates an arithmetic fault (overflow, underflow) was
            // detected in the ALU’s stage2 or stage3 calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the ALU’s stage3 calculation.
            // 1 Arithmetic fault associated with the ALU’s stage3 calculation was detected.
            vuint32_t S1AFLT:1;
            // Stage1 Arithmetic Fault
            // The assertion of this read-only flag indicates an arithmetic fault (overflow, underflow) was
            // detected in the ALU’s stage1 calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No arithmetic fault associated with the ALU’s stage1 calculation.
            // 1 Arithmetic fault associated with the ALU’s stage1 calculation was detected.
            vuint32_t IDVERR:1;
            // Input Data Validation Error
            // The assertion of this read-only flag indicates an error (NaN, +/- INF) was detected in the
            // input data before the ALU’s calculation. The ALU’s calculation is halted.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No error associated with the input data
            // 1 Arithmetic fault associated with the input data was detected
            vuint32_t ADMERR:1;
            // ADMA Error
            // The assertion of this read-only flag indicates an error (such as bus error, illegal address,
            // multi-bit ECC event) was detected by the ADMA. This flag does not include CRC
            // checksum errors as these are directly signaled by SEIRCHn[CKSERR].
            // If the ADMA is streaming P3 or V data, or both, at the time of the error, this flag is set and
            // the ALU calculation is stalled with AMU2_SEIRCHn[S{1,23}XS] indicating the running or
            // stalled state.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No bus error, illegal address, multi-bit ECC, such as errors associated with the ADMA
            // 1 An ADMA bus error, illegal address, multi-bit ECC event, other errors, was detected
            vuint32_t CKSERR:1;
            // ADMA Checksum Error
            // The assertion of this read-only flag indicates an ADMA CRC checksum error was
            // detected.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No CRC checksum error associated with the ADMA
            // 1 An ADMA CRC checksum error was detected
            vuint32_t ECCERR:1;
            // Error Correcting Code Error
            // The assertion of this read-only flag indicates a non-correctable ECC error was detected
            // on an ARAM read by the ALU. Non-correctable ECC errors detected by the ADMA are
            // reported with AMU2_SEIRCHn[ADMERR] = 1, while similar errors detected during a
            // slave peripheral bus access from the CPU or SDMA are reported via an error-terminated
            // bus cycle.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No ARAM ECC error
            // 1 An ARAM non-correctable ECC error was detected
            vuint32_t RGCERR:1;
            // Register Conflict Error
            // The assertion of this read-only flag indicates an unexpected write of the AMU2’s
            // programming model while the ALU is executing was attempted.
            // The protected registers include: AMU2_{P1* - P9*, VPTR, LPTR, UPTR}CHn.
            // Attempted writes to the AMU2_{P1PTR, P2PTR, P7, UPTR}CHn registers while the ALU
            // is executing stage 1 set this indicator bit and halt the ALU. Attempted writes to the
            // AMU2_{P3PTR, P4, P5, P6, P7, P8, P9{M,L}, VPTR, LPTR}CHn registers while the ALU
            // is executing stage 23 set this indicator bit and halt the ALU.
            // The AMU2_{N, DSA, DDA, DCNT, DCKS, DCCR, CCR1, CCR2}CHn registers can
            // safely be written while the ALU is executing.
            // This flag is cleared by a read of this register (r1c); reads of AMU2_SEINCCHn do not
            // clear this flag.
            // 0 No register conflict error
            // 1 An AMU2 register conflict error was detected
            vuint32_t unused_0:1;
            vuint32_t DEIRQ:1;
            // ADMA Error Interrupt Request
            // This flag is set to signal the ADMA has detected an error.
            // The error conditions which set this indicator flag include:
            // – Multi-bit ECC event during a data transfer (ADMERR = 1)
            // – Bus error termination during a data transfer (ADMERR = 1)
            // – Detection of a checksum error (CKSERR = 1)
            // The subsequent system behavior is defined by the AMU2_DCCRCHn[DEICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position.
            // A read of this register does not affect the state of this indicator bit.
            // 0 ADMA has not detected an error
            // 1 ADMA has detected an error.
            vuint32_t ADIRQ:1;
            ADMA Interrupt Request
            // This flag is set to signal the ADMA has completed its data transfer. This flag is not set
            // when streaming P3[*] or V[*] data, or both, completes.
            // The subsequent system behavior is defined by the AMU2_DCCRCHn[ADICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_DCCRCHn[ADICFG] = 0b0-. For other configuration values, the SDMA
            // hardware provides an acknowledgment signal which clears this indicator bit. A read of
            // this register does not affect the state of this indicator bit.
            // 0 ADMA has not completed its data transfer
            // 1 ADMA has completed its data transfer
            vuint32_t ERIRQ:1;
            // ALU Error Interrupt Request
            // This flag is set to signal the ALU has detected certain errors.
            // The error conditions which set this indicator flag include:
            // – Multi-bit ECC event on an ARAM read by the ALU (ECCERR = 1)
            // – -Detection of a register conflict error (RGCERR = 1)
            // – Detection of an input data validation error (IDVERR = 1)
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[AEICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position.
            // A read of this register does not affect the state of this indicator bit.
            // 0 ALU has not detected an error
            // 1 ALU has detected an error
            vuint32_t OVIRQ:1;
            // ALU Overflow Interrupt Request
            // This flag is set to signal the ALU has detected an overflow condition.
            // The error conditions which set this indicator flag include:
            // – Arithmetic overflow during stage1 (S1AFLT = 1), stage2 (S23AFLT = 1), or stage3
            // (S23AFLT = 1)
            // – Overflow when performing 64-bit to 32-bit conversions for ut[*] (S1AFLT = 1), t
            // (S23AFLT = 1), y (YCAFLT = 1), z (ZCAFLT =1)
            // The ALU halts execution at specific places within the algorithm if an overflow is
            // detected: stage1 overflows halt at the end of its calculation, stage2 overflows halt at
            // the completion of the outer loop iteration and stage3 overflows complete at the end of
            // its calculation. See Table 2288: ALU Completion State Details in AMU2_SEIRCHn for
            // additional details.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[OVICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position.
            // A read of this register does not affect the state of this indicator bit.
            // 0 ALU has not detected an overflow condition
            // 1 ALU has detected an overflow condition
            vuint32_t NCIRQ:1;
            // ALU N Crossing Interrupt Request
            // This flag is set to signal the ALU has completed “N” iterations of the stage2 calculation
            // in response to a properly configured N crossing event.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[NCICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_CCR1CHn[NCICFG] = 0b0-. For other configuration values, the SDMA or
            // ADMA hardware provides an acknowledgment signal which clears this indicator bit. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ALU has not completed N iterations of a properly-configured N crossing event
            // 1 ALU has completed N iterations of a properly-configured N crossing event
            vuint32_t DNIRQ:1;
            // ALU Done Interrupt Request
            // This flag is set to signal the ALU has successfully completed an error-free calculation.
            // The subsequent system behavior is defined by the AMU2_CCR1CHn[DNICFG] field.
            // This flag must be cleared by an explicit write of a 1 (“write 1 clear”) to the bit position if
            // AMU2_CCR1CHn[DNICFG] = 0b0-. For other configuration values, the SDMA or
            // ADMA hardware provides an acknowledgment signal which clears this indicator bit. A
            // read of this register does not affect the state of this indicator bit.
            // 0 ALU has not completed its calculation
            // 1 ALU has completed its calculation
        } B;
    } SEINCCH;

    union {
        vuint32_t R; // Reset Value (=0x00000000)
        struct {
            vuint32_t IEEE32:32;
            // Single-precision version (IEEE 32-bit floating-point format) of the 64-bit result
            // (y64) value.
        } B;
    } Y32CH;

    vuint8_t AMU_reserved4[76];
  } CH[2];

};

#define AMU                                      (*(volatile struct AMU_tag *) 0xf40c0000UL)

*/

// Details on register format and data types are availble in chapter 88.3.4

// First possible use case: Single calculation using a CPU as the master device

/*

For this scenario, a processor core performs all the required data loading, moving the
coefficients and parameters from system Flash into the ARAM and then initializing all the
corresponding pointer and parameter registers. Once the data load and register initialization
are completed, the calculation is started by writing the AMU2_CCR{1,2}CHn registers. In
this case, the AMU completion and error indicators are configured to generate interrupts to
the processor; the calculation actually begins when the AMU2_CCR2CHn[S1SRT, S23SRT]
bits are set.
The AMU2 performs the calculation and then typically generates an interrupt, signaling
successful completion or some type of error termination or an N crossing debug event.
As the processor handles the interrupt, the 64-bit double precision result
(AMU2_RES64{M,L}CHn) is retrieved along with the status flags in the AMU2_SEIRCHn
register. After processing the interrupt, the service routine clears the interrupt source by
writing a “1” to clear the appropriate flag in the low-order byte of the AMU2_SEIRCHn
register. The processor then performs any required analysis of the status indicators before
saving the result.
The preceding description assumes the processor is interrupted when the AMU2 completes
as this would be the typical scenario. The AMU2 also provides a channel busy flag
(AMU2_SEIRCHn[CHBSY]) that the processor can poll to determine whether the calculation
is finished.

*/

/*
The 32 KB physical address space allocated to the AMU’s local RAM (ARAM) is segmented
into 2 regions. The first, a 31 KB space (offset addresses = 0x0_0000 - 0x0_7BFF), is
intended for user-defined storage of the AMU input data. The second, a 1 KB space (offset
addresses = 0x0_7C00 - 0x0_7FFF) is used by the AMU2 for temporary storage. This RAM
space is used by the calculation engines to temporarily store the UT[*] vector generated as
the stage1 output; additionally, it implements small FIFO memories to store “streamed data”
associated with the V[*] and P3[*] vectors. The specific memory allocation within this 1 KB
space is shown in Table 2247. Note if the streaming feature for the V[*] and P3[*] vectors is
not enabled, the first 768 bytes of this 1 KB space can be used for general purpose ARAM
data storage.
Given the 32 KB physical address space associated with the ARAM, all the pointers for this
memory are implemented as 15-bit byte addresses that define the offset into the local
memory. These local memory pointers are restricted to reference data items on their natural
size boundaries, for example, with a 0-modulo-2 byte addresses (2-byte aligned) for 16-bit
data, 0-modulo-4 byte addresses (4-byte aligned) for 32-bit data and 0-modulo-8 byte
addresses (8-byte aligned) for 64-bit data. Additionally, software must manage the pointer
values near the end of the address ranges as the hardware pointer calculations do not
perform any special handling near the 31 KB or 32 KB boundaries.
*/

/*

Inf - Inf // ieee32 = 0x7fc0_0001, ieee64 = 0x7ff8_0000_0000_0001
Inf * 0// ieee32 = 0x7fc0_0002, ieee64 = 0x7ff8_0000_0000_0002
0 * Inf// ieee32 = 0x7fc0_0003, ieee64 = 0x7ff8_0000_0000_0003
FMA(0, Inf, x)// ieee32 = 0x7fc0_0004, ieee64 = 0x7ff8_0000_0000_0004
FMA(Inf, 0, x)// ieee32 = 0x7fc0_0005, ieee64 = 0x7ff8_0000_0000_0005
FMA(Inf, 0, -Inf)// ieee32 = 0x7fc0_0006, ieee64 = 0x7ff8_0000_0000_0006
FMA(x, Inf, -Inf)// ieee32 = 0x7fc0_0006, ieee64 = 0x7ff8_0000_0000_0006

*/

/* The following definition is used when converting an ieee64 NaN into an ieee32 NaN: 
  ieee32[31] = ieee64[63]// copy the sign bit
  ieee32[30:23] = 0xff // exponent = maximum
  ieee32[22] = ieee64[51]// copy (signaling, quiet) bit from the ieee64 NaN
  ieee32[21:0] = if (ieee64[50:22] == 0) then ieee64[21:0] else 0x3f_ffff
*/

// problems in compiling with these definitions, used elsewhere, don't know where

// ieee32 ieee32Result;
// ieee64 ieee64Result;
// int32_t ARAM_DACCESS_SIZE = 31744;
// int32_t ARAM_ALU_STORAGE_SIZE = 1.024;


#endif

void AMUInit( volatile struct AMU_tag * amu,struct ADMAChannels_tag * adma_channels);

/*

  ieee32* ut, // pointer to ut[p7] 32-bit single data array
  uint01 v16, // v[p6*p7] is 16-bit data array
  uint01 vfh, // v[p6*p7] is 16-bit half precision float
  ieee32* v32f, // pointer to v[p6*p7] as ieee32
  ieee16* v16h, // pointer to v[p6*p7] as ieee16
  uint16* v16x, // pointer to v[p6*p7] as 16-bit fixed-point
  uint07 cmExp, // v[p6*p7] common exponent for 16-bit fixed
  ieee32* L, // pointer to L[p7] 32-bit single data array
  ieee32* p3, // pointer to p3[p7] 32-bit single data array
  ieee32 p4, // scalar factor in the output normalization
  ieee32 p5, // optional start value in the output normalization
  uint16 p6, // size of the ASC function
  uint05 p7, // dimension of the ASC function
  uint16 p8, // outer stage2 "for" loop count
  ieee64 p9, // starting value of double-precision y accumulator
  uint01 setz, // configuration to define initial z64 value
  ieee64 y64, // 64-bit double-precision outer loop output value
  ieee32 y32, // 32-bit single-precision version of y64
  ieee64 z64, // 64-bit double-precision final output value
  ieee32 z32 // 32-bit single-precision version of final output
*/

// CPU -> CPU used to perform transfers from RAM to ARAM (slower)
// SDMA -> SDMA used to perform transfers from RAM to ARAM (faster)
// ADMA -> ADMA used to perform transfers from RAM to ARAM (fastest)
// mode -> from 0 to 2
void AMUAddInputs(unsigned int mode, volatile struct AMU_tag * amu, struct ADMAChannels_tag * adma_channels, volatile struct AMU_params_tag * amu_params, volatile struct EDMA_tag * edma_0, volatile struct EDMA_tag * edma_1,unsigned int edma_channel, bool p3StreamingEnabled, bool VStreamingEnabled);

// void amuStage1(
//   ieee32* u, // pointer to u[p7] 32-bit single data array
//   ieee32* p1, // pointer to p1[p7] 32-bit single data array
//   ieee32* p2, // pointer to p2[p7] 32-bit single data array
//   ieee32* ut, // pointer to ut[p7] 32-bit single data array
//   uint05 p7 // dimension of the ASC function, so is max 2^5 = 32
// );

// void amuStage23(
//   ieee32* ut, // pointer to ut[p7] 32-bit single data array
//   uint01 v16, // v[p6*p7] is 16-bit data array
//   uint01 vfh, // v[p6*p7] is 16-bit half precision float
//   ieee32* v32f, // pointer to v[p6*p7] as ieee32
//   ieee16* v16h, // pointer to v[p6*p7] as ieee16
//   uint16* v16x, // pointer to v[p6*p7] as 16-bit fixed-point
//   uint07 cmExp, // v[p6*p7] common exponent for 16-bit fixed
//   ieee32* L, // pointer to L[p7] 32-bit single data array
//   ieee32* p1, // pointer to p1[p7] 32-bit single data array
//   ieee32* p3, // pointer to p3[p7] 32-bit single data array
//   ieee32 p4, // scalar factor in the output normalization
//   ieee32 p5, // optional start value in the output normalization
//   uint16 p6, // size of the ASC function
//   uint05 p7, // dimension of the ASC function
//   uint16 p8, // outer stage2 "for" loop count
//   ieee64 p9, // starting value of double-precision y accumulator
//   uint01 setz, // configuration to define initial z64 value
//   ieee64 y64, // 64-bit double-precision outer loop output value
//   ieee32 y32, // 32-bit single-precision version of y64
//   ieee64 z64, // 64-bit double-precision final output value
//   ieee32 z32 // 32-bit single-precision version of final output
// );

void AMUExec(volatile struct AMU_tag * amu, int numUsedADMAChannels, bool p3StreamingEnabled, bool VStreamingEnabled);
/*
As previously described, a single-precision evaluation of the exp(x) is a key function in the
defined algorithm (part of the stage2 outer loop calculations). The AMU2’s implementation
consists of four steps:
1. Special case analysis, for example, value out of range produces +Inf
2. Argument reduction
3. Function evaluation
4. Range reconstruction

The first step of the exp(x) function consists of a series of conditional tests to filter out these
special cases and perform the proper operation, for example returning an infinity when the
input argument is too large.

Standard algorithms for exp(x) typically approximate ex in a bounded domain, typically
defined as [-ln(2)/2, ln(2)/2] or [0, ln(2)]. The AMU2 implementation uses the [0, ln(2)) range.
Further, the following mathematical identity is applied to the function definition:
e^x = e^(E*ln(2)+z) = (e^ln(2))^E * e^z = 2^E * e^z
where E is a signed integer and z is such that |z| < ln(2). After a series of arithmetic
manipulations, z and E can be computed as:
E = int(x / ln(2))
z = x - E * ln(2)
where E is the integer part of the (x/ln(2)) computation with the same sign.
Further, the ez computation can be rewritten as:
e^z = e^(A+B) = e^A * e^B
The range of the input argument can be further reduced by rewriting z as the sum of two
fixed-point numbers such that z = A + B. This can be accomplished trivially by assigning the
first n bits of z to A and the remaining bits of z to B. For the AMU2, the first 6 bits of the input
argument are assigned to A, and the remaining 17 bits to B, thus allowing the use of a
simple 64-element lookup table to compute eA and a polynomial approximation for eB.

The next step is the selection of a polynomial approximation of eB that is sufficiently
accurate in the range [0, ln(2)/64]. In the AMU2, a Minimax approximation is used to model
the ex function with a low-degree polynomial. Minimax approximations are polynomials of
degree N that calculate a given function within a given interval such that the absolute
maximum error is minimized. This allows an error bound on the approximation without
incurring unnecessary terms in the polynomial.
The difficult part of finding a Minimax polynomial is the iterative nature of the algorithm to
compute the coefficients. For this, the Remez Algorithm as implemented in an indefinite
precision solver is applied. The form of the polynomial is:
f(x) = a0 + a1 * x + a2 * x2 + a3 * x3 + ...
Using the Remez Algorithm, the function implements a three-term expression of the form:
exp(x) = 1 + x * (C0 + x * (C1 + x* C2))
where Cn represent the required coefficients and x is the range-limited input argument. This
produces the following expression in a more typical polynomial form:
exp(x) = 1 + C0 * x + C1 * x2 + C2 * x3
In solving for the Cn coefficients to provide the minimum error, it becomes obvious that C0 is
very close to 1.0 and C1 is reasonably close to 0.5. Since the assignment of these two
coefficients to these constants allows a simplified hardware implementation, the next step is
calculation of a revised C2 coefficient to account for the simplifications involving C0 and C1.
This calculation produces the following coefficient values:
C0 = 1.0
C1 = 0.5
C2 = 0.167876224340382
Using this form of the exp(x) function and comparing its precision and accuracy versus
Excel’s computation of ex over the range [0, ln(2)/64] shows the following results:
• Error terms approximately bounded as [-7.0E-10, +7.0E-10]
• > 30 bits of precision across the entire input range
The AMU2 limits the datapath width to 25 bits to minimize the exp() implementation cost.

The final step in the exp(x) function is the use of multiplicative range reconstruction to return
the answer back into the proper range. Recall the equations of interest are:
e^x = 2^E * e^z
e^z = e^(A + B) = e^A * e^B
exp(x) = 2^E * e^A * e^B
where E was calculated during argument reduction, e^A from a table lookup and e^B using the
polynomial evaluation. Finally, the result must be converted into a single-precision floating
point number. Due to the nature of floating point numbers, this is a simple step; because the
range of z is [0, ln(2)), the range of ez is [1, 2). Since floating point numbers must be
normalized to the range [1, 2), the result is guaranteed to be normalized, and in the proper
range. The calculated ez is stored as the single-precision mantissa and E as the exponent.
Note: If the exp(x) evaluation generates an overflow, the single-precision function result is set to
positive infinity (+Inf = 0x7F800000). Likewise, if an underflow is generated, the result is set
to a positive zero (+0 = 0x00000000).
The AMU2 includes a single instance of the exp(x) hardware function which is shared via
time-multiplexing across the two calculation channels.
*/

/*

Stop ALU calculation, check progress, then resume:
For this basic stop/resume sequence, the following steps are needed:
1. Set AMU2_CCR2CHn[S23STP] = 1.
2. Wait for AMU2_CCR2CHn[S23STP] to (auto)clear, indicating the stop request has
been processed and the ALU has entered the stopped state. The ALU's stopped state
is signaled by AMU2_SEIRCHn[S23XS] = 2 (stopped).
3. Check calculation progress as needed.
4. Resume the calculation by setting AMU2_CCR2CHn[S23RSM] = 1. As the ALU
continues the calculation, AMU2_SEIRCHn[S23XS] = 11 (running).
This sequence can be used whether P3[*] or V[*], or both, streaming is enabled or not. If
data streaming is enabled, the stopping of the ALU automatically causes the ADMA to stop
fetching data since the data transfers are paced by the ALU execution.
If a stop request is made during the final iteration of the stage2 outer loop, the AMU honors
the request and stops prior to executing stage3.

*/

void AMUGetResults( volatile struct AMU_tag * amu, struct ADMAChannels_tag * adma_channels, struct AMUResults_tag * amu_results);

void ALUstopCheckResume( volatile struct AMU_tag * amu , bool ADMACH0Used, bool ADMACH1Used);

/*
Stop ALU calculation, perform a new calculation, then restore and resume the original calculation:
For this stop/resume sequence, the following steps are needed:
1. Set AMU2_CCR2CHn[S23STP] = 1.
2. Wait for AMU2_CCR2CHn[S23STP] to (auto)clear, indicating the stop request has
been processed and the ALU has entered the stopped state. The ALU's stopped state
is signaled by AMU2_SEIRCHn[S23XS] = 2 (stopped).
3. Temporarily save the contents of the required programming model. This includes the
AMU2_{P3PTR, P4, P5, P6, P7, P8, VPTR, LPTR, CCR{1,2}, Y64, RES32} registers
as well as the CHn UT[*] in the ARAM data FIFO.
4. Load the new data set, execute the calculation, store the results as required.
5. Restore the saved data contents from Step 3, including restoring the saved Y64 to P9
and RES32 to P5 (see Note below).
6. Continue the calculation by setting AMU2_CCR2CHn[S23SRT] = 1. As the ALU
continues the calculation, AMU2_SEIRCHn[S23XS] = 11 (running).
Again, this sequence can be used whether P3[*] or V[*], or both, streaming is enabled or
not. This sequence assumes the two calculations do not corrupt each other’s input data in
ARAM, otherwise software must save/restore the ARAM contents as required.
Note: In the case where the interrupted calculation is configured to initialize Z to P5 as indicated
by AMU2_CCR1CHn[SETZ] = 1, then P5 is restored to the original P5 value. Otherwise, P5
is restored to the saved RES32 value. Note that in the latter case, the double precision
RES64 value is lost when resuming the interrupted calculation as only the single-precision
RES32 can be saved and restored using P5.
*/

void ALUstopNewCalcRestoreResume( volatile struct AMU_tag * amu, bool ADMACH0Used, bool ADMACH1Used);

// EDMA Struct

// struct EDMA_tag {
//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t unused_1:14;
//             vuint32_t CX:1;
//             vuint32_t ECX:1;
//             vuint32_t GRP3PRI:2;
//             vuint32_t GRP2PRI:2;
//             vuint32_t GRP1PRI:2;
//             vuint32_t GRP0PRI:2;
//             vuint32_t EMLM:1;
//             vuint32_t CLM:1;
//             vuint32_t HALT:1;
//             vuint32_t HOE:1;
//             vuint32_t ERGA:1;
//             vuint32_t ERCA:1;
//             vuint32_t EDBG:1;
//             vuint32_t unused_0:1;
//         } B;
//     } CR;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t VLD:1;
//             vuint32_t unused_0:13;
//             vuint32_t UCE:1;
//             vuint32_t ECX:1;
//             vuint32_t GPE:1;
//             vuint32_t CPE:1;
//             vuint32_t ERRCHN:6;
//             vuint32_t SAE:1;
//             vuint32_t SOE:1;
//             vuint32_t DAE:1;
//             vuint32_t DOE:1;
//             vuint32_t NCE:1;
//             vuint32_t SGE:1;
//             vuint32_t SBE:1;
//             vuint32_t DBE:1;
//         } B;
//     } ES;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t ERQ63:1;
//             vuint32_t ERQ62:1;
//             vuint32_t ERQ61:1;
//             vuint32_t ERQ60:1;
//             vuint32_t ERQ59:1;
//             vuint32_t ERQ58:1;
//             vuint32_t ERQ57:1;
//             vuint32_t ERQ56:1;
//             vuint32_t ERQ55:1;
//             vuint32_t ERQ54:1;
//             vuint32_t ERQ53:1;
//             vuint32_t ERQ52:1;
//             vuint32_t ERQ51:1;
//             vuint32_t ERQ50:1;
//             vuint32_t ERQ49:1;
//             vuint32_t ERQ48:1;
//             vuint32_t ERQ47:1;
//             vuint32_t ERQ46:1;
//             vuint32_t ERQ45:1;
//             vuint32_t ERQ44:1;
//             vuint32_t ERQ43:1;
//             vuint32_t ERQ42:1;
//             vuint32_t ERQ41:1;
//             vuint32_t ERQ40:1;
//             vuint32_t ERQ39:1;
//             vuint32_t ERQ38:1;
//             vuint32_t ERQ37:1;
//             vuint32_t ERQ36:1;
//             vuint32_t ERQ35:1;
//             vuint32_t ERQ34:1;
//             vuint32_t ERQ33:1;
//             vuint32_t ERQ32:1;
//         } B;
//     } ERQH;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t ERQ31:1;
//             vuint32_t ERQ30:1;
//             vuint32_t ERQ29:1;
//             vuint32_t ERQ28:1;
//             vuint32_t ERQ27:1;
//             vuint32_t ERQ26:1;
//             vuint32_t ERQ25:1;
//             vuint32_t ERQ24:1;
//             vuint32_t ERQ23:1;
//             vuint32_t ERQ22:1;
//             vuint32_t ERQ21:1;
//             vuint32_t ERQ20:1;
//             vuint32_t ERQ19:1;
//             vuint32_t ERQ18:1;
//             vuint32_t ERQ17:1;
//             vuint32_t ERQ16:1;
//             vuint32_t ERQ15:1;
//             vuint32_t ERQ14:1;
//             vuint32_t ERQ13:1;
//             vuint32_t ERQ12:1;
//             vuint32_t ERQ11:1;
//             vuint32_t ERQ10:1;
//             vuint32_t ERQ9:1;
//             vuint32_t ERQ8:1;
//             vuint32_t ERQ7:1;
//             vuint32_t ERQ6:1;
//             vuint32_t ERQ5:1;
//             vuint32_t ERQ4:1;
//             vuint32_t ERQ3:1;
//             vuint32_t ERQ2:1;
//             vuint32_t ERQ1:1;
//             vuint32_t ERQ0:1;
//         } B;
//     } ERQL;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t EEI63:1;
//             vuint32_t EEI62:1;
//             vuint32_t EEI61:1;
//             vuint32_t EEI60:1;
//             vuint32_t EEI59:1;
//             vuint32_t EEI58:1;
//             vuint32_t EEI57:1;
//             vuint32_t EEI56:1;
//             vuint32_t EEI55:1;
//             vuint32_t EEI54:1;
//             vuint32_t EEI53:1;
//             vuint32_t EEI52:1;
//             vuint32_t EEI51:1;
//             vuint32_t EEI50:1;
//             vuint32_t EEI49:1;
//             vuint32_t EEI48:1;
//             vuint32_t EEI47:1;
//             vuint32_t EEI46:1;
//             vuint32_t EEI45:1;
//             vuint32_t EEI44:1;
//             vuint32_t EEI43:1;
//             vuint32_t EEI42:1;
//             vuint32_t EEI41:1;
//             vuint32_t EEI40:1;
//             vuint32_t EEI39:1;
//             vuint32_t EEI38:1;
//             vuint32_t EEI37:1;
//             vuint32_t EEI36:1;
//             vuint32_t EEI35:1;
//             vuint32_t EEI34:1;
//             vuint32_t EEI33:1;
//             vuint32_t EEI32:1;
//         } B;
//     } EEIH;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t EEI31:1;
//             vuint32_t EEI30:1;
//             vuint32_t EEI29:1;
//             vuint32_t EEI28:1;
//             vuint32_t EEI27:1;
//             vuint32_t EEI26:1;
//             vuint32_t EEI25:1;
//             vuint32_t EEI24:1;
//             vuint32_t EEI23:1;
//             vuint32_t EEI22:1;
//             vuint32_t EEI21:1;
//             vuint32_t EEI20:1;
//             vuint32_t EEI19:1;
//             vuint32_t EEI18:1;
//             vuint32_t EEI17:1;
//             vuint32_t EEI16:1;
//             vuint32_t EEI15:1;
//             vuint32_t EEI14:1;
//             vuint32_t EEI13:1;
//             vuint32_t EEI12:1;
//             vuint32_t EEI11:1;
//             vuint32_t EEI10:1;
//             vuint32_t EEI9:1;
//             vuint32_t EEI8:1;
//             vuint32_t EEI7:1;
//             vuint32_t EEI6:1;
//             vuint32_t EEI5:1;
//             vuint32_t EEI4:1;
//             vuint32_t EEI3:1;
//             vuint32_t EEI2:1;
//             vuint32_t EEI1:1;
//             vuint32_t EEI0:1;
//         } B;
//     } EEIL;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t SAER:1;
//             vuint8_t SERQ:6;
//         } B;
//     } SERQ;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t CAER:1;
//             vuint8_t CERQ:6;
//         } B;
//     } CERQ;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t SAEE:1;
//             vuint8_t SEEI:6;
//         } B;
//     } SEEI;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t CAEE:1;
//             vuint8_t CEEI:6;
//         } B;
//     } CEEI;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t CAIR:1;
//             vuint8_t CINT:6;
//         } B;
//     } CINT;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t CAEI:1;
//             vuint8_t CERR:6;
//         } B;
//     } CERR;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t SAST:1;
//             vuint8_t SSRT:6;
//         } B;
//     } SSRT;

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t NOP:1;
//             vuint8_t CADN:1;
//             vuint8_t CDNE:6;
//         } B;
//     } CDNE;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t INT63:1;
//             vuint32_t INT62:1;
//             vuint32_t INT61:1;
//             vuint32_t INT60:1;
//             vuint32_t INT59:1;
//             vuint32_t INT58:1;
//             vuint32_t INT57:1;
//             vuint32_t INT56:1;
//             vuint32_t INT55:1;
//             vuint32_t INT54:1;
//             vuint32_t INT53:1;
//             vuint32_t INT52:1;
//             vuint32_t INT51:1;
//             vuint32_t INT50:1;
//             vuint32_t INT49:1;
//             vuint32_t INT48:1;
//             vuint32_t INT47:1;
//             vuint32_t INT46:1;
//             vuint32_t INT45:1;
//             vuint32_t INT44:1;
//             vuint32_t INT43:1;
//             vuint32_t INT42:1;
//             vuint32_t INT41:1;
//             vuint32_t INT40:1;
//             vuint32_t INT39:1;
//             vuint32_t INT38:1;
//             vuint32_t INT37:1;
//             vuint32_t INT36:1;
//             vuint32_t INT35:1;
//             vuint32_t INT34:1;
//             vuint32_t INT33:1;
//             vuint32_t INT32:1;
//         } B;
//     } INTH;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t INT31:1;
//             vuint32_t INT30:1;
//             vuint32_t INT29:1;
//             vuint32_t INT28:1;
//             vuint32_t INT27:1;
//             vuint32_t INT26:1;
//             vuint32_t INT25:1;
//             vuint32_t INT24:1;
//             vuint32_t INT23:1;
//             vuint32_t INT22:1;
//             vuint32_t INT21:1;
//             vuint32_t INT20:1;
//             vuint32_t INT19:1;
//             vuint32_t INT18:1;
//             vuint32_t INT17:1;
//             vuint32_t INT16:1;
//             vuint32_t INT15:1;
//             vuint32_t INT14:1;
//             vuint32_t INT13:1;
//             vuint32_t INT12:1;
//             vuint32_t INT11:1;
//             vuint32_t INT10:1;
//             vuint32_t INT9:1;
//             vuint32_t INT8:1;
//             vuint32_t INT7:1;
//             vuint32_t INT6:1;
//             vuint32_t INT5:1;
//             vuint32_t INT4:1;
//             vuint32_t INT3:1;
//             vuint32_t INT2:1;
//             vuint32_t INT1:1;
//             vuint32_t INT0:1;
//         } B;
//     } INTL;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t ERR63:1;
//             vuint32_t ERR62:1;
//             vuint32_t ERR61:1;
//             vuint32_t ERR60:1;
//             vuint32_t ERR59:1;
//             vuint32_t ERR58:1;
//             vuint32_t ERR57:1;
//             vuint32_t ERR56:1;
//             vuint32_t ERR55:1;
//             vuint32_t ERR54:1;
//             vuint32_t ERR53:1;
//             vuint32_t ERR52:1;
//             vuint32_t ERR51:1;
//             vuint32_t ERR50:1;
//             vuint32_t ERR49:1;
//             vuint32_t ERR48:1;
//             vuint32_t ERR47:1;
//             vuint32_t ERR46:1;
//             vuint32_t ERR45:1;
//             vuint32_t ERR44:1;
//             vuint32_t ERR43:1;
//             vuint32_t ERR42:1;
//             vuint32_t ERR41:1;
//             vuint32_t ERR40:1;
//             vuint32_t ERR39:1;
//             vuint32_t ERR38:1;
//             vuint32_t ERR37:1;
//             vuint32_t ERR36:1;
//             vuint32_t ERR35:1;
//             vuint32_t ERR34:1;
//             vuint32_t ERR33:1;
//             vuint32_t ERR32:1;
//         } B;
//     } ERRH;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t ERR31:1;
//             vuint32_t ERR30:1;
//             vuint32_t ERR29:1;
//             vuint32_t ERR28:1;
//             vuint32_t ERR27:1;
//             vuint32_t ERR26:1;
//             vuint32_t ERR25:1;
//             vuint32_t ERR24:1;
//             vuint32_t ERR23:1;
//             vuint32_t ERR22:1;
//             vuint32_t ERR21:1;
//             vuint32_t ERR20:1;
//             vuint32_t ERR19:1;
//             vuint32_t ERR18:1;
//             vuint32_t ERR17:1;
//             vuint32_t ERR16:1;
//             vuint32_t ERR15:1;
//             vuint32_t ERR14:1;
//             vuint32_t ERR13:1;
//             vuint32_t ERR12:1;
//             vuint32_t ERR11:1;
//             vuint32_t ERR10:1;
//             vuint32_t ERR9:1;
//             vuint32_t ERR8:1;
//             vuint32_t ERR7:1;
//             vuint32_t ERR6:1;
//             vuint32_t ERR5:1;
//             vuint32_t ERR4:1;
//             vuint32_t ERR3:1;
//             vuint32_t ERR2:1;
//             vuint32_t ERR1:1;
//             vuint32_t ERR0:1;
//         } B;
//     } ERRL;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t HRS63:1;
//             vuint32_t HRS62:1;
//             vuint32_t HRS61:1;
//             vuint32_t HRS60:1;
//             vuint32_t HRS59:1;
//             vuint32_t HRS58:1;
//             vuint32_t HRS57:1;
//             vuint32_t HRS56:1;
//             vuint32_t HRS55:1;
//             vuint32_t HRS54:1;
//             vuint32_t HRS53:1;
//             vuint32_t HRS52:1;
//             vuint32_t HRS51:1;
//             vuint32_t HRS50:1;
//             vuint32_t HRS49:1;
//             vuint32_t HRS48:1;
//             vuint32_t HRS47:1;
//             vuint32_t HRS46:1;
//             vuint32_t HRS45:1;
//             vuint32_t HRS44:1;
//             vuint32_t HRS43:1;
//             vuint32_t HRS42:1;
//             vuint32_t HRS41:1;
//             vuint32_t HRS40:1;
//             vuint32_t HRS39:1;
//             vuint32_t HRS38:1;
//             vuint32_t HRS37:1;
//             vuint32_t HRS36:1;
//             vuint32_t HRS35:1;
//             vuint32_t HRS34:1;
//             vuint32_t HRS33:1;
//             vuint32_t HRS32:1;
//         } B;
//     } HRSH;

//     union {
//         vuint32_t R;
//         struct {
//             vuint32_t HRS31:1;
//             vuint32_t HRS30:1;
//             vuint32_t HRS29:1;
//             vuint32_t HRS28:1;
//             vuint32_t HRS27:1;
//             vuint32_t HRS26:1;
//             vuint32_t HRS25:1;
//             vuint32_t HRS24:1;
//             vuint32_t HRS23:1;
//             vuint32_t HRS22:1;
//             vuint32_t HRS21:1;
//             vuint32_t HRS20:1;
//             vuint32_t HRS19:1;
//             vuint32_t HRS18:1;
//             vuint32_t HRS17:1;
//             vuint32_t HRS16:1;
//             vuint32_t HRS15:1;
//             vuint32_t HRS14:1;
//             vuint32_t HRS13:1;
//             vuint32_t HRS12:1;
//             vuint32_t HRS11:1;
//             vuint32_t HRS10:1;
//             vuint32_t HRS9:1;
//             vuint32_t HRS8:1;
//             vuint32_t HRS7:1;
//             vuint32_t HRS6:1;
//             vuint32_t HRS5:1;
//             vuint32_t HRS4:1;
//             vuint32_t HRS3:1;
//             vuint32_t HRS2:1;
//             vuint32_t HRS1:1;
//             vuint32_t HRS0:1;
//         } B;
//     } HRSL;

//     vuint8_t ADR_reserved0[200];

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t ECP:1;
//             vuint8_t DPA:1;
//             vuint8_t GRPPRI:2;
//             vuint8_t CHPRI:4;
//         } B;
//     } DCHPRI[64];

//     union {
//         vuint8_t R;
//         struct {
//             vuint8_t EMI:1;
//             vuint8_t PAL:1;
//             vuint8_t unused_0:2;
//             vuint8_t MID:4;
//         } B;
//     } DCHMID[64];

//     vuint8_t ADR_reserved1[3712];

//     struct {
//         union {
//             vuint32_t R;
//             struct {
//                 vuint32_t SADDR:32;
//             } B;
//         } TCD_SADDR;

//         union {
//             vuint16_t R;
//             struct {
//                 vuint16_t SMOD:5;
//                 vuint16_t SSIZE:3;
//                 vuint16_t DMOD:5;
//                 vuint16_t DSIZE:3;
//             } B;
//         } TCD_ATTR;

//         union {
//             vuint16_t R;
//             struct {
//                 vuint16_t SOFF:16;
//             } B;
//         } TCD_SOFF;

//         union {
//             vuint32_t R;
//             struct {
//                 vuint32_t SMLOE:1;
//                 vuint32_t DMLOE:1;
//                 vuint32_t MLOFF:20;
//                 vuint32_t NBYTES:10;
//             } B_MLOFFYES;
//             struct {
//                 vuint32_t SMLOE:1;
//                 vuint32_t DMLOE:1;
//                 vuint32_t NBYTES:30;
//             } B_MLOFFNO;
//             struct {
//                 vuint32_t NBYTES:32;
//             } B_MLNO;
//         } TCD_NBYTES;

//         union {
//             vuint32_t R;
//             struct {
//                 vuint32_t SLAST:32;
//             } B;
//         } TCD_SLAST;

//         union {
//             vuint32_t R;
//             struct {
//                 vuint32_t DADDR:32;
//             } B;
//         } TCD_DADDR;

//         union {
//             vuint16_t R;
//             struct {
//                 vuint16_t ELINK:1;
//                 vuint16_t LINKCH:6;
//                 vuint16_t CITER:9;
//             } B_ELINKYES;
//             struct {
//                 vuint16_t ELINK:1;
//                 vuint16_t CITER:15;
//             } B_ELINKNO;
//         } TCD_CITER;

//         union {
//             vuint16_t R;
//             struct {
//                 vuint16_t DOFF:16;
//             } B;
//         } TCD_DOFF;

//         union {
//             vuint32_t R;
//             struct {
//                 vuint32_t DLASTSGA:32;
//             } B;
//         } TCD_DLASTSGA;

//         union {
//             vuint16_t R;
//             struct {
//                 vuint16_t ELINK:1;
//                 vuint16_t LINKCH:6;
//                 vuint16_t BITER:9;
//             } B_ELINKYES;
//             struct {
//                 vuint16_t ELINK:1;
//                 vuint16_t BITER:15;
//             } B_ELINKNO;
//         } TCD_BITER;

//         union {
//             vuint16_t R;
//             struct {
//                 vuint16_t BWC:2;
//                 vuint16_t MAJORLINKCH:6;
//                 vuint16_t DONE:1;
//                 vuint16_t ACTIVE:1;
//                 vuint16_t MAJORELINK:1;
//                 vuint16_t ESG:1;
//                 vuint16_t DREQ:1;
//                 vuint16_t INTHALF:1;
//                 vuint16_t INTMAJOR:1;
//                 vuint16_t START:1;
//             } B;
//         } TCD_CSR;

//     } CH[64];

// };