#include <stdio.h>
#include "./amu_cfg.h"

void ADMA_StartSpeed( volatile struct AMU_tag * amu ,uint08 ADMAspeed, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.SRTSP = (vint32_t) ADMAspeed;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.SRTSP = (vint32_t) ADMAspeed;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.SRTSP = (vint32_t) ADMAspeed;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void ADMA_MaxSpeed( volatile struct AMU_tag * amu ,uint08 ADMAspeed, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.MAXSP = (vint32_t) ADMAspeed;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.MAXSP = (vint32_t) ADMAspeed;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.MAXSP = (vint32_t) ADMAspeed;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void ADMA_InterruptConfig( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.ADICFG = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.ADICFG = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.ADICFG = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_SourceAddressUpdate( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.SARU = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.SARU = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.SARU = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_DestinationAddressUpdate( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.DARU = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.DARU = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.DARU = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_HaltOnCRCError( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if(amu != NULL){
        if(usedChannel == 2){
            for(unsigned int i = 0 ; i<usedChannel; i++){
                if(amu->CH[i].DCCRCH.B.ECRC == 0){
                    amu->CH[i].DCCRCH.B.ECRC = 1;
                }
            }
        } else if (usedChannel == 1 || usedChannel == 0){
            if(amu->CH[usedChannel].DCCRCH.B.ECRC == 0){
                amu->CH[usedChannel].DCCRCH.B.ECRC = 1;
            }
        } else {
            return;
        }
    }
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.HCRCE = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.HCRCE = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.HCRCE = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_EnableCRC( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.ECRC = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.ECRC = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.ECRC = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_ClearState( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.CADS = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.CADS = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.CADS = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_DisableECC( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.DECC = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.DECC = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.DECC = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_StreamP3( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.STMP3 = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.STMP3 = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.STMP3 = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_StreamV32( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.STMV32 = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.STMV32 = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.STMV32 = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_StreamV16( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.STMV16 = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.STMV16 = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.STMV16 = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_EnableHighPriority( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.EHP = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.EHP = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.EHP = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_StopIfAluStops( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.DSAS = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.DSAS = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.DSAS = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_StopRequest( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.STP = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.STP = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.STP = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_ErrorInterruptConfiguration( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.DEICFG = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.DEICFG = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.DEICFG = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_WaitForAluDoneInterruptRequest( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.WFDNI = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.WFDNI = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.WFDNI = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_WaitForStage23Done( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.WFS23D = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.WFS23D = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.WFS23D = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_WaitForStage1Done( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.WFS1D = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.WFS1D = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.WFS1D = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_Resume( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.RSM = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.RSM = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.RSM = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_ForceAramToZero( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.FARZ = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.FARZ = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.FARZ = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ADMA_StartRequest( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].DCCRCH.B.SRT = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].DCCRCH.B.SRT = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].DCCRCH.B.SRT = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}


void ALU_StartSpeed( volatile struct AMU_tag * amu ,uint08 ALUspeed, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.SRTSP = (vint32_t) ALUspeed;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.SRTSP = (vint32_t) ALUspeed;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.SRTSP = (vint32_t) ALUspeed;
        }
        default:
            break;
        }
    } else {
        return;
    }
}


void ALU_MaxSpeed( volatile struct AMU_tag * amu ,uint08 ALUspeed, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.MAXSP = (vint32_t) ALUspeed;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.MAXSP = (vint32_t) ALUspeed;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.MAXSP = (vint32_t) ALUspeed;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void ErrorInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.AEICFG = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.AEICFG = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.AEICFG = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void OverflowInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.OVICFG = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.OVICFG = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.OVICFG = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void NCrossingInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.NCICFG = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.NCICFG = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.NCICFG = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void DoneInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.DNICFG = (vint32_t) indicatorFlag;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.DNICFG = (vint32_t) indicatorFlag;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.DNICFG = (vint32_t) indicatorFlag;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void BusPriority( volatile struct AMU_tag * amu ,uint01 priority, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.BPRI = (vint32_t) priority;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.BPRI = (vint32_t) priority;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.BPRI = (vint32_t) priority;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void EnableARAMECC( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.EECC = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.EECC = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.EECC = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void DisableDebugStall( volatile struct AMU_tag * amu ,uint01 disable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.DDSL = (vint32_t) disable;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.DDSL = (vint32_t) disable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.DDSL = (vint32_t) disable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void SetZResult( volatile struct AMU_tag * amu ,uint01 set, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.SETZ = (vint32_t) set;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.SETZ = (vint32_t) set;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.SETZ = (vint32_t) set;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void EnableSETZClear( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.ESTZC = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.ESTZC = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.ESTZC = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void V16BitDataFormat( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.V16 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.V16 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.V16 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void VFixedHalfwordFormat( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR1CH.B.VFH = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR1CH.B.VFH = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR1CH.B.VFH = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void CommonExponent( volatile struct AMU_tag * amu ,uint07 exponent, unsigned int usedChannel){
    if (usedChannel <= 2 && amu != NULL) {
        if(exponent <= 127){
            switch (usedChannel)
            {
            case 0:
                amu->CH[0].CCR1CH.B.CMEXP = (vint32_t) exponent;
                break;
            case 1:
                amu->CH[1].CCR1CH.B.CMEXP = (vint32_t) exponent;
            case 2:
                
            for(int i=0;i<2;i++){
                amu->CH[i].CCR1CH.B.CMEXP = (vint32_t) exponent;
            }
            default:
                break;
            }
        } else {
            return;
        }
    } else {
        return;
    }
}

void AlternateDCCRWriteEnable( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCRE = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCRE = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCRE = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateSTMP3( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR18 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR18 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR18 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateSTMV32( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR19 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR19 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR19 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateSTMV16( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR20 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR20 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR20 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateWFDNI( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR25 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR25 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR25 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateWFS23D( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR26 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR26 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR26 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateWFS1D( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR27 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR27 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR27 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void AlternateSRT( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ADCCR31 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ADCCR31 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ADCCR31 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void EnableNCRoSsing( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.ENCRS = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.ENCRS = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.ENCRS = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void StopOnNCRoSsing( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.SNCRS = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.SNCRS = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.SNCRS = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void ClearStageXeXecutionState( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.CSXXS = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.CSXXS = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.CSXXS = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void Stage23STopRequest( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.S23STP = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.S23STP = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.S23STP = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void WaitForSdmaCompleteBeforeStartingStage23( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.WFSS23 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.WFSS23 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.WFSS23 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}

void WaitForADmaCompleteBeforeStartingStage23( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.WFDS23 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.WFDS23 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.WFDS23 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void WaitForADmaCompleteBeforeStartingStage1( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.WFDS1 = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.WFDS1 = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.WFDS1 = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void Stage23ReSuMe( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.S23RSM = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.S23RSM = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.S23RSM = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
void Stage23StaRTRequest( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if( amu != NULL){
        if(usedChannel == 2){
            for(unsigned int i=0;i<usedChannel;i++){
                if(amu->CH[i].CCR2CH.B.S23STP != 0){
                    amu->CH[i].CCR2CH.B.S23STP = 0;
                }
            }
        } else if(usedChannel == 1 || usedChannel == 0){
            if(amu->CH[usedChannel].CCR2CH.B.S23STP != 0){
                amu->CH[usedChannel].CCR2CH.B.S23STP = 0;
            }
        } else {
            return;
        }
    }
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.S23SRT = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.S23SRT = (vint32_t) enable;
        case 2:     
            for(int i=0;i<2;i++){
                amu->CH[i].CCR2CH.B.S23SRT = (vint32_t) enable;
            }
        default:
            break;
        }
    } else {
        return;
    }
}
void Stage1StaRTRequest( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel){
    if ( usedChannel <= 2 && amu != NULL) {
        switch (usedChannel)
        {
        case 0:
            amu->CH[0].CCR2CH.B.S1SRT = (vint32_t) enable;
            break;
        case 1:
            amu->CH[1].CCR2CH.B.S1SRT = (vint32_t) enable;
        case 2:
            
        for(int i=0;i<2;i++){
            amu->CH[i].CCR2CH.B.S1SRT = (vint32_t) enable;
        }
        default:
            break;
        }
    } else {
        return;
    }
}
