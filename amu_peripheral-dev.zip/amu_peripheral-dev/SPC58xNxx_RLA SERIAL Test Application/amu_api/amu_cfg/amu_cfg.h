#ifndef AMU_CFG_H
#define AMU_CFG_H
#include "components.h"

#include "../amu_typedefs.h"

// DCCRCH configuration bits

// Start Speed
// This 3-bit encoded value defines the start speed for the ADMA channel. It is used with
// the MAXSP field and AMU2_DCNTCHn[THRHC] with the current speed of the ADMA is
// reported in AMU2_SEIRCHn[DCURSP].
// The ADMA speed control provides a mechanism to control the operation efficiency of the
// submodule for coarse power control of the AMU. See Section 88.3.6.5: ADMA speed
// control for more details on the ADMA speed control mechanism. There is a single ADMA
// speed control function shared by both channels and accessible from either the CH0 or
// CH1 programming models.
// 000 Maximum speed; speed control disabled
// 001 1/8 speed
// 010 2/8 speed
// 011 3/8 speed
// 100 4/8 speed
// 101 5/8 speed
// 110 6/8 speed
// 111 7/8 speed

// channels selections => 
// a) 0 => channel 0
// b) 1 => channel 1
// c) 2 => channel 0 and 1

void ADMA_StartSpeed( volatile struct AMU_tag * amu ,uint08 ADMAspeed, unsigned int usedChannel);

// Maximum Speed
// This 3-bit encoded value defines the maximum speed for the ADMA channel. It is used
// with the SRTSP field and AMU2_DCNTCHn[THRHC] with the current speed of the
// ADMA is reported in AMU2_SEIRCHn[DCURSP].
// The ADMA speed control provides a mechanism to control the operation efficiency of the
// submodule for coarse power control of the AMU. See Section 88.3.6.5: ADMA speed
// control for more details on the ADMA speed control mechanism. There is a single ADMA
// speed control function shared by both channels and accessible from either the CH0 or
// CH1 programming models.
// This field uses the same definition as SRTSP above.

// channels selections => 
// a) 0 => channel 0
// b) 1 => channel 1
// c) 2 => channel 0 and 1

void ADMA_MaxSpeed( volatile struct AMU_tag * amu ,uint08 ADMAspeed, unsigned int usedChannel);

// ADma Interrupt ConFiGuration
// This 2-bit field provides the reporting mechanism associated with the ADMA complete
// indicator flag (AMU2_SEIRCHn[ADIRQ]).
// 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ADMA completion
// 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software
// 10 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
// acknowledgement
// 11 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
// acknowledgement

void ADMA_InterruptConfig( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// Source Address Register Update
// This 2-bit field controls the updating of the AMU2_DSACHn register.
// 00 ADMA does not modify the original starting value of AMU2_DSACHn
// 01 ADMA does not modify the original starting value of AMU2_DSACHn
// 10 ADMA increments the AMU2_DSACHn as the data transfer occurs. The final value
// points to the next 8-byte aligned system Flash address
// 11 ADMA increments the AMU2_DSACHn as the data transfer occurs and, after the final
// transfer, “rounds up” to the next 32-byte aligned system Flash page address

void ADMA_SourceAddressUpdate( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// Destination Address Register Update
// This 2-bit field controls the updating of the AMU2_DDACHn register.
// 00 ADMA does not modify the original starting value of AMU2_DDACHn
// 01 ADMA uses AMU2_DDACHn + the current byte counter as the ARAM write address
// as each data transfer occurs except for the final 8-byte transfer. Both the
// AMU2_DDACHn and AMU2_DCNTCHn register values are unchanged. This value
// enables the special ADMA transfer where the last 8 bytes are not written into the
// ARAM, but instead are written into the AMU2_CCR{1,2}CHn registers. For this mode,
// the contents of AMU2_DCNTCHn defines the total number of data bytes to be
// transferred + 8 (for the final 8-byte transfer to the AMU2_CCR{1,2}CHn). Additionally,
// if DCCRCHn[DECC] = 0, any required single-bit corrections on the fetched data,
// including that destined for AMU2_CCR{1,2}CHn, are performed before being
// forwarded to the destination (either the ARAM or the control & configuration
// registers). If a non-correctable ECC event is detected on the last 64-bit data fetch, the
// update of the AMU2_CCR{1,2}CHn registers is not performed to avoid any
// inadvertent ALU activity
// 10 ADMA increments the AMU2_DDACHn as each data transfer occurs including the
// last transfer. The final value points to the next 8-byte aligned ARAM address
// 11 ADMA increments the AMU2_DDACHn as each data transfer occurs including the
// last transfer. The final value points to the next 8-byte aligned ARAM address

void ADMA_DestinationAddressUpdate( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// Halt on Cyclic Redundancy Check Error
// This bit determines the AMU2’s response to a properly-enabled (ECRC == 1) CRC
// checksum error.
// 0 AMU2 continues calculation regardless of the error status associated with a CRC
// checksum
// 1 AMU2 halts execution if a CRC checksum error is detected when DCCRCHn[ECRC]
// = 1

void ADMA_HaltOnCRCError( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Enable Cyclic Redundancy Check
// This bit enables the ADMA’s calculation of a CRC checksum as data is written into the
// ARAM. The expected 32-bit checksum result is defined in the AMU2_DCKSCHn
// register.
// 0 ADMA checksum is disabled
// 1 ADMA checksum is enabled

void ADMA_EnableCRC( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Clear ADMA State
// Setting this bit resets the DMA status state machine (AMU2_SEIRCHn[ADMAS]) to idle.
// The use of this bit is intended for situations where halted or stopped data transfers are
// not continued. This bit always reads as a zero.
// See Section 88.3.6.2: ADMA execution states for more information.
// 0 Do not reset the ADMA status state machine to idle
// 1 Reset the ADMA status state machines to idle

void ADMA_ClearState( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Disable ADMA ECC single bit corrections
// Setting this bit disables the ADMA’s ECC logic from performing single-bit corrections and
// double-bit detections on data to be written into the ARAM and optionally sent to the CRC
// logic for checksum generation.
// This bit is intended for test and debug purposes.
// 0 Enable single-bit corrections and double-bit detections on corrupted data fetched from
// the system Flash address space
// 1 Disable single-bit corrections and double-bit detections on corrupted data fetched from
// the system Flash address space

void ADMA_DisableECC( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Stream the P3 vector into a 128-byte ARAM circular FIFO
// When enabled, the P3 vector is fetched from the system Flash using the
// AMU2_P3PTRCHn register (which is incremented) and written into a dedicated 128-
// byte ARAM FIFO. The transfers are paced by the ALU’s execution speed. Due to the
// inherent pipelining of the AMU2, speculative prefetches beyond the actual P3 vector in
// Flash are likely - the AMU2_P3PTRCHn register must be reloaded before the next
// calculation. When operating in this mode, the checksum function is not supported.
// The streaming of P3 data is initiated when STMP3 = 1 and SRT = 1. Concurrent
// streaming of the V array can be supported by also setting STMV{32,16} != 00.
// When a non-streamed ADMA data transfer is required, this flag must be cleared. The
// ADMA supports either normal data transfers or a streaming operation.
// Writes to AMU2_CCR2CHn[ADCC18] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[STMP3] =
// AMU2_CCR2CHn[ADCCR18].
// 0 P3 streaming mode is disabled
// 1 P3 streaming mode is enabled

void ADMA_StreamP3( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Stream the 32-bit V array into a 256-byte ARAM circular FIFO
// When enabled, the 32-bit V array is fetched from the system Flash using the
// AMU2_VPTRCHn register (which is incremented) and written into a dedicated 256-byte
// ARAM FIFO. The transfers are paced by the ALU’s execution speed. Due to the inherent
// pipelining of the AMU2, speculative prefetches beyond the actual V array in Flash are
// likely - the AMU2_VPTRCHn register must be reloaded before the next calculation.
// When operating in this mode, the checksum function is not supported.
// The separate STMV{32,16} are required so the ADMA can begin the appropriate data
// transfer before the AMU2_CCR1CHn[V16] is configured. It is software’s responsibility to
// insure the STMV{32,16} and AMU2_CCR1CHn[V16] settings are consistent.
// The definition of the 2-bit {STMV32, STMV16} configuration bits is:
// (00) All V streaming is disabled
// (01) 16-bit V streaming is enabled
// (10) 32-bit V streaming is enabled
// (11) 32-bit V streaming is enabled
// The streaming of V data is initiated when STMV{32, 16} != 00 and SRT = 1. Concurrent
// streaming of the P3 vector can be supported by also setting STMP3 = 1.
// When a non-streamed ADMA data transfer is required, this flag must be cleared. The
// ADMA supports either normal data transfers or a streaming operation.
// Writes to AMU2_CCR2CHn[ADCC19] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[STMV32] =
// AMU2_CCR2CHn[ADCCR19].
// 0 V32 streaming mode is disabled
// 1 V32 streaming mode is enabled

void ADMA_StreamV32( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Stream the 16-bit V array into a 256-byte ARAM circular FIFO
// When enabled, the 16-bit V array is fetched from the system Flash using the
// AMU2_VPTRCHn register (which is incremented) and written into a dedicated 256-byte
// ARAM FIFO. The transfers are paced by the ALU’s execution speed. Due to the inherent
// pipelining of the AMU2, speculative prefetches beyond the actual V array in Flash are
// likely - the AMU2_VPTRCHn register must be reloaded before the next calculation.
// When operating in this mode, the checksum function is not supported.
// The separate STMV{32,16} are required so the ADMA can begin the appropriate data
// transfer before the AMU2_CCR1CHn[V16] is configured. It is software’s responsibility to
// insure the STMV{32,16} and AMU2_CCR1CHn[V16] settings are consistent.
// 0 V16 streaming mode is disabled
// 1 V16 streaming mode is enabled
// The definition of the 2-bit {STMV32, STMV16} configuration bits is:
// (00) All V streaming is disabled
// (01) 16-bit V streaming is enabled
// (10) 32-bit V streaming is enabled
// (11) 32-bit V streaming is enabled
// The streaming of V data is initiated when STMV{32,16} != 00 and SRT = 1. Concurrent
// streaming of the P3 vector can be supported by also setting STMP3 = 1.
// When a non-streamed ADMA data transfer is required, this flag must be cleared. The
// ADMA supports either normal data transfers or a streaming operation.
// Writes to AMU2_CCR2CHn[ADCC20] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[STMV16] =
// AMU2_CCR2CHn[ADCCR20].

void ADMA_StreamV16( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Enable High Priority
// The ADMA’s private connection with the platform Flash controller includes a signal that
// elevates the priority of a data request versus requests from the other system bus
// masters. By default, the ADMA’s priority is lower than the other system bus masters.
// However, when this control signal is asserted, the ADMA’s request is given highest
// priority within the platform Flash controller. The assertion of this high priority signal is
// controlled by three mechanisms:
// (1) For non-streamed ADMA transfers, the high priority control signal is asserted based
// on the setting of the ADMA speed control and the platform Flash controller’s response
// time. If the responses are too slow, the ADMA asserts the high priority signal.
// (2) For streamed ADMA transfers, the high priority control signal is asserted based on
// the setting of the ALU speed control and the platform Flash controller’s response time.
// Again, if the responses are too slow based on the ALU’s need for new data, the ADMA
// asserts the high priority signal.
// (3) If this EHP bit is set, the high priority control signal is unconditionally asserted.
// 0 ADMA does not unconditionally assert the high priority signal to the platform Flash
// controller
// 1 ADMA does unconditionally assert the high priority signal to the platform Flash
// controller

void ADMA_EnableHighPriority( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// ADMA Stop if Alu Stops. This bit provides a mechanism to automatically stop the ADMA
// channel transfer requests if the ALU stops for any reason.
// This bit applies to non-streamed ADMA transfers. When streaming P3 or V, or both, the
// ADMA automatically stops streaming if/when the ALU is stopped or halted, and
// automatically resumes streaming when the calculation is resumed.
// 0 ALU stops do not affect the ADMA
// 1 ALU stops force the ADMA to also stop

void ADMA_StopIfAluStops( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// ADMA Stop request
// The setting of this indicator bit signals the ADMA to stop at the next appropriate point.
// The ADMA run status is available in AMU2_SEIRCHn[ADMAS].
// If the P3 vector or V array, or both, are being streamed, the ADMA data transfers are
// paced by the ALU calculation speed, so any stop or halt condition to the ALU
// automatically stalls the ADMA.
// Note the simultaneous assertion of the STP and any conditional (WFS1D, WFS23D,
// WFDNI) or unconditional (SRT) start indicators causes the attempted ADMA initiation to
// effectively be ignored with no change in the AMU2_SEIRCHn[ADMAS] status.
// 0 No ADMA stop request; it operates normally
// 1 ADMA stop request; stop data transfer at the next appropriate point. Once the ADMA
// stops, this indicator is cleared.

void ADMA_StopRequest( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// ADMA Error Interrupt ConfIguration
// This field controls the reporting mechanism associated with the ADMA error indicator
// flag (AMU2_SEIRCHn[DEIRQ]).
// 0 If an ADMA error is detected, set the indicator flag; the flag is explicitly cleared by
// software.
// 1 If an ADMA error is detected, set the indicator flag and assert core interrupt request;
// the flag is explicitly cleared by software.

void ADMA_ErrorInterruptConfiguration( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Wait For ALU Done Interrupt request
// This flag is a conditional ADMA start indicator. If asserted, the ADMA does not begin any
// data transfers until the ALU’s stage2 + 3 calculations complete and set the
// AMU2_SEIRCHn[DNIRQ] indicator. This condition is signaled by
// (AMU2_SEIRCHn[DNIRQ] = 1’b1). If the ALU is idle when the AMU2_DCCRCHn
// register is loaded and a conditional ADMA start after the next ALU calculation completes
// is desired, the WFDNI indicator should be used.
// Once the ADMA transfer begins, this indicator bit is automatically cleared.
// Writes to AMU2_CCR2CHn[ADCC25] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[WFDNI] =
// AMU2_CCR2CHn[ADCCR25].
// 0 No ADMA start condition dependency
// 1 ADMA does not start until the ALU’s stage2 + 3 calculations complete, and set
// AMU2_SEIRCHn[DNIRQ]

void ADMA_WaitForAluDoneInterruptRequest( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Wait For Stage23 Done
// This flag is a conditional ADMA start indicator. If asserted, the ADMA does not begin any
// data transfers until the ALU’s stage2 + 3 calculations are complete. This condition is
// signaled by (AMU2_SEIRCHn[S23XS] == 2’b00). Once the ADMA transfer begins, this
// indicator bit is automatically cleared.
// If the ADMA’s data transfer must be delayed until the entire ALU calculation is complete,
// then both WFS1D and WFS23D must be asserted. Alternatively, the WFDNI flag can be
// used as the conditional ADMA start condition.
// Writes to AMU2_CCR2CHn[ADCC26] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[WFS23D] =
// AMU2_CCR2CHn[ADCCR26].
// 0 No ADMA start condition dependency
// 1 ADMA does not start until the ALU’s stage2 + 3 calculations are complete

void ADMA_WaitForStage23Done( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Wait For Stage1 Done
// This flag is a conditional ADMA start indicator. If asserted, the ADMA does not begin any
// data transfers until the ALU’s stage1 calculation is complete. This condition is signaled
// by (AMU2_SEIRCHn[S1XS] == 2’b00). Once the ADMA transfer begins, this indicator bit
// is automatically cleared.
// If the ADMA’s data transfer must be delayed until the entire ALU calculation is complete,
// then both WFS1D and WFS23D must be asserted. Alternatively, the WFDNI flag can be
// used as the conditional ADMA start condition.
// Writes to AMU2_CCR2CHn[ADCC27] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[WFS1D] =
// AMU2_CCR2CHn[ADCCR27].
// 0 No ADMA start condition dependency
// 1 ADMA does not start until the ALU’s stage1 calculation is complete

void ADMA_WaitForStage1Done( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// ADMA ReSuMe
// The assertion of a properly-qualified resume condition ((RSM == 1) && (STP == 0))
// resumes the data transfer defined by the contents of the ADMA’s registers, exiting from
// the stopped state.
// This bit applies to non-streamed ADMA transfers. When streaming P3 or V, or both, the
// ADMA automatically stops streaming if/when the ALU is stopped or halted, and
// automatically resumes streaming when the calculation is resumed.
// Once the ADMA resumes execution, this indicator bit is automatically cleared.
// 0 Do not resume the ADMA
// 1 Resume the ADMA’s data transfer

void ADMA_Resume( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// Force ARAM to Zero
// The assertion of this indicator flag enables a special ADMA mode of operation where up
// to 16 bytes of zero data (with the appropriate ECC check bits) are written into the ARAM
// destination defined by AMU2_DDACHn on alternating cycles.
// This ARAM initialization mode functions in a manner similar to a normal ADMA data
// transfer. Instead of fetching data from the Flash (or one of its remapped destination
// memories), the ADMA forces all zero data with correct ECC to be written into the ARAM.
// The AMU2_DSACHn register is not used, but the starting destination address is defined
// by AMU2_DDACHn and the size of the memory to be cleared by
// AMU2_DCNTCHn[BCNT]. The CRC is not supported in this mode, and
// AMU2_DCCRCHn[DARU] must be 0b00. The ARAM initialization is initiated by setting
// AMU2_DCCRCHn[SRT] = 1. All the ADMA status reporting operates like a normal data
// transfer. It is recommended that the other ADMA channel be idle during this initialization
// function.
// 0 The zeroing of the ARAM by the ADMA is disabled
// 1 The zeroing of the ARAM by the ADMA is enabled

void ADMA_ForceAramToZero( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// ADMA Start request. This assertion of a properly-qualified start condition ((SRT == 1) &&
// (STP == 0)) initiates the data transfer defined by the contents of the ADMA’s registers.
// Once ADMA starts execution, this indicator bit is automatically cleared.
// Writes to AMU2_CCR2CHn[ADCC31] may affect this indicator, that is, if
// AMU2_CCR2CHn[ADCCRE] == 1, AMU2_DCCRCHn[SRT] =
// AMU2_CCR2CHn[ADCCR31].
// 0 Do not unconditionally start the ADMA
// 1 Unconditionally start the ADMA

void ADMA_StartRequest( volatile struct AMU_tag * amu ,uint01 indicatorFlag, unsigned int usedChannel);

// CCR1CH configuration bits

// Start Speed
// This 3-bit encoded value defines the start speed for the ALU engine. It is used with the
// MAXSP field and AMU2_P8CHn[THRHC] with the current speed of the ALU is reported
// in AMU2_SEIRCHn[ACURSP].
// The ALU speed control provides a mechanism to control the operation efficiency of the
// engine for coarse power control of the AMU. See Section 88.3.5.2: ALU speed control
// for more details on the ALU speed control mechanism. There is a single ALU speed
// control function shared by the calculation engine and accessible from either the CH0 or
// CH1 programming models.
// 000 Maximum speed; speed control disabled
// 001 1/8 speed
// 010 2/8 speed
// 011 3/8 speed
// 100 4/8 speed
// 101 5/8 speed
// 110 6/8 speed
// 111 7/8 speed

// channels selections => 
// a) 0 => channel 0
// b) 1 => channel 1
// c) 2 => channel 0 and 1



void ALU_StartSpeed( volatile struct AMU_tag * amu ,uint08 ALUspeed, unsigned int usedChannel);

// Maximum Speed
// This 3-bit encoded value defines the maximum speed for the ALU engine. It is used with
// the SRTSP field and AMU2_P8CHn[THRHC] with the current speed of the ALU is
// reported in AMU2_SEIRCHn[ACURSP].
// The ALU speed control provides a mechanism to control the operation efficiency of the
// engine for coarse power control of the AMU. See Section 88.3.5.2: ALU speed control
// for more details on the ALU speed control mechanism. There is a single ALU speed
// control function shared by the calculation engine and accessible from either the CH0 or
// CH1 programming models.
// 000 Maximum speed
// 001 1/8 speed
// 010 2/8 speed
// 011 3/8 speed
// 100 4/8 speed
// 101 5/8 speed
// 110 6/8 speed
// 111 7/8 speed

// channels selections => 
// a) 0 => channel 0
// b) 1 => channel 1
// c) 2 => channel 0 and 1

void ALU_MaxSpeed( volatile struct AMU_tag * amu ,uint08 ADMAspeed, unsigned int usedChannel);

// ALU Error Interrupt ConFiGuration
// This 2-bit field provides the reporting mechanism associated with the ALU error indicator
// flag (AMU2_SEIRCHn[ERIRQ]).
// 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ALU error condition
// 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software
// 10 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ALU error condition
// 11 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software

void ErrorInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// Overflow Interrupt Configuration
// This 2-bit field provides the reporting mechanism associated with the ALU overflow
// indicator flag (AMU2_SEIRCHn[OVIRQ]).
// 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ALU overflow condition.
// 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software.
// 10 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ALU overflow condition.
// 11 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software.

void OverflowInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// N Crossing Interrupt Configuration
// This 2-bit field provides the reporting mechanism associated with the ALU N crossing
// indicator flag (AMU2_SEIRCHn[NCIRQ]).
// 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ALU N crossing condition
// 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software
// 10 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
// acknowledgement.The AMU2_CCR2CHn[SNCRS] indicator should be set so the
// ALU stops its calculation so the correct intermediate result is available for the SDMA
// 11 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
// acknowledgement.The AMU2_CCR2CHn[SNCRS] indicator should be set so the
// ALU stops its calculation so the correct intermediate result is available for the SDMA

void NCrossingInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// ALU Done Interrupt Configuration
// This 2-bit field provides the reporting mechanism associated with the ALU done, that is,
// a calculation has successfully completed, indicator flag (AMU2_SEIRCHn[DNIRQ]).
// 00 Set indicator flag; the flag is explicitly cleared by software. This mode can be used by
// software to poll for ALU done condition.
// 01 Set indicator flag, assert core interrupt request. The flag is explicitly cleared by
// software.
// 10 Set indicator flag, assert SDMA request. The flag is cleared by an SDMA
// acknowledgement
// 11 Set indicator flag, initiate an ADMA transfer if one of the conditional start flags
// (AMU2_DCCRCHn[WFS1D, WFS23D, WFDNI]) is also asserted. The
// AMU2_SEIRCHn[DNIRQ] flag is cleared by the AMU

void DoneInterruptConFiGuration( volatile struct AMU_tag * amu ,uint02 indicatorFlag, unsigned int usedChannel);

// Bus Priority
// This indicator bit controls the bus arbitration priority associated with the ARAM and the
// programming model registers. Recall from Figure 2350: AMU2 block diagram, there are
// multiple master devices that can access the ARAM and programming model registers,
// specifically, the ADMA and ALU as well as system bus transfers routed via slave
// peripheral bus. This indicator bit controls the arbitration policy for selecting one master’s
// request when concurrent accesses occur; idle cycles from the selected master provide
// opportunities for stalled accesses from other masters to be granted and complete.
// 0 ADMA has higher arbitration priority than the ALU which has higher priority than slave
// peripheral bus accesses (ADMA > ALU > slave peripheral bus)
// 1 ADMA has higher arbitration priority than slave peripheral bus accesses which have
// higher priority than the ALU (ADMA > slave peripheral bus > ALU)

void BusPriority( volatile struct AMU_tag * amu ,uint01 priority, unsigned int usedChannel);

// Enable Error Correcting Code (ECC) in the ARAM
// This bit controls the checking of data read from the ARAM by the ALU and the slave
// peripheral bus. Note, ECC is generated on all writes to the ARAM from either the ADMA
// or the slave peripheral bus. If a single-bit error is detected by the ECC logic on an ARAM
// read, the corrected data is written back into the ARAM only in response to the readmodify-
// write sequence needed on all slave peripheral write accesses.
// 0 ECC checking of ARAM reads is disabled
// 1 ECC checking of ARAM reads is enabled
// If the system DMA is used for ARAM initialization, the EECC bits for both channels must
// be cleared until the initialization is complete.

void EnableARAMECC( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Disable Debug Stall
// This bit disables the AMU from stalling when an MCU debug event is underway.
// 0 All debug events, as signaled by an input signal, stall the AMU. The stall globally
// affects both channels of the ADMA and ALU
// 1 Debug events do not affect the AMU

void DisableDebugStall( volatile struct AMU_tag * amu ,uint01 disable, unsigned int usedChannel);

// Set Z result
// This bit controls the first operation performed in the ALU’s stage3 output normalization.
// As the name implies, if this bit is asserted, the final result (z64) is set to the P5 data
// value, else it is unaffected. The second operation in stage3 involves a final accumulation
// with the result plus the product of y64 and p4.
// The stage3 output normalization pseudo-code is:
// /* stage 3: output normalization */
// if (setz) {
// z64 = (ieee64) p5;
// }
// z64 = z64 + (ieee32) y64 * p4; // 32 x 32 -> 64 FMA
// 0 z64 is unaffected
// 1 z64 is set to the 64-bit double-precision value of p5

void SetZResult( volatile struct AMU_tag * amu ,uint01 set, unsigned int usedChannel);

// Enable SETZ Clear
// If set, this bit forces the SETZ flag to be automatically cleared after a stage3 calculation
// as indicated by the assertion of AMU2_SEIRCHn[DNIRQ].
// 0 SETZ flag is not cleared by the hardware.
// 1 SETZ flag is automatically cleared by the hardware after the stage3 calculation
// completes.

void EnableSETZClear( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// V is a 16-bit data format
// This bit, along with VFH, defines the format for the V array:
// if V16 = 0, then V[*] is 32-bit single-precision format (ieee32)
// if V16 = 1 && VFH = 0, then V[*] is 16-bit half-precision format (ieee16)
// if V16 = 1 && VFH = 1, then V[*] is 16-bit fixed-point format with a common 7-bit biased
// exponent
// This bit cannot be changed while the ADMA is streaming V[*] data. See
// Section 88.3.3.2: 16-bit fixed-point with common exponent for details on the 16-bit fixed
// point format.

void V16BitDataFormat( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// V is Fixed Halfword format
// This bit, along with V16, defines the format for the V array:
// if V16 = 0, then V[*] is 32-bit single-precision format (ieee32)
// if V16 = 1 && VFH = 0, then V[*] is 16-bit half-precision format (ieee16)
// if V16 = 1 && VFH = 1, then V[*] is 16-bit fixed-point format with a common 7-bit biased
// exponent
// See Section 88.3.3.2: 16-bit fixed-point with common exponent for details on the 16-bit
// fixed point format.

void VFixedHalfwordFormat( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Common Exponent
// This 7-bit field defines the common exponent using an excess-63 format for the V array’s
// 16-bit fixed-point format.
// See Section 88.3.3.2: 16-bit fixed-point with common exponent for details on the 16-bit
// fixed point format.

void CommonExponent( volatile struct AMU_tag * amu ,uint07 exponent, unsigned int usedChannel);

// CCR2CH

// Alternate DCCR write Enable
// This bit enables all the aliased AMU2_DCCRCHn indicators
// (AMU2_CCR2CHn[ADCR18, ADCCR19, ADCCR20, ADCCR25, ADCCR26,
// ADCCR27]) to be written when this register is updated. Clearing this bit allows software
// to write the AMU2_CCR2CHn without affecting the aliased control bits in the
// AMU2_DCCRCHn. The ADCCRE indicator always reads as a zero.
// 0 Contents of the write data for AMU2_CCR2CHn[ADCCR{18,19,20,25,26,27}] do not
// affect the AMU2_DcCRCHn
// 1 Contents of the write data for AMU2_CCR2CHn[ADCCR{18,19,20,25,26,27}] are
// loaded into AMU2_DCCRCHn

void AlternateDCCRWriteEnable( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[STMP3]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[STMP3], that is, AMU2_DCCRCHn[STMP3] =
// AMU2_CCR2CHn[ADCCR18], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the STMP3 indicator allows it to be written by the special ADMA
// mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateSTMP3( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[STMV32]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[STMV32], that is, AMU2_DCCRCHn[STMV32] =
// AMU2_CCR2CHn[ADCCR19], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the STMV32 indicator allows it to be written by the special ADMA
// mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateSTMV32( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[STMV16]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[STMV16], that is, AMU2_DCCRCHn[STMV16] =
// AMU2_CCR2CHn[ADCCR20], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the STMV16 indicator allows it to be written by the special ADMA
// mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateSTMV16( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[WFDNI]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[WFDNI], that is, AMU2_DCCRCHn[WFDNI] =
// AMU2_CCR2CHn[ADCCR25], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the WFDNI indicator allows it to be written by the special ADMA
// mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateWFDNI( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[WFS23D]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[WFS23D], that is, AMU2_DCCRCHn[WFS23D] =
// AMU2_CCR2CHn[ADCCR26], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the WFS23D indicator allows it to be written by the special ADMA
// mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateWFS23D( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[WFS1D]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[WFS1D], that is, AMU2_DCCRCHn[WFS1D] =
// AMU2_CCR2CHn[ADCCR27], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the WFS1D indicator allows it to be written by the special ADMA
// mode that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateWFS1D( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Alternate AMU2_DCCRCHn[SRT]
// If a register write with AMU2_CCR2CHn[ADCCRE] == 1, then writes to this indicator flag
// directly affect AMU2_DCCRCHn[SRT], that is, AMU2_DCCRCHn[SRT] =
// AMU2_CCR2CHn[ADCCR31], else the AMU2_DCCRCHn indicator is unaffected.
// This alternate copy of the SRT indicator allows it to be written by the special ADMA mode
// that loads the AMU2_CCR{1,2}CHn registers as the last 8 bytes transferred.

void AlternateSRT( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Enable N CRoSsing event
// This bit enables the occurrence of an N crossing event.
// 0 The ALU’s N crossing logic is disabled
// 1 The ALU’s N crossing logic is enabled

void EnableNCRoSsing( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Stop on N CRoSsing event
// This bit forces the ALU to stop execution on the occurrence of an N crossing event.
// 0 The ALU does not stop execution when an N crossing event occurs
// 1 The ALU stops execution when an N crossing event occurs

void StopOnNCRoSsing( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Clear Stage “X” eXecution State
// Setting this bit resets both the ALU execution state machines (AMU2_SEIRCHn[S1XS,
// S23XS]) to idle. The use of this bit is intended for situations where halted or stopped
// calculations are not continued. This bit always reads as a zero.
// 0 Do not reset the ALU execution state machines to idle
// 1 Reset both of the ALU execution state machines to idle
// See Section 88.3.5.1: ALU execution states for more information.

void ClearStageXeXecutionState( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Stage23 STop request
// The setting of this indicator bit signals the ALU to stop at the completion of the current
// outer loop execution. If asserted after the final stage2 outer loop completes, stage3 also
// finishes and S23STP remains asserted indicating the stop request was not granted.The
// ALU’s stage23 status is available in AMU2_SEIRCHn[S23XS].
// Once the ALU is stopped, this indicator bit is automatically cleared.
// 0 No stage23 stop request; the ALU operates normally
// 1 Stage23 stop request; stop execution at the completion of the current outer loop
// iteration

void Stage23STopRequest( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Wait For Sdma complete before starting Stage23
// This is a conditional start bit for stage23. It signals the stage23 execution start is enabled
// by the completion of an SDMA data transfer.
// This indicator is used when the SDMA is used to copy an AMU result into system
// memory. The setting of this flag means the SDMA result retrieval must be finished before
// a stage23 calculation is initiated. Once stage23 begins execution, this indicator bit is
// automatically cleared.
// When streaming P3[*] or V[*] data, or both, this indicator bit is ignored.
// 0 No conditional stage23 start condition
// 1 Initiate stage23’s execution when the SDMA completes its current data transfer

void WaitForSdmaCompleteBeforeStartingStage23( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Wait For aDma complete before starting Stage23
// This is a conditional start bit for stage23. It signals the stage23 execution start is enabled
// by the completion of the ADMA data transfer.
// The WFDS23 indicator is automatically cleared if the ADMA halts due to a bus or noncorrectable
// ECC error, or if a checksum error is detected. This prevents the ALU stage23
// execution from starting after the ADMA halt condition is processed by a service routine.
// The WFDS23 conditional start indicator can be combined with WFDS1. If both bits are
// asserted, as the ADMA completes its data transfer, the ALU begins execution of stage1,
// followed by stage23.
// Once stage23 begins execution, this indicator bit is automatically cleared.
// When streaming P3[*] or V[*] data, or both, this indicator bit is ignored.
// 0 No conditional stage23 start condition
// 1 Initiate stage23’s execution when the ADMA completes its current data transfer

void WaitForADmaCompleteBeforeStartingStage23( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Wait For aDma complete before starting Stage1
// This is a conditional start bit for stage1. It signals the stage1 execution start is enabled by
// the completion of the ADMA data transfer.
// The WFDS1 indicator is automatically cleared if the ADMA halts due to a bus or noncorrectable
// ECC error, or if a checksum error is detected. This prevents the ALU stage1
// execution from starting after the ADMA halt condition is processed by a service routine.
// The WFDS1 conditional start indicator can be combined with WFDS23. If both bits are
// asserted, as the ADMA completes its data transfer, the ALU begins execution of stage1,
// followed by stage23. Once stage1 begins execution, this indicator bit is automatically
// cleared.
// When streaming P3[*] or V[*] data, or both, this indicator bit is ignored.
// 0 No conditional stage1 start condition
// 1 Initiate stage1’s execution when the ADMA completes its current data transfer.

void WaitForADmaCompleteBeforeStartingStage1( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Stage23 ReSuMe
// This bit resumes a stopped stage23 calculation. If stage23 is not stopped at the time of
// an attempted write to assert this bit, it is ignored.
// Once stage23 resumes execution, this indicator bit is automatically cleared.
// 0 Do not resume a stopped stage23 calculation
// 1 Resume a stopped stage23 calculation

void Stage23ReSuMe( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Stage23 StaRT request. This assertion of a properly-qualified start condition ((S23SRT
// == 1) && (S23STP == 0)) initiates the ALU’s stage23 execution. If S1SRT is also
// asserted, the ALU hardware sequences through the execution, first of stage1 and then
// stage23.
// Once stage23 starts execution, this indicator bit is automatically cleared.
// 0 Do not unconditionally start ALU’s stage23 execution
// 1 Unconditionally start ALU’s stage23 execution, either immediately or after stage1
// completes

void Stage23StaRTRequest( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

// Stage1 StaRT request. This assertion of this start condition initiates the ALU’s stage1
// execution.
// Once stage1 starts execution, this indicator bit is automatically cleared.
// 0 Do not unconditionally start ALU’s stage1 execution
// 1 Unconditionally start ALU’s stage1 execution

void Stage1StaRTRequest( volatile struct AMU_tag * amu ,uint01 enable, unsigned int usedChannel);

#endif