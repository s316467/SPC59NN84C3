#include <stdio.h>
#include "./amu_test.h"


#ifdef TESTING 

ieee32 amuExp(ieee32 t){
    // Special case analysis
    if (t > 88.7228390520687) return 0x7F800000; // +Inf
    if (t < -88.7228390520687) return 0x00000000; // +0
    // Argument reduction
    ieee16 E = (ieee16)(t * 1.4426950408889634); // 1/ln(2)
    ieee32 z = t - E * 0.6931471805599453; // ln(2)
    // Function evaluation
    uint07 A = (uint07)(z * 64.0); // 6-bit integer
    ieee32 B = z - A * 0.015625; // 1/64
    ieee32 ez = 1.0 + B * (0.5 + B * 0.167876224340382);
    // Range reconstruction
    return (E << 23) + (ieee32)(ez* 388608.0); // 2^23
}

void amuStage1(
  ieee32* u, // pointer to u[p7] 32-bit single data array
  ieee32* p1, // pointer to p1[p7] 32-bit single data array
  ieee32* p2, // pointer to p2[p7] 32-bit single data array
  ieee32* ut, // pointer to ut[p7] 32-bit single data array
  uint05* p7 // dimension of the ASC function, so is max 2^5 = 32
) {
  uint16 k; // local loop counter
  /* stage 1 */
  for (k = 0; k < *p7; k++) {
  *(ut + k*4) = (ieee32) (*(u + k*4) * *(p1 + k*4) + (ieee64) *(p2 + k*4)); // 32x32 . 64 FMA
  }
}

void amuStage23(
  ieee32* ut, // pointer to ut[p7] 32-bit single data array
  uint01* v16, // v[p6*p7] is 16-bit data array
  uint01* vfh, // v[p6*p7] is 16-bit half precision float
  ieee32* v32f, // pointer to v[p6*p7] as ieee32
  ieee16* v16h, // pointer to v[p6*p7] as ieee16
  uint16* v16x, // pointer to v[p6*p7] as 16-bit fixed-point
  uint07* cmExp, // v[p6*p7] common exponent for 16-bit fixed
  ieee32* L, // pointer to L[p7] 32-bit single data array
  ieee32* p1, // pointer to p1[p7] 32-bit single data array
  ieee32* p3, // pointer to p3[p7] 32-bit single data array
  ieee32* p4, // scalar factor in the output normalization
  ieee32* p5, // optional start value in the output normalization
  uint16* p6, // size of the ASC function
  uint05* p7, // dimension of the ASC function
  uint16* p8, // outer stage2 "for" loop count
  ieee64* p9, // starting value of double-precision y accumulator
  uint01* setz, // configuration to define initial z64 value
  ieee64* y64, // 64-bit double-precision outer loop output value
  ieee32* y32, // 32-bit single-precision version of y64
  ieee64* z64, // 64-bit double-precision final output value
  ieee32* z32 // 32-bit single-precision version of final output
) {
  ieee32 d, e, v_ieee32;// internal stage23 local single-precision variables
  ieee64 t; // internal stage23 local double-precision accumulator
  uint16 p8_init; // internal unsigned integer variable
  uint16 i,j,k; // internal unsigned integer array index (i), loop count variables (j,k)
  /* data initialization */
  *y64 = *p9;
  p8_init = *p1;
  /* stage 2: t accumulation, exp(-t), y accumulation */
  for (j = *(p1 + (*p7 * 4)); j < *(p6 + (*p7 * 4)); j++) {
    i = j * *p7;
    /* stage 2a: t accumulation */
    t = (ieee64) 0.0;
    for (k = 0; k < *p7; k++) {
      switch ((*(v16 + (*p6 * *p7)*4) << 1) + *(vfh + (*p6 * *p7)*4)) {
        case 0:
        case 1: // V array = ieee32 format
          v_ieee32 = *(v32f + (i+k)*4);
          break;
        case 2: // V array = ieee16 format
          v_ieee32 = (ieee32) *(v16h + (i+k)*4);
          break;
        case 3:
          v_ieee32 = convertFixedPoint (*cmExp-63, *(v16x + (i+k)*4));
          break;
      }
      d = *(ut + k*4) - v_ieee32;
      d = (ieee32)(d * d);
      t += (*(L + k*4) * d); // 32 x 32 . 64 FMA
    }
    /* stage 2b: exp() */
    e = amuExp(-(ieee32)t); // amu exp()
    /* stage 2c: y64 accumulation */
    *y64 += *(p3 + j*4) * e; // 32 x 32 . 64 FMA
    *p8++; // update global loop counter
    // user stop requests pause the algorithm in-place at this point
  }
  *y32 = (ieee32) *y64; // ieee32 version of y
  /* stage 3: output normalization */
  if (*setz) {
    *z64 = (ieee64) *p5;
  }
  *z64 = *z64 + *y64 * *p4; // 32 x 32 . 64 FMA
  *z32 = (ieee32) *z64;
  *p8 = p8_init; // return p8 to original value
}


void gen_crc_table(){
  /* generate the table of CRC remainders for all possible bytes */
  register int i, j;
  register unsigned long crc_accum;
  for (i = 0; i < 256; i++) {
    crc_accum = ((unsigned long) i << 24);
    for (j = 0; j < 1; j++) {
      if (crc_accum & 0x80000000L)
        crc_accum = (crc_accum << 1) ^ POLYNOMIAL;
      else
        crc_accum = (crc_accum << 1);
    }
    crc_table[i] = crc_accum;
  }
}

unsigned long update_crc(unsigned long crc_accum,
char *data_blk_ptr,
int data_blk_size) {
  /* update the CRC on the data block one byte at a time */
  register int i, j;
  for (j = 0; j < data_blk_size; j++) {
    i = ((int)(crc_accum >> 24) ^ *data_blk_ptr++) & 0xff;
    crc_accum = (crc_accum << 8) ^ crc_table[i];
  }
  return crc_accum;
}


// problems with ieee32Result declaration when compiling

ieee32 convertFixedPoint(uint07 cmExp, uint16 v16x){
  int i, s;
  if (v16x & 0x8000) {
    s = 1;
    v16x = (~v16x + 1) & 0xffff; // same as v16x = -v16x
  } else
    s = 0;
  if (v16x & 0x8000)
    ieee32Result = 1<<31 | (64+cmExp)<<23; // minimum value
  else if (v16x == 0)
    ieee32Result = 0x00000000;
  else {
  for (i = 0; i < 16; i++) {
    v16x <<= 1;
    if (v16x & 0x8000)
      break;
    }
    ieee32Result = s<<31 | (63+cmExp-i)<<23 | (v16x & 0x7fff)<<1;
  }
  return ieee32Result;
}
#endif