#ifndef AMU_TEST_PARAMS_H
#define AMU_TEST_PARAMS_H
#include "../amu_typedefs.h"

extern ieee32 ieee32Result;
#define POLYNOMIAL 0x04c11db7L
static unsigned long crc_table[256];

// params for amuStage1 and amuStage23 tests (then physically done by AMU)

extern ieee32 p1[5];
extern ieee32 p2[5];
extern ieee32 p3[1];
extern ieee32 p4[1];
extern ieee32 p5[1];
extern uint16 p6[1]; // Size of the ASC function, reduced because of init size
extern uint05 p7[1]; // Dimensionality of the ASC function (if this => 32)
extern uint16 p8[1]; // outer stage2 "for" loop counter
extern ieee64 p9[1];
extern uint01 v16[1]; // 0 or 1
extern uint01 vfh[1]; // 0 or 1
extern ieee32 v32f[5];
extern ieee16 v16h[5];
extern uint16 v16x[5];
extern ieee32 L[5];
extern ieee32 u[5];
extern uint07 cmExp[1]; // 0 or 1
extern uint01 setz[1]; // 0 or 1
extern ieee64 y64[1];
extern ieee32 y32[1];
extern ieee64 z64[1];
extern ieee32 z32[1];
extern ieee32 ut[5];

typedef const struct AMU_params_tag{
    // max dimensions of p1, p2, p3, v32f,v16h,v16x, L and u should be 5460
    // Su 14.05.2023 16:31:57.115, Error, Core2, UDESymbolEngine, ABORT DOWNLOAD - Size of target pattern exceeds demo version limit (256 kByte)!
    ieee32 p1[5];
    ieee32 p2[5];
    ieee32 p3[5];
    ieee32 p4[1];
    ieee32 p5[1];
    uint16 p6[1];
    uint05 p7[1];
    uint16 p8[1];
    ieee64 p9[1];
    ieee32 v32f[5];
    ieee16 v16h[5];
    uint16 v16x[5];
    ieee32 L[5];
    ieee32 u[5];
    uint07 cmExp[1];
};

extern unsigned int ADMAusedChannels[2]; // indices 0 and 1

// TBC struct in case FIFOs not used

// typedef struct edma_channels_tag{
//     unsigned int num_used_channels;
//     unsigned int edma_channels[64];
// };


// previously considered as parameter, conf and results params in reality

// uint01 v16[1];
// uint01 vfh[1];
// uint01 setz[1];
// ieee64 y64[1];
// ieee32 y32[1];
// ieee64 z64[1];
// ieee32 z32[1];

#endif