#ifndef AMU_TEST_H
#define AMU_TEST_H

#define TESTING 1

#ifdef TESTING

#include "./amu_test_params.h"


ieee32 amuExp(ieee32 t);

void amuStage1(
  ieee32* u, // pointer to u[p7] 32-bit single data array
  ieee32* p1, // pointer to p1[p7] 32-bit single data array
  ieee32* p2, // pointer to p2[p7] 32-bit single data array
  ieee32* ut, // pointer to ut[p7] 32-bit single data array
  uint05* p7 // dimension of the ASC function, so is max 2^5 = 32
);

void amuStage23(
  ieee32* ut, // pointer to ut[p7] 32-bit single data array
  uint01* v16, // v[p6*p7] is 16-bit data array
  uint01* vfh, // v[p6*p7] is 16-bit half precision float
  ieee32* v32f, // pointer to v[p6*p7] as ieee32
  ieee16* v16h, // pointer to v[p6*p7] as ieee16
  uint16* v16x, // pointer to v[p6*p7] as 16-bit fixed-point
  uint07* cmExp, // v[p6*p7] common exponent for 16-bit fixed
  ieee32* L, // pointer to L[p7] 32-bit single data array
  ieee32* p1, // pointer to p1[p7] 32-bit single data array
  ieee32* p3, // pointer to p3[p7] 32-bit single data array
  ieee32* p4, // scalar factor in the output normalization
  ieee32* p5, // optional start value in the output normalization
  uint16* p6, // size of the ASC function
  uint05* p7, // dimension of the ASC function
  uint16* p8, // outer stage2 "for" loop count
  ieee64* p9, // starting value of double-precision y accumulator
  uint01* setz, // configuration to define initial z64 value
  ieee64* y64, // 64-bit double-precision outer loop output value
  ieee32* y32, // 32-bit single-precision version of y64
  ieee64* z64, // 64-bit double-precision final output value
  ieee32* z32 // 32-bit single-precision version of final output
);


void gen_crc_table();

unsigned long update_crc(unsigned long crc_accum,
char *data_blk_ptr,
int data_blk_size);

ieee32 convertFixedPoint(uint07 cmExp, uint16 v16x);

#endif
#endif