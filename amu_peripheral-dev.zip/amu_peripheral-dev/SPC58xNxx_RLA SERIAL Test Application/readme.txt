TThis application shows how to the use the PAL and SERIAL driver. It writes
"Hello World!" on serial port and lights the LED_D2 and LED_D3

Please configure the board as follow:

 - wire pins P7[1] and P8[1] for LED_D2.
 - wire pins P7[2] and P8[2] for LED_D3.
 - pin P8[10] with the pin J13 (SCI) and on PC set baudrate to 38400
 


